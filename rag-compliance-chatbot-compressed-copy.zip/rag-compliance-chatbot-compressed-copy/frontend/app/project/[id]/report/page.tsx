'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { ArrowLeft, FileText, AlertTriangle, CheckCircle, ChevronRight, Sun, Moon } from 'lucide-react';

interface MetricCard {
  title: string;
  status: 'compliant' | 'warning' | 'critical';
  message: string;
  link: string;
}

export default function ReportPage() {
  const params = useParams();
  const router = useRouter();
  const projectId = params.id as string;
  const [darkMode, setDarkMode] = useState(true);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const metrics: MetricCard[] = [
    {
      title: 'Personal Data Protection',
      status: 'compliant',
      message: 'All GDPR requirements met',
      link: 'What are specific requirements for data transfer to Germany?'
    },
    {
      title: 'Transfer Impact Assessment',
      status: 'warning',
      message: 'TIA documentation needs review',
      link: 'How do I document a TIA properly?'
    },
    {
      title: 'Consent Mechanisms',
      status: 'critical',
      message: 'Explicit consent form missing',
      link: 'What are the consent requirements for EU data transfer?'
    },
    {
      title: 'Data Processing Records',
      status: 'compliant',
      message: 'Processing records are up to date',
      link: 'What records must be maintained?'
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'compliant':
        return <CheckCircle className={darkMode ? 'text-emerald-400' : 'text-emerald-600'} size={20} />;
      case 'warning':
        return <AlertTriangle className={darkMode ? 'text-yellow-400' : 'text-yellow-600'} size={20} />;
      case 'critical':
        return <AlertTriangle className={darkMode ? 'text-red-400' : 'text-red-600'} size={20} />;
      default:
        return <CheckCircle className={darkMode ? 'text-gray-400' : 'text-gray-600'} size={20} />;
    }
  };

  const getStatusColor = (status: string) => {
    if (darkMode) {
      switch (status) {
        case 'compliant': return 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400';
        case 'warning': return 'bg-yellow-500/10 border-yellow-500/30 text-yellow-400';
        case 'critical': return 'bg-red-500/10 border-red-500/30 text-red-400';
        default: return 'bg-gray-500/10 border-gray-500/30 text-gray-400';
      }
    } else {
      switch (status) {
        case 'compliant': return 'bg-emerald-100 border-emerald-300 text-emerald-700';
        case 'warning': return 'bg-yellow-100 border-yellow-300 text-yellow-700';
        case 'critical': return 'bg-red-100 border-red-300 text-red-700';
        default: return 'bg-gray-100 border-gray-300 text-gray-700';
      }
    }
  };

  const handleCardClick = (query: string) => {
    router.push(`/project/${projectId}?query=${encodeURIComponent(query)}`);
  };

  return (
    <div className={darkMode ? 'min-h-screen bg-[#0a0f1e]' : 'min-h-screen bg-gray-50'}>
      {/* Top Bar */}
      <header className={`border-b ${darkMode ? 'border-gray-800 bg-[#0d1425]' : 'border-gray-200 bg-white'}`}>
        <div className="flex items-center justify-between px-5 py-3">
          <div className="flex items-center gap-3">
            <button
              onClick={() => router.push('/')}
              className={`p-1.5 rounded-lg transition-colors ${darkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-200'}`}
            >
              <ArrowLeft className={darkMode ? 'text-gray-400' : 'text-gray-600'} size={18} />
            </button>
            <h1 className={`text-lg font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>Analysis Report</h1>
          </div>
          <button
            onClick={() => setDarkMode(!darkMode)}
            className={`p-2 rounded-lg transition-colors ${darkMode ? 'bg-gray-800 text-yellow-400' : 'bg-gray-200 text-gray-700'}`}
          >
            {darkMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto px-5 py-6">
        {/* Report Header */}
        <div className={`mb-6 p-5 rounded-xl border ${darkMode ? 'bg-[#151b2e] border-gray-800' : 'bg-white border-gray-200'}`}>
          <div className="flex items-start gap-3">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center border flex-shrink-0 ${
              darkMode 
                ? 'bg-gradient-to-br from-emerald-500/20 to-teal-600/20 border-emerald-500/30'
                : 'bg-gradient-to-br from-emerald-100 to-teal-100 border-emerald-300'
            }`}>
              <FileText className={darkMode ? 'text-emerald-400' : 'text-emerald-600'} size={20} />
            </div>
            <div className="flex-1">
              <h2 className={`text-xl font-bold mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                Data Privacy Compliance Check
              </h2>
              <p className={`text-sm mb-3 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                Analyzed against UAE Personal Data Protection Law and GDPR standards
              </p>
              <div className="flex items-center gap-3 text-xs">
                <div className="flex items-center gap-1.5">
                  <div className={`w-2 h-2 rounded-full ${darkMode ? 'bg-emerald-400' : 'bg-emerald-600'}`}></div>
                  <span className={darkMode ? 'text-gray-300' : 'text-gray-700'}>2 Compliant</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className={`w-2 h-2 rounded-full ${darkMode ? 'bg-yellow-400' : 'bg-yellow-600'}`}></div>
                  <span className={darkMode ? 'text-gray-300' : 'text-gray-700'}>1 Warning</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className={`w-2 h-2 rounded-full ${darkMode ? 'bg-red-400' : 'bg-red-600'}`}></div>
                  <span className={darkMode ? 'text-gray-300' : 'text-gray-700'}>1 Critical</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Executive Summary */}
        <div className={`mb-6 rounded-xl p-5 border ${darkMode ? 'bg-[#151b2e] border-gray-800' : 'bg-white border-gray-200'}`}>
          <h3 className={`text-lg font-bold mb-3 ${darkMode ? 'text-white' : 'text-gray-900'}`}>Executive Summary</h3>
          
          <p className={`text-sm leading-relaxed mb-3 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
            The analysis reveals <strong className={darkMode ? 'text-emerald-400' : 'text-emerald-600'}>substantial compliance</strong> with 
            UAE PDPL and GDPR requirements for international data transfers to Germany.
          </p>

          <h4 className={`text-base font-semibold mt-4 mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>Key Findings</h4>
          
          <div className="space-y-3">
            <div className={`p-3 rounded-lg border ${darkMode ? 'bg-emerald-500/5 border-emerald-500/20' : 'bg-emerald-50 border-emerald-200'}`}>
              <div className="flex items-start gap-2">
                <CheckCircle className={`flex-shrink-0 mt-0.5 ${darkMode ? 'text-emerald-400' : 'text-emerald-600'}`} size={16} />
                <div>
                  <h5 className={`font-semibold text-sm mb-1 ${darkMode ? 'text-emerald-400' : 'text-emerald-700'}`}>Legal Basis Established</h5>
                  <p className={`text-xs ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    Germany recognized as "Adequate Jurisdiction" under UAE PDPL Article 28.
                  </p>
                </div>
              </div>
            </div>

            <div className={`p-3 rounded-lg border ${darkMode ? 'bg-yellow-500/5 border-yellow-500/20' : 'bg-yellow-50 border-yellow-200'}`}>
              <div className="flex items-start gap-2">
                <AlertTriangle className={`flex-shrink-0 mt-0.5 ${darkMode ? 'text-yellow-400' : 'text-yellow-600'}`} size={16} />
                <div>
                  <h5 className={`font-semibold text-sm mb-1 ${darkMode ? 'text-yellow-400' : 'text-yellow-700'}`}>TIA Required</h5>
                  <p className={`text-xs ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    Transfer Impact Assessment recommended for sensitive data categories.
                  </p>
                </div>
              </div>
            </div>

            <div className={`p-3 rounded-lg border ${darkMode ? 'bg-red-500/5 border-red-500/20' : 'bg-red-50 border-red-200'}`}>
              <div className="flex items-start gap-2">
                <AlertTriangle className={`flex-shrink-0 mt-0.5 ${darkMode ? 'text-red-400' : 'text-red-600'}`} size={16} />
                <div>
                  <h5 className={`font-semibold text-sm mb-1 ${darkMode ? 'text-red-400' : 'text-red-700'}`}>Explicit Consent Gap</h5>
                  <p className={`text-xs ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    <strong>Critical:</strong> No evidence of explicit user consent for EU data storage.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Metric Cards */}
        <div className="mb-6">
          <h3 className={`text-lg font-bold mb-3 ${darkMode ? 'text-white' : 'text-gray-900'}`}>Detailed Analysis</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {metrics.map((metric, index) => (
              <button
                key={index}
                onClick={() => handleCardClick(metric.link)}
                className={`group p-4 rounded-lg border transition-all text-left ${getStatusColor(metric.status)} hover:scale-[1.02]`}
              >
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 mt-0.5">
                    {getStatusIcon(metric.status)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className={`font-semibold text-sm mb-1 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{metric.title}</h4>
                    <p className={`text-xs mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{metric.message}</p>
                    <div className="flex items-center gap-1.5 text-xs opacity-70 group-hover:opacity-100 transition-opacity">
                      <span>Ask AI about this</span>
                      <ChevronRight size={14} />
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => router.push(`/project/${projectId}`)}
            className={`flex-1 px-5 py-2.5 text-sm rounded-lg font-medium shadow-lg transition-all ${
              darkMode
                ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white hover:from-emerald-600 hover:to-teal-700'
                : 'bg-gradient-to-r from-emerald-400 to-teal-500 text-white hover:from-emerald-500 hover:to-teal-600'
            }`}
          >
            Start Compliance Chat
          </button>
          <button
            onClick={() => router.push('/')}
            className={`px-5 py-2.5 text-sm rounded-lg transition-all border ${
              darkMode 
                ? 'bg-[#151b2e] text-gray-300 hover:bg-[#1a2235] border-gray-800'
                : 'bg-white text-gray-700 hover:bg-gray-50 border-gray-300'
            }`}
          >
            Back to Dashboard
          </button>
        </div>
      </main>
    </div>
  );
}
