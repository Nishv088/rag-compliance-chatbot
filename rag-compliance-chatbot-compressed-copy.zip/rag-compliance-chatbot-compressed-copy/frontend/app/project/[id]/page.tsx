//frontend/app/project/[id]/page.tsx
'use client';

import { useState, useEffect, useRef } from 'react';
import { useParams, useRouter, useSearchParams } from 'next/navigation';
import { 
  Send, Paperclip, Menu, RefreshCw, MessageSquare, 
  X, FileText, LayoutDashboard, Sun, Moon, Monitor, Loader2,
  Search, Upload, Trash2, AlertCircle, Info, Edit2
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeRaw from 'rehype-raw';
import { useTheme } from '@/contexts/ThemeContext';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  confidence?: number;
  citations?: Citation[];
  suggestions?: string[];
  followup_questions?: string[];
  timestamp: string;
  isStreaming?: boolean;
  files?: string[];
}

interface Citation {
  id: string;
  title: string;
  score: number;
  type?: 'compliance' | 'proposal';
  text?: string;
  section_no?: string;
  page_no?: string;
  document_name?: string;
  confidence?: number;
}

interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  lastUpdated?: string;
}

interface UploadedFile {
  name: string;
  size: number;
  type: string;
}

interface Project {
  id: string;
  name: string;
  description?: string;
}

const MAX_FILES = 5;

export default function ChatPage() {
  const params = useParams();
  const router = useRouter();
  const searchParams = useSearchParams();
  const { theme, setTheme, effectiveTheme } = useTheme();
  
  const projectId = params.id as string;
  const queryParam = searchParams.get('query');
  
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConvId, setCurrentConvId] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [streamingContent, setStreamingContent] = useState('');
  const [searchConv, setSearchConv] = useState('');
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [project, setProject] = useState<Project | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [hasProcessedQuery, setHasProcessedQuery] = useState(false);
  const [filesToAttach, setFilesToAttach] = useState<File[]>([]);
  const [showFileLimitError, setShowFileLimitError] = useState(false);
  const [hoveredCitation, setHoveredCitation] = useState<number | null>(null);
  const [isQueryProcessing, setIsQueryProcessing] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const processedQueryRef = useRef<string>('');

  // Fetch project details
  useEffect(() => {
    const fetchProject = async () => {
      try {
        const response = await fetch(`http://localhost:8000/api/projects/${projectId}`);
        if (response.ok) {
          const data = await response.json();
          setProject(data.project);
        }
      } catch (error) {
        console.error('Failed to fetch project:', error);
      }
    };
    fetchProject();
  }, [projectId]);

  // FIXED: Load ALL conversations from localStorage (not just current project)
  useEffect(() => {
    const loadAllConversations = () => {
      const allConvs: Conversation[] = [];
      
      // Scan all localStorage keys for conversations
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith('project_') && key.endsWith('_conversations')) {
          try {
            const convData = localStorage.getItem(key);
            if (convData) {
              const convs = JSON.parse(convData);
              allConvs.push(...convs);
            }
          } catch (error) {
            console.error(`Failed to parse ${key}:`, error);
          }
        }
      }
      
      return allConvs;
    };

    const allConversations = loadAllConversations();
    setConversations(allConversations);
    
    // Find conversation for current project or create new one
    const currentProjectConvs = allConversations.filter(c => 
      c.id.startsWith(`conv_${projectId}`) || c.id.includes(projectId)
    );
    
    if (currentProjectConvs.length > 0) {
      const latestConv = currentProjectConvs[0];
      setCurrentConvId(latestConv.id);
      if (latestConv.messages && latestConv.messages.length > 0) {
        setMessages(latestConv.messages);
      }
    } else {
      createNewConversation();
    }
  }, [projectId]);

  // Load messages for current conversation
  useEffect(() => {
    const currentConv = conversations.find(c => c.id === currentConvId);
    if (currentConv) {
      setMessages(currentConv.messages || []);
    }
  }, [currentConvId, conversations]);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, streamingContent]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [input]);

  // FIXED: Prevent duplicate query execution with ref check
  useEffect(() => {
    if (queryParam && !loading && !hasProcessedQuery && !isQueryProcessing) {
      // Check if this exact query was already processed
      if (processedQueryRef.current === queryParam) {
        console.log('⚠️ Query already processed, skipping:', queryParam);
        return;
      }

      console.log('🔵 Processing query param:', queryParam);
      setHasProcessedQuery(true);
      setIsQueryProcessing(true);
      processedQueryRef.current = queryParam;
      
      // Clear URL immediately
      window.history.replaceState({}, '', `/project/${projectId}`);
      
      // Send message after small delay
      setTimeout(() => {
        sendMessage(queryParam);
        setIsQueryProcessing(false);
      }, 200);
    }
  }, [queryParam]);

  // Reset query processing on navigation
  useEffect(() => {
    return () => {
      setHasProcessedQuery(false);
      setIsQueryProcessing(false);
      processedQueryRef.current = '';
    };
  }, [projectId]);

  // Auto-hide file limit error
  useEffect(() => {
    if (showFileLimitError) {
      const timer = setTimeout(() => setShowFileLimitError(false), 4000);
      return () => clearTimeout(timer);
    }
  }, [showFileLimitError]);

  const createNewConversation = () => {
    const newConv: Conversation = {
      id: `conv_${projectId}_${Date.now()}`,
      title: 'New Chat',
      messages: [],
      lastUpdated: new Date().toISOString()
    };
    const updatedConvs = [newConv, ...conversations];
    setConversations(updatedConvs);
    setCurrentConvId(newConv.id);
    setMessages([]);
    setUploadedFiles([]);
    setFilesToAttach([]);
    setHasProcessedQuery(false);
    processedQueryRef.current = '';
    saveConversations(updatedConvs);
  };

  const saveConversations = (convs: Conversation[]) => {
    // Group by project and save separately
    const projectConvs = convs.filter(c => c.id.includes(projectId));
    localStorage.setItem(`project_${projectId}_conversations`, JSON.stringify(projectConvs));
  };

  const deleteConversation = (convId: string) => {
    const updated = conversations.filter(c => c.id !== convId);
    setConversations(updated);
    saveConversations(updated);
    
    if (convId === currentConvId) {
      const projectConvs = updated.filter(c => c.id.includes(projectId));
      if (projectConvs.length > 0) {
        setCurrentConvId(projectConvs[0].id);
      } else {
        createNewConversation();
      }
    }
    setDeleteConfirm(null);
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const totalFiles = filesToAttach.length + files.length;
    if (totalFiles > MAX_FILES) {
      setShowFileLimitError(true);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      return;
    }

    setFilesToAttach(prev => [...prev, ...Array.from(files)]);
    setIsUploading(true);
    
    try {
      for (const file of Array.from(files)) {
        const formData = new FormData();
        formData.append('session_id', `${projectId}_${currentConvId}`);
        formData.append('file', file);

        const response = await fetch('http://localhost:8000/api/upload', {
          method: 'POST',
          body: formData
        });

        if (!response.ok) {
          throw new Error(`Upload failed for ${file.name}`);
        }

        const result = await response.json();
        
        setUploadedFiles(prev => [...prev, {
          name: file.name,
          size: file.size,
          type: result.type
        }]);
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert('Failed to upload some files');
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const removeFileToAttach = (index: number) => {
    setFilesToAttach(prev => prev.filter((_, i) => i !== index));
  };

  const sendMessage = async (messageText?: string) => {
    const text = messageText || input;
    if (!text.trim() || loading) return;

    // Prevent duplicate sends
    if (messages.length > 0 && messages[messages.length - 1].content === text && messages[messages.length - 1].role === 'user') {
      console.log('⚠️ Duplicate message detected, skipping');
      return;
    }

    const userMessage: Message = {
      role: 'user',
      content: text,
      timestamp: new Date().toISOString(),
      files: filesToAttach.map(f => f.name)
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);
    setFilesToAttach([]);

    // Auto-name conversation from first message
    if (messages.length === 0) {
      const autoTitle = text.length > 50 ? text.substring(0, 47) + '...' : text;
      const updatedConvs = conversations.map(c => 
        c.id === currentConvId 
          ? { ...c, title: autoTitle, lastUpdated: new Date().toISOString() }
          : c
      );
      setConversations(updatedConvs);
      saveConversations(updatedConvs);
    }

    // Add streaming placeholder
    const streamingMsg: Message = {
      role: 'assistant',
      content: '',
      timestamp: new Date().toISOString(),
      isStreaming: true
    };
    setMessages(prev => [...prev, streamingMsg]);

    try {
      const response = await fetch('http://localhost:8000/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          session_id: `${projectId}_${currentConvId}`,
          project_id: projectId,
          message: text,
          history: messages.map(m => ({
            role: m.role,
            content: m.content
          }))
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      // Simulate streaming effect
      await streamText(data.message.content, (chunk) => {
        setStreamingContent(chunk);
      });

      const assistantMsg: Message = {
        role: 'assistant',
        content: data.message.content,
        confidence: data.message.confidence,
        citations: data.message.citations || [],
        suggestions: data.message.suggestions || [],
        followup_questions: data.message.followup_questions || [],
        timestamp: new Date().toISOString()
      };

      // Update messages
      setMessages(prev => {
        const newMessages = prev.slice(0, -1);
        return [...newMessages, assistantMsg];
      });

      setStreamingContent('');
      
      // Save to localStorage
      const updatedConvs = conversations.map(c => 
        c.id === currentConvId
          ? { ...c, messages: [...messages, userMessage, assistantMsg], lastUpdated: new Date().toISOString() }
          : c
      );
      setConversations(updatedConvs);
      saveConversations(updatedConvs);
      
    } catch (error) {
      console.error('❌ Chat error:', error);
      setMessages(prev => {
        const newMessages = prev.slice(0, -1);
        return [...newMessages, {
          role: 'assistant',
          content: 'Sorry, I encountered an error. Please check if the backend server is running and try again.',
          timestamp: new Date().toISOString()
        }];
      });
      setStreamingContent('');
    } finally {
      setLoading(false);
    }
  };

  const streamText = async (text: string, callback: (chunk: string) => void) => {
    const words = text.split(' ');
    let accumulated = '';
    
    for (let i = 0; i < words.length; i++) {
      accumulated += (i > 0 ? ' ' : '') + words[i];
      callback(accumulated);
      await new Promise(resolve => setTimeout(resolve, 30));
    }
  };

  // FIXED: Filter conversations for current project only in sidebar
  const currentProjectConversations = conversations.filter(c => 
    c.id.includes(projectId)
  );
  
  const filteredConversations = currentProjectConversations.filter(c =>
    c.title.toLowerCase().includes(searchConv.toLowerCase())
  );

  return (
    <div className={`flex h-screen ${effectiveTheme === 'dark' ? 'bg-[#0a0f1e]' : 'bg-gray-50'}`}>
      {/* File Limit Error Notification */}
      {showFileLimitError && (
        <div className="fixed top-20 right-6 z-50 animate-slide-in">
          <div className="bg-red-500/20 border-2 border-red-500 rounded-lg px-4 py-3 shadow-2xl backdrop-blur-sm">
            <div className="flex items-center gap-3">
              <AlertCircle size={24} className="text-red-400 flex-shrink-0" />
              <div>
                <p className="text-red-100 font-semibold text-sm">Maximum {MAX_FILES} files allowed</p>
                <p className="text-red-200 text-xs">Please remove some files before uploading more</p>
              </div>
              <button
                onClick={() => setShowFileLimitError(false)}
                className="ml-2 p-1 hover:bg-red-500/30 rounded transition-colors"
              >
                <X size={16} className="text-red-300" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-0'} transition-all duration-300 ${
        effectiveTheme === 'dark' ? 'bg-[#0d1425]' : 'bg-white'
      } border-r ${effectiveTheme === 'dark' ? 'border-gray-800' : 'border-gray-200'} flex flex-col overflow-hidden`}>
        <div className={`p-3 border-b ${effectiveTheme === 'dark' ? 'border-gray-800' : 'border-gray-200'} space-y-2`}>
          <button
            onClick={() => router.push('/dashboard')}
            className={`w-full flex items-center justify-center gap-2 px-3 py-2.5 text-sm ${
              effectiveTheme === 'dark' ? 'bg-[#151b2e] text-white hover:bg-[#1a2235]' : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
            } rounded-lg transition-all border ${effectiveTheme === 'dark' ? 'border-gray-700' : 'border-gray-300'}`}
          >
            <LayoutDashboard size={18} />
            <span className="font-medium">Dashboard</span>
          </button>

          <button
            onClick={createNewConversation}
            className={`w-full flex items-center justify-center gap-2 px-3 py-2.5 text-sm ${
              effectiveTheme === 'dark' ? 'bg-gradient-to-r from-emerald-500 to-teal-600' : 'bg-gradient-to-r from-emerald-400 to-teal-500'
            } text-white rounded-lg font-medium hover:opacity-90 transition-all`}
          >
            <MessageSquare size={18} />
            New Chat
          </button>
        </div>

        <div className={`p-3 border-b ${effectiveTheme === 'dark' ? 'border-gray-800' : 'border-gray-200'}`}>
          <div className={`flex items-center gap-2 px-3 py-2 rounded-lg ${
            effectiveTheme === 'dark' ? 'bg-[#151b2e]' : 'bg-gray-100'
          }`}>
            <Search size={16} className={effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'} />
            <input
              type="text"
              placeholder="Search chats..."
              value={searchConv}
              onChange={(e) => setSearchConv(e.target.value)}
              className={`flex-1 bg-transparent border-none outline-none text-sm ${
                effectiveTheme === 'dark' ? 'text-white placeholder-gray-500' : 'text-gray-900 placeholder-gray-400'
              }`}
            />
          </div>
        </div>

        {/* FIXED: Conversations List with Edit/Delete */}
        <div className="flex-1 overflow-y-auto p-2">
          {filteredConversations.length === 0 ? (
            <p className={`text-center text-sm py-4 ${effectiveTheme === 'dark' ? 'text-gray-500' : 'text-gray-400'}`}>
              {searchConv ? 'No chats found' : 'No conversations yet'}
            </p>
          ) : (
            filteredConversations.map(conv => (
              <div
                key={conv.id}
                className={`relative group mb-1 rounded-lg transition-all ${
                  conv.id === currentConvId
                    ? effectiveTheme === 'dark' ? 'bg-emerald-500/20 border border-emerald-500/30' : 'bg-emerald-100 border border-emerald-300'
                    : effectiveTheme === 'dark' ? 'hover:bg-[#151b2e]' : 'hover:bg-gray-100'
                }`}
              >
                <button
                  onClick={() => setCurrentConvId(conv.id)}
                  className="w-full text-left px-3 py-2.5 rounded-lg"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm font-medium truncate ${
                        conv.id === currentConvId
                          ? effectiveTheme === 'dark' ? 'text-emerald-300' : 'text-emerald-700'
                          : effectiveTheme === 'dark' ? 'text-gray-300' : 'text-gray-700'
                      }`}>
                        {conv.title}
                      </p>
                      <p className={`text-xs ${
                        conv.id === currentConvId
                          ? effectiveTheme === 'dark' ? 'text-emerald-400/60' : 'text-emerald-600'
                          : effectiveTheme === 'dark' ? 'text-gray-500' : 'text-gray-500'
                      }`}>
                        {conv.messages.length} messages
                      </p>
                    </div>
                    
                    {/* Edit/Delete Buttons */}
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          // TODO: Implement edit title
                          const newTitle = prompt('Enter new title:', conv.title);
                          if (newTitle) {
                            const updated = conversations.map(c => 
                              c.id === conv.id ? { ...c, title: newTitle } : c
                            );
                            setConversations(updated);
                            saveConversations(updated);
                          }
                        }}
                        className={`p-1 rounded hover:bg-emerald-500/20 transition-colors ${
                          effectiveTheme === 'dark' ? 'text-emerald-400' : 'text-emerald-600'
                        }`}
                      >
                        <Edit2 size={12} />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setDeleteConfirm(conv.id);
                        }}
                        className={`p-1 rounded hover:bg-red-500/20 transition-colors ${
                          effectiveTheme === 'dark' ? 'text-red-400' : 'text-red-600'
                        }`}
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  </div>
                </button>
              </div>
            ))
          )}
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative">
        {/* Header */}
        <header className={`flex items-center justify-between px-4 py-3 border-b ${
          effectiveTheme === 'dark' ? 'border-gray-800 bg-[#0d1425]' : 'border-gray-200 bg-white'
        } z-10`}>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className={`p-1.5 ${
                effectiveTheme === 'dark' ? 'hover:bg-gray-800' : 'hover:bg-gray-100'
              } rounded-lg transition-colors`}
            >
              <Menu size={20} className={effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'} />
            </button>
            
            <div>
              <span className={`text-sm font-medium ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                {project ? project.name : `Project ${projectId}`}
              </span>
              {uploadedFiles.length > 0 && (
                <div className="flex items-center gap-1 mt-0.5">
                  <FileText size={12} className={effectiveTheme === 'dark' ? 'text-emerald-400' : 'text-emerald-600'} />
                  <span className={`text-xs ${effectiveTheme === 'dark' ? 'text-emerald-400' : 'text-emerald-600'}`}>
                    {uploadedFiles.length} file(s) attached
                  </span>
                </div>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {/* Theme Switcher */}
            <div className={`flex items-center rounded-lg border ${
              effectiveTheme === 'dark' ? 'bg-[#151b2e] border-gray-700' : 'bg-white border-gray-300'
            }`}>
              <button
                onClick={() => setTheme('light')}
                className={`p-1.5 rounded-l-lg transition-colors ${
                  theme === 'light'
                    ? effectiveTheme === 'dark' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-emerald-100 text-emerald-700'
                    : effectiveTheme === 'dark' ? 'text-gray-400 hover:text-gray-200' : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Sun size={16} />
              </button>
              <button
                onClick={() => setTheme('dark')}
                className={`p-1.5 transition-colors ${
                  theme === 'dark'
                    ? effectiveTheme === 'dark' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-emerald-100 text-emerald-700'
                    : effectiveTheme === 'dark' ? 'text-gray-400 hover:text-gray-200' : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Moon size={16} />
              </button>
              <button
                onClick={() => setTheme('system')}
                className={`p-1.5 rounded-r-lg transition-colors ${
                  theme === 'system'
                    ? effectiveTheme === 'dark' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-emerald-100 text-emerald-700'
                    : effectiveTheme === 'dark' ? 'text-gray-400 hover:text-gray-200' : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Monitor size={16} />
              </button>
            </div>

            <button
              onClick={() => router.push(`/project/${projectId}/analyze`)}
              className={`flex items-center gap-2 px-3 py-1.5 text-sm ${
                effectiveTheme === 'dark' ? 'bg-[#151b2e] text-emerald-400 border-emerald-500/30' : 'bg-emerald-50 text-emerald-600 border-emerald-200'
              } rounded-lg hover:opacity-80 transition-all border`}
            >
              <RefreshCw size={16} />
              <span className="font-medium">Analyze Proposal</span>
            </button>
          </div>
        </header>

        {/* Messages Area */}
        <div className="flex-1 relative overflow-hidden">
          <div className="absolute inset-0 overflow-y-auto pb-32">
            {messages.length === 0 ? (
              <div className="h-full flex items-center justify-center px-4">
                <div className="text-center max-w-2xl">
                  <div className={`w-16 h-16 mx-auto mb-5 rounded-xl ${
                    effectiveTheme === 'dark' ? 'bg-gradient-to-br from-emerald-500/20 to-teal-600/20 border-emerald-500/30' : 'bg-gradient-to-br from-emerald-100 to-teal-100 border-emerald-300'
                  } border flex items-center justify-center`}>
                    <MessageSquare size={32} className={effectiveTheme === 'dark' ? 'text-emerald-400' : 'text-emerald-600'} />
                  </div>
                  <h2 className={`text-2xl font-bold mb-3 ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    Dubai Compliance Assistant
                  </h2>
                  <p className={`text-base mb-6 ${effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                    Ask me anything about Dubai construction regulations and your proposal documents.
                  </p>
                  
                  <div className="flex flex-col gap-3 mt-8">
                    <button
                      onClick={() => router.push(`/project/${projectId}/analyze`)}
                      className={`flex items-center justify-center gap-3 px-6 py-4 rounded-xl border-2 transition-all ${
                        effectiveTheme === 'dark'
                          ? 'bg-[#0d1425] border-emerald-500/30 hover:border-emerald-500/50 text-white'
                          : 'bg-white border-emerald-300 hover:border-emerald-400 text-gray-900'
                      }`}
                    >
                      <Upload size={20} className={effectiveTheme === 'dark' ? 'text-emerald-400' : 'text-emerald-600'} />
                      <div className="text-left">
                        <p className="font-semibold text-sm">Analyze Proposal Documents</p>
                        <p className={`text-xs ${effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                          Upload PDFs for compliance analysis
                        </p>
                      </div>
                    </button>
                    
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      disabled={filesToAttach.length >= MAX_FILES}
                      className={`flex items-center justify-center gap-3 px-6 py-4 rounded-xl border-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
                        effectiveTheme === 'dark'
                          ? 'bg-[#0d1425] border-gray-700 hover:border-gray-600 text-white'
                          : 'bg-white border-gray-300 hover:border-gray-400 text-gray-900'
                      }`}
                    >
                      <Paperclip size={20} className={effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'} />
                      <div className="text-left">
                        <p className="font-semibold text-sm">Upload File for Chat</p>
                        <p className={`text-xs ${effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                          Ask questions about a specific document (Max {MAX_FILES} files)
                        </p>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
                {messages.map((msg, idx) => (
                  <div key={idx} className="flex gap-3 items-start">
                    {msg.role === 'assistant' && (
                      <div className={`w-7 h-7 rounded-full ${
                        effectiveTheme === 'dark' ? 'bg-gradient-to-br from-emerald-500 to-teal-600' : 'bg-gradient-to-br from-emerald-400 to-teal-500'
                      } flex items-center justify-center flex-shrink-0`}>
                        <MessageSquare size={14} className="text-white" />
                      </div>
                    )}
                    
                    <div className="flex-1">
                      {msg.role === 'user' ? (
                        <div className="flex justify-end">
                          <div>
                            {msg.files && msg.files.length > 0 && (
                              <div className="mb-2 flex flex-wrap gap-1 justify-end">
                                {msg.files.map((fileName, i) => (
                                  <div
                                    key={i}
                                    className={`flex items-center gap-1 px-2 py-1 rounded text-xs ${
                                      effectiveTheme === 'dark' ? 'bg-emerald-600/30 text-emerald-200' : 'bg-emerald-200 text-emerald-800'
                                    }`}
                                  >
                                    <Paperclip size={10} />
                                    <span>{fileName}</span>
                                  </div>
                                ))}
                              </div>
                            )}
                            <div className={`inline-block rounded-2xl px-4 py-2.5 ${
                              effectiveTheme === 'dark' ? 'bg-gradient-to-r from-emerald-500 to-teal-600' : 'bg-gradient-to-r from-emerald-400 to-teal-500'
                            } text-white text-sm leading-relaxed max-w-2xl break-words`}>
                              {msg.content}
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {msg.confidence && (
                            <div className="flex items-center gap-2 mb-2">
                              <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                                msg.confidence >= 90 ? effectiveTheme === 'dark' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-emerald-100 text-emerald-700' :
                                msg.confidence >= 70 ? effectiveTheme === 'dark' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-yellow-100 text-yellow-700' :
                                effectiveTheme === 'dark' ? 'bg-red-500/20 text-red-400' : 'bg-red-100 text-red-700'
                              }`}>
                                {msg.confidence}% Confidence
                              </span>
                            </div>
                          )}
                          
                          {/* FIXED: Better Markdown Formatting */}
                          <div className={`prose prose-sm max-w-none ${effectiveTheme === 'dark' ? 'prose-invert' : ''}`}>
                            <ReactMarkdown 
                              remarkPlugins={[remarkGfm]}
                              rehypePlugins={[rehypeRaw]}
                              components={{
                                h2: ({node, ...props}) => (
                                  <h2 className={`text-lg font-bold mt-6 mb-3 ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`} {...props} />
                                ),
                                h3: ({node, ...props}) => (
                                  <h3 className={`text-base font-semibold mt-4 mb-2 ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`} {...props} />
                                ),
                                p: ({node, ...props}) => (
                                  <p className={`my-3 leading-relaxed ${effectiveTheme === 'dark' ? 'text-gray-200' : 'text-gray-800'}`} {...props} />
                                ),
                                ol: ({node, ...props}) => (
                                  <ol className={`list-decimal list-outside ml-6 my-3 space-y-2 ${effectiveTheme === 'dark' ? 'text-gray-200' : 'text-gray-800'}`} {...props} />
                                ),
                                ul: ({node, ...props}) => (
                                  <ul className={`list-disc list-outside ml-6 my-3 space-y-2 ${effectiveTheme === 'dark' ? 'text-gray-200' : 'text-gray-800'}`} {...props} />
                                ),
                                li: ({node, ...props}) => (
                                  <li className="leading-relaxed" {...props} />
                                ),
                                strong: ({node, ...props}) => (
                                  <strong className={`font-bold ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`} {...props} />
                                ),
                                code: ({node, inline, ...props}: any) => 
                                  inline ? (
                                    <code className={`px-1.5 py-0.5 rounded text-xs font-mono ${
                                      effectiveTheme === 'dark' ? 'bg-gray-800 text-emerald-300' : 'bg-gray-200 text-emerald-700'
                                    }`} {...props} />
                                  ) : (
                                    <code className={`block p-3 rounded-lg text-xs font-mono my-2 overflow-x-auto ${
                                      effectiveTheme === 'dark' ? 'bg-gray-900 text-gray-200' : 'bg-gray-100 text-gray-800'
                                    }`} {...props} />
                                  ),
                              }}
                            >
                              {msg.isStreaming ? streamingContent : msg.content}
                            </ReactMarkdown>
                            {msg.isStreaming && <span className="inline-block w-1 h-4 bg-emerald-500 animate-pulse ml-1"></span>}
                          </div>

                          {/* FIXED: Compact 3×3 Sources Grid */}
                          {!msg.isStreaming && msg.citations && msg.citations.length > 0 && (
                            <div className={`mt-6 pt-4 border-t ${effectiveTheme === 'dark' ? 'border-gray-800' : 'border-gray-200'}`}>
                              <h4 className={`text-xs font-semibold mb-3 uppercase tracking-wide ${
                                effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                              }`}>
                                Sources ({msg.citations.length})
                              </h4>
                              <div className="grid grid-cols-3 gap-2">
                                {msg.citations.map((citation, i) => {
                                  // FIXED: Use confidence from citation, fallback to score
                                  const confidenceScore = citation.confidence || citation.score * 100;
                                  const isValidScore = !isNaN(confidenceScore) && isFinite(confidenceScore);
                                  
                                  return (
                                    <div
                                      key={i}
                                      className="relative group"
                                      onMouseEnter={() => setHoveredCitation(i)}
                                      onMouseLeave={() => setHoveredCitation(null)}
                                    >
                                      {/* Compact Card */}
                                      <div className={`p-2.5 rounded-lg border transition-all cursor-pointer ${
                                        effectiveTheme === 'dark'
                                          ? 'bg-gray-800/50 border-gray-700 hover:bg-emerald-500/10 hover:border-emerald-500/50'
                                          : 'bg-gray-50 border-gray-200 hover:bg-emerald-50 hover:border-emerald-300'
                                      }`}>
                                        <div className="flex items-start justify-between gap-2 mb-1.5">
                                          <span className={`text-xs font-mono px-1.5 py-0.5 rounded font-semibold ${
                                            effectiveTheme === 'dark' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-emerald-100 text-emerald-700'
                                          }`}>
                                            {citation.id}
                                          </span>
                                          {citation.type && (
                                            <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                                              citation.type === 'proposal'
                                                ? effectiveTheme === 'dark' ? 'bg-blue-500/20 text-blue-300' : 'bg-blue-100 text-blue-700'
                                                : effectiveTheme === 'dark' ? 'bg-purple-500/20 text-purple-300' : 'bg-purple-100 text-purple-700'
                                            }`}>
                                              {citation.type === 'proposal' ? 'P' : 'R'}
                                            </span>
                                          )}
                                        </div>
                                        <p className={`text-xs font-semibold truncate ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                                          {citation.section_no || 'N/A'}
                                        </p>
                                        {isValidScore && (
                                          <span className={`text-[10px] ${effectiveTheme === 'dark' ? 'text-gray-500' : 'text-gray-400'}`}>
                                            {confidenceScore.toFixed(0)}%
                                          </span>
                                        )}
                                      </div>

                                      {/* Hover Tooltip */}
                                      {hoveredCitation === i && (
                                        <div className={`absolute left-0 top-full mt-2 z-50 w-80 p-4 rounded-lg border shadow-2xl ${
                                          effectiveTheme === 'dark' ? 'bg-gray-900 border-emerald-500/50' : 'bg-white border-emerald-300'
                                        }`}>
                                          <div className="flex items-center gap-2 mb-2">
                                            <span className={`text-xs font-mono px-1.5 py-0.5 rounded font-semibold ${
                                              effectiveTheme === 'dark' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-emerald-100 text-emerald-700'
                                            }`}>
                                              {citation.id}
                                            </span>
                                            {citation.type && (
                                              <span className={`text-xs px-2 py-0.5 rounded-full ${
                                                citation.type === 'proposal'
                                                  ? effectiveTheme === 'dark' ? 'bg-blue-500/20 text-blue-300' : 'bg-blue-100 text-blue-700'
                                                  : effectiveTheme === 'dark' ? 'bg-purple-500/20 text-purple-300' : 'bg-purple-100 text-purple-700'
                                              }`}>
                                                {citation.type === 'proposal' ? 'Proposal' : 'Regulation'}
                                              </span>
                                            )}
                                            <Info size={12} className={effectiveTheme === 'dark' ? 'text-emerald-400' : 'text-emerald-600'} />
                                          </div>
                                          <p className={`text-sm font-semibold mb-2 ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                                            {citation.title}
                                          </p>
                                          <div className={`text-xs space-y-1 ${effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                                            <p><strong>Section:</strong> {citation.section_no || 'N/A'}</p>
                                            <p><strong>Page:</strong> {citation.page_no || 'N/A'}</p>
                                            {citation.document_name && citation.document_name !== 'Unknown' && (
                                              <p><strong>Document:</strong> {citation.document_name}</p>
                                            )}
                                            {citation.text && (
                                              <p className="mt-2 text-[11px] leading-tight line-clamp-3">{citation.text.substring(0, 200)}...</p>
                                            )}
                                          </div>
                                          {isValidScore && (
                                            <div className={`mt-3 pt-2 border-t ${effectiveTheme === 'dark' ? 'border-gray-800' : 'border-gray-200'}`}>
                                              <span className={`text-xs font-semibold ${effectiveTheme === 'dark' ? 'text-emerald-400' : 'text-emerald-600'}`}>
                                                Confidence: {confidenceScore.toFixed(1)}%
                                              </span>
                                            </div>
                                          )}
                                        </div>
                                      )}
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          )}

                          {/* FIXED: Follow-up Questions (Only for Latest Message) */}
                          {!msg.isStreaming && msg.followup_questions && msg.followup_questions.length > 0 && idx === messages.length - 1 && (
                            <div className={`mt-6 pt-4 border-t ${effectiveTheme === 'dark' ? 'border-gray-800' : 'border-gray-200'}`}>
                              <h4 className={`text-xs font-semibold mb-3 uppercase tracking-wide flex items-center gap-2 ${
                                effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                              }`}>
                                <MessageSquare size={14} />
                                Follow-up Questions
                              </h4>
                              <div className="space-y-2">
                                {msg.followup_questions.map((question, i) => (
                                  <button
                                    key={i}
                                    onClick={() => {
                                      setInput(question);
                                      textareaRef.current?.focus();
                                    }}
                                    disabled={loading}
                                    className={`w-full text-left px-4 py-3 rounded-lg text-sm border transition-all disabled:opacity-50 ${
                                      effectiveTheme === 'dark' 
                                        ? 'bg-[#151b2e] text-gray-200 border-gray-700 hover:bg-[#1a2235] hover:border-emerald-500/50' 
                                        : 'bg-gray-50 text-gray-800 border-gray-200 hover:bg-white hover:border-emerald-300'
                                    }`}
                                  >
                                    <span className={effectiveTheme === 'dark' ? 'text-emerald-400' : 'text-emerald-600'}>→</span> {question}
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {msg.role === 'user' && (
                      <div className={`w-7 h-7 rounded-full ${
                        effectiveTheme === 'dark' ? 'bg-gradient-to-br from-blue-500 to-indigo-600' : 'bg-gradient-to-br from-blue-400 to-indigo-500'
                      } flex items-center justify-center flex-shrink-0`}>
                        <span className="text-white font-bold text-xs">U</span>
                      </div>
                    )}
                  </div>
                ))}
                
                <div ref={messagesEndRef} />
              </div>
            )}
          </div>

          <div className={`absolute bottom-0 left-0 right-0 h-32 pointer-events-none ${
            effectiveTheme === 'dark' ? 'bg-gradient-to-t from-[#0a0f1e] via-[#0a0f1e]/80 to-transparent' : 'bg-gradient-to-t from-gray-50 via-gray-50/80 to-transparent'
          }`} />
        </div>

        {/* Input Area */}
        <div className="absolute bottom-0 left-0 right-0 z-20">
          <div className="max-w-4xl mx-auto px-4 pb-4">
            <div className="relative">
              {filesToAttach.length > 0 && (
                <div className={`absolute bottom-full left-0 right-0 mb-2 p-2 rounded-lg border max-h-24 overflow-y-auto ${
                  effectiveTheme === 'dark' ? 'bg-[#0d1425] border-gray-700' : 'bg-white border-gray-300'
                }`}>
                  <div className="flex flex-wrap gap-2">
                    {filesToAttach.map((file, index) => (
                      <div
                        key={index}
                        className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm ${
                          effectiveTheme === 'dark' ? 'bg-[#151b2e] text-gray-300 border border-gray-700' : 'bg-gray-100 text-gray-700 border border-gray-300'
                        }`}
                      >
                        <Paperclip size={14} />
                        <span className="truncate max-w-[150px]">{file.name}</span>
                        <button
                          onClick={() => removeFileToAttach(index)}
                          className="hover:text-red-400 transition-colors"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              <div className={`flex items-end gap-2 rounded-xl px-3 py-2 border ${
                effectiveTheme === 'dark' ? 'bg-[#0d1425] border-gray-700 hover:border-gray-600' : 'bg-white border-gray-300 hover:border-gray-400'
              } transition-colors shadow-lg`}>
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  accept=".pdf,.docx,.doc,.txt,image/*"
                  multiple
                  onChange={handleFileSelect}
                />
                <button
                  onClick={() => {
                    if (filesToAttach.length >= MAX_FILES) {
                      setShowFileLimitError(true);
                    } else {
                      fileInputRef.current?.click();
                    }
                  }}
                  disabled={isUploading || loading}
                  className={`p-2 ${
                    effectiveTheme === 'dark' ? 'hover:bg-gray-800' : 'hover:bg-gray-100'
                  } rounded-lg transition-colors flex-shrink-0 disabled:opacity-50 ${
                    filesToAttach.length >= MAX_FILES ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                >
                  {isUploading ? (
                    <Loader2 size={18} className={`${effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'} animate-spin`} />
                  ) : (
                    <Paperclip size={18} className={effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'} />
                  )}
                </button>

                <textarea
                  ref={textareaRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      sendMessage();
                    }
                  }}
                  placeholder="Ask about compliance requirements..."
                  className={`flex-1 bg-transparent border-none outline-none resize-none text-sm ${
                    effectiveTheme === 'dark' ? 'text-gray-100 placeholder-gray-500' : 'text-gray-900 placeholder-gray-400'
                  } max-h-32 py-2`}
                  rows={1}
                  disabled={loading}
                />

                <button
                  onClick={() => sendMessage()}
                  disabled={!input.trim() || loading}
                  className={`p-2 rounded-lg transition-all flex-shrink-0 ${
                    effectiveTheme === 'dark'
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white hover:shadow-lg disabled:opacity-50'
                      : 'bg-gradient-to-r from-emerald-400 to-teal-500 text-white hover:shadow-lg disabled:opacity-50'
                  }`}
                >
                  {loading ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
                </button>
              </div>
            </div>
            
            <p className={`text-xs text-center mt-2 ${effectiveTheme === 'dark' ? 'text-gray-500' : 'text-gray-400'}`}>
              AI can make mistakes. Verify critical compliance data. {filesToAttach.length > 0 && `(${filesToAttach.length}/${MAX_FILES} files)`}
            </p>
          </div>
        </div>
      </main>

      {/* Delete Confirmation Modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className={`w-full max-w-sm rounded-xl p-6 ${
            effectiveTheme === 'dark' ? 'bg-[#0d1425]' : 'bg-white'
          }`}>
            <h2 className={`text-lg font-bold mb-3 ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              Delete Chat?
            </h2>
            <p className={`text-sm mb-6 ${effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
              This conversation will be permanently deleted.
            </p>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setDeleteConfirm(null)}
                className={`flex-1 px-4 py-2 rounded-lg font-medium ${
                  effectiveTheme === 'dark'
                    ? 'bg-gray-800 text-white hover:bg-gray-700'
                    : 'bg-gray-200 text-gray-900 hover:bg-gray-300'
                }`}
              >
                Cancel
              </button>
              <button
                onClick={() => deleteConfirm && deleteConversation(deleteConfirm)}
                className="flex-1 px-4 py-2 rounded-lg font-medium bg-red-600 text-white hover:bg-red-700"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
