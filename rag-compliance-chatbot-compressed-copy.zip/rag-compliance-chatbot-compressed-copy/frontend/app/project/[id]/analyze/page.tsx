//frontend\app\project\[id]\analyze\page.tsx
'use client';

import { useState, useRef, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { 
  Upload, FileText, X, AlertCircle, CheckCircle, 
  Loader2, ChevronLeft, MessageSquare, TrendingUp, AlertTriangle,
  FileCheck, Shield, Target
} from 'lucide-react';
import { useTheme } from '@/contexts/ThemeContext';

interface UploadedFile {
  file: File;
  path: string;
  status: 'pending' | 'uploading' | 'success' | 'error';
}

interface AnalysisLog {
  timestamp: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
}

interface CoveragePoint {
  title: string;
  summary: string;
  source: string;
}

interface Gap {
  area: string;
  issue: string;
  source: string;
}

interface Recommendation {
  priority: number;
  title: string;
  recommendation: string;
}

interface AnalysisReport {
  document_info: {
    report_title: string;
    date: string;
    file_name?: string;
    file_names?: string[];
    page_count: number;
    batch_analysis?: boolean;
  };
  compliance_coverage_assessment: {
    overview: string;
    coverage_points: CoveragePoint[];
  };
  key_gaps_identified: Gap[];
  risk_level: {
    assessment: string;
    reasoning: string;
  };
  top_recommendations: Recommendation[];
}

export default function ProposalAnalyzePage() {
  const router = useRouter();
  const params = useParams();
  const { effectiveTheme } = useTheme();
  const projectId = params.id as string;
  
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisLogs, setAnalysisLogs] = useState<AnalysisLog[]>([]);
  const [report, setReport] = useState<AnalysisReport | null>(null);
  const [expandedGaps, setExpandedGaps] = useState<Set<number>>(new Set());
  const [expandedRecs, setExpandedRecs] = useState<Set<number>>(new Set());
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const logsEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll logs
  useEffect(() => {
    if (logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [analysisLogs]);

  // Load existing report if available
  useEffect(() => {
    loadExistingReport();
  }, [projectId]);

  const loadExistingReport = async () => {
    try {
      const response = await fetch(`http://localhost:8000/api/proposals/report/${projectId}`);
      if (response.ok) {
        const data = await response.json();
        if (data.success && data.report) {
          setReport(data.report);
        }
      }
    } catch (error) {
      console.log('No existing report found');
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;

    const files = Array.from(e.target.files);
    const validFiles = files.filter(file => {
      const ext = file.name.split('.').pop()?.toLowerCase();
      return ['pdf', 'doc', 'docx'].includes(ext || '');
    });

    if (validFiles.length !== files.length) {
      alert('Some files were skipped. Only PDF, DOC, and DOCX files are supported.');
    }

    const newFiles: UploadedFile[] = validFiles.map(file => ({
      file,
      path: '',
      status: 'pending'
    }));

    setUploadedFiles(prev => [...prev, ...newFiles]);
  };

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const addLog = (message: string, type: AnalysisLog['type'] = 'info') => {
    setAnalysisLogs(prev => [...prev, {
      timestamp: new Date().toLocaleTimeString(),
      message,
      type
    }]);
  };

  const uploadAndAnalyze = async () => {
    if (uploadedFiles.length === 0) {
      alert('Please upload at least one document');
      return;
    }

    setIsAnalyzing(true);
    setAnalysisLogs([]);
    setReport(null);

    addLog('🚀 Starting analysis pipeline...', 'info');
    addLog(`📄 Processing ${uploadedFiles.length} document(s)`, 'info');

    try {
      // Step 1: Upload files
      const formData = new FormData();
      formData.append('project_id', projectId);
      uploadedFiles.forEach(f => formData.append('files', f.file));

      addLog('📤 Uploading files to server...', 'info');
      const uploadResponse = await fetch('http://localhost:8000/api/proposals/upload', {
        method: 'POST',
        body: formData
      });

      if (!uploadResponse.ok) {
        throw new Error(`Upload failed: ${uploadResponse.statusText}`);
      }
      
      const uploadData = await uploadResponse.json();
      
      // Update file statuses
      uploadData.files.forEach((f: any, i: number) => {
        setUploadedFiles(prev => {
          const updated = [...prev];
          if (updated[i]) {
            updated[i] = { ...updated[i], path: f.path, status: 'success' };
          }
          return updated;
        });
      });

      addLog('✅ Files uploaded successfully', 'success');
      addLog('🔍 Searching Dubai compliance database...', 'info');
      
      await new Promise(resolve => setTimeout(resolve, 1000));

      addLog('📚 Retrieved compliance regulations', 'success');
      addLog('🤖 AI analyzing compliance gaps...', 'info');

      // Step 2: Analyze
      const analyzeFormData = new FormData();
      analyzeFormData.append('project_id', projectId);
      analyzeFormData.append('conversation_id', `conv_${Date.now()}`);
      uploadData.files.forEach((f: any) => analyzeFormData.append('file_paths', f.path));

      const analyzeResponse = await fetch('http://localhost:8000/api/proposals/analyze', {
        method: 'POST',
        body: analyzeFormData
      });

      if (!analyzeResponse.ok) {
        const errorData = await analyzeResponse.json().catch(() => ({}));
        throw new Error(errorData.detail || errorData.error || 'Analysis failed');
      }
      
      const result = await analyzeResponse.json();

      if (!result.success || result.error) {
        throw new Error(result.error || 'Analysis failed');
      }

      addLog('✅ Analysis completed successfully', 'success');
      addLog('📋 Generated comprehensive compliance report', 'success');
      addLog('💾 Stored in vector database for chat context', 'success');

      setReport(result.report);

    } catch (error: any) {
      addLog(`❌ Analysis failed: ${error.message}`, 'error');
      console.error('Analysis error:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleChatAboutSection = (sectionTitle: string, content: string) => {
  const query = `Tell me more about: ${sectionTitle}. ${content}`;
  // FIX: Use window.location.href instead of router.push to prevent duplicate requests
  window.location.href = `/project/${projectId}?query=${encodeURIComponent(query)}`;
};

  const toggleGap = (index: number) => {
    setExpandedGaps(prev => {
      const newSet = new Set(prev);
      if (newSet.has(index)) {
        newSet.delete(index);
      } else {
        newSet.add(index);
      }
      return newSet;
    });
  };

  const toggleRec = (index: number) => {
    setExpandedRecs(prev => {
      const newSet = new Set(prev);
      if (newSet.has(index)) {
        newSet.delete(index);
      } else {
        newSet.add(index);
      }
      return newSet;
    });
  };

  const getFileIcon = (filename: string) => {
    const ext = filename.split('.').pop()?.toLowerCase();
    if (ext === 'pdf') return '📄';
    if (ext === 'doc' || ext === 'docx') return '📝';
    return '📎';
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'Low':
        return effectiveTheme === 'dark' 
          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
          : 'bg-emerald-100 text-emerald-700 border-emerald-300';
      case 'Medium':
        return effectiveTheme === 'dark'
          ? 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30'
          : 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'High':
        return effectiveTheme === 'dark'
          ? 'bg-red-500/20 text-red-300 border-red-500/30'
          : 'bg-red-100 text-red-700 border-red-300';
      default:
        return effectiveTheme === 'dark'
          ? 'bg-gray-700 text-gray-300 border-gray-600'
          : 'bg-gray-200 text-gray-700 border-gray-300';
    }
  };

  const getPriorityColor = (priority: number) => {
    if (priority === 1) {
      return effectiveTheme === 'dark' 
        ? 'bg-red-500/20 text-red-300 border-red-500/30'
        : 'bg-red-100 text-red-700 border-red-300';
    } else if (priority === 2) {
      return effectiveTheme === 'dark'
        ? 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30'
        : 'bg-yellow-100 text-yellow-700 border-yellow-300';
    } else {
      return effectiveTheme === 'dark'
        ? 'bg-blue-500/20 text-blue-300 border-blue-500/30'
        : 'bg-blue-100 text-blue-700 border-blue-300';
    }
  };

  return (
    <div className={`min-h-screen ${effectiveTheme === 'dark' ? 'bg-[#0a0f1e]' : 'bg-gray-50'}`}>
      {/* Header */}
      <header className={`border-b ${effectiveTheme === 'dark' ? 'bg-[#0d1425] border-gray-800' : 'bg-white border-gray-200'}`}>
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => router.push('/dashboard')}
              className={`p-2 rounded-lg transition-colors ${
                effectiveTheme === 'dark' ? 'hover:bg-gray-800' : 'hover:bg-gray-100'
              }`}
            >
              <ChevronLeft size={20} className={effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'} />
            </button>
            <div>
              <h1 className={`text-xl font-bold ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                Proposal Analysis
              </h1>
              <p className={`text-sm ${effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                Upload and analyze project proposal documents
              </p>
            </div>
          </div>

          <button
            onClick={() => router.push(`/project/${projectId}`)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg border transition-colors ${
              effectiveTheme === 'dark'
                ? 'bg-[#151b2e] border-gray-700 text-white hover:border-emerald-500/50'
                : 'bg-white border-gray-300 text-gray-900 hover:border-emerald-400'
            }`}
          >
            <MessageSquare size={18} />
            Go to Chat
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {!report ? (
          <>
            {/* Upload Section */}
            <div className={`p-8 rounded-xl border-2 border-dashed mb-6 transition-all ${
              effectiveTheme === 'dark'
                ? 'bg-[#0d1425] border-gray-700 hover:border-emerald-500/50'
                : 'bg-white border-gray-300 hover:border-emerald-400'
            }`}>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept=".pdf,.doc,.docx"
                onChange={handleFileSelect}
                className="hidden"
              />

              <div className="text-center">
                <Upload size={48} className={`mx-auto mb-4 ${effectiveTheme === 'dark' ? 'text-gray-600' : 'text-gray-400'}`} />
                <h3 className={`text-base font-semibold mb-2 ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  Upload Proposal Documents
                </h3>
                <p className={`text-sm mb-4 ${effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                  Supported formats: PDF, DOC, DOCX • Max 10 files
                </p>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isAnalyzing}
                  className={`px-6 py-2 rounded-lg font-medium transition-colors disabled:opacity-50 ${
                    effectiveTheme === 'dark'
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white hover:opacity-90'
                      : 'bg-gradient-to-r from-emerald-400 to-teal-500 text-white hover:opacity-90'
                  }`}
                >
                  Select Files
                </button>
              </div>
            </div>

            {/* Uploaded Files Grid */}
            {uploadedFiles.length > 0 && (
              <div className="mb-6">
                <h3 className={`text-base font-semibold mb-4 ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  Uploaded Files ({uploadedFiles.length})
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {uploadedFiles.map((fileObj, index) => (
                    <div
                      key={index}
                      className={`p-4 rounded-lg border transition-all ${
                        effectiveTheme === 'dark' ? 'bg-[#0d1425] border-gray-800' : 'bg-white border-gray-200'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className="text-3xl">{getFileIcon(fileObj.file.name)}</div>
                        <div className="flex-1 min-w-0">
                          <p className={`text-sm font-medium truncate ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                            {fileObj.file.name}
                          </p>
                          <p className={`text-xs ${effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                            {(fileObj.file.size / 1024 / 1024).toFixed(2)} MB
                          </p>
                          
                          {/* Status Indicator */}
                          <div className="mt-2 flex items-center gap-2">
                            {fileObj.status === 'pending' && (
                              <span className={`text-xs ${effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                                Ready to upload
                              </span>
                            )}
                            {fileObj.status === 'uploading' && (
                              <>
                                <Loader2 size={14} className="text-blue-400 animate-spin" />
                                <span className="text-xs text-blue-400">Uploading...</span>
                              </>
                            )}
                            {fileObj.status === 'success' && (
                              <>
                                <CheckCircle size={14} className={effectiveTheme === 'dark' ? 'text-emerald-400' : 'text-emerald-600'} />
                                <span className={`text-xs ${effectiveTheme === 'dark' ? 'text-emerald-400' : 'text-emerald-600'}`}>
                                  Ready
                                </span>
                              </>
                            )}
                            {fileObj.status === 'error' && (
                              <>
                                <AlertCircle size={14} className="text-red-400" />
                                <span className="text-xs text-red-400">Failed</span>
                              </>
                            )}
                          </div>
                        </div>
                        
                        <button
                          onClick={() => removeFile(index)}
                          disabled={isAnalyzing}
                          className={`p-1 rounded hover:bg-gray-800 transition-colors disabled:opacity-50`}
                        >
                          <X size={16} className={effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Analyze Button */}
            {uploadedFiles.length > 0 && !isAnalyzing && (
              <div className="flex justify-center mb-8">
                <button
                  onClick={uploadAndAnalyze}
                  className={`px-8 py-3 rounded-lg font-semibold text-base transition-all shadow-lg ${
                    effectiveTheme === 'dark'
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white hover:shadow-xl'
                      : 'bg-gradient-to-r from-emerald-400 to-teal-500 text-white hover:shadow-xl'
                  }`}
                >
                  🚀 Analyze Documents
                </button>
              </div>
            )}

            {/* Analysis Progress */}
            {isAnalyzing && (
              <div className={`p-6 rounded-xl border ${
                effectiveTheme === 'dark' ? 'bg-[#0d1425] border-gray-800' : 'bg-white border-gray-200'
              }`}>
                <div className="flex items-center gap-3 mb-4">
                  <Loader2 size={24} className={`${effectiveTheme === 'dark' ? 'text-emerald-400' : 'text-emerald-600'} animate-spin`} />
                  <h3 className={`text-base font-semibold ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    Analyzing Documents...
                  </h3>
                </div>

                <div className={`max-h-96 overflow-y-auto space-y-2 p-4 rounded-lg ${
                  effectiveTheme === 'dark' ? 'bg-[#151b2e]' : 'bg-gray-50'
                }`}>
                  {analysisLogs.map((log, index) => (
                    <div
                      key={index}
                      className={`text-sm flex items-start gap-2 ${
                        log.type === 'error' ? 'text-red-400' :
                        log.type === 'success' ? effectiveTheme === 'dark' ? 'text-emerald-400' : 'text-emerald-600' :
                        log.type === 'warning' ? 'text-yellow-400' :
                        effectiveTheme === 'dark' ? 'text-gray-300' : 'text-gray-700'
                      }`}
                    >
                      <span className={`text-xs ${effectiveTheme === 'dark' ? 'text-gray-500' : 'text-gray-400'} min-w-[60px]`}>
                        {log.timestamp}
                      </span>
                      <span className="flex-1">{log.message}</span>
                    </div>
                  ))}
                  <div ref={logsEndRef} />
                </div>
              </div>
            )}
          </>
        ) : (
          /* Analysis Report - Make sections clickable */
          <div className="space-y-6">
            {/* Report Header */}
            <div className={`p-6 rounded-xl border ${
              effectiveTheme === 'dark' ? 'bg-[#0d1425] border-gray-800' : 'bg-white border-gray-200'
            }`}>
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h2 className={`text-xl font-bold mb-2 ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    {report.document_info.report_title}
                  </h2>
                  <div className={`flex flex-wrap items-center gap-4 text-sm ${effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                    {report.document_info.batch_analysis && report.document_info.file_names ? (
                      <span>📚 {report.document_info.file_names.length} documents analyzed</span>
                    ) : (
                      <span>📄 {report.document_info.file_name}</span>
                    )}
                    <span>📊 {report.document_info.page_count} pages</span>
                    <span>📅 {new Date(report.document_info.date).toLocaleString()}</span>
                  </div>
                </div>
                
                <div className={`px-4 py-2 rounded-lg border-2 ${getRiskColor(report.risk_level.assessment)}`}>
                  <span className="font-semibold text-sm">{report.risk_level.assessment} Risk</span>
                </div>
              </div>

              {/* File Names List (if batch) */}
              {report.document_info.batch_analysis && report.document_info.file_names && (
                <div className={`mt-4 p-3 rounded-lg ${effectiveTheme === 'dark' ? 'bg-[#151b2e]' : 'bg-gray-50'}`}>
                  <p className={`text-xs font-semibold mb-2 ${effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                    ANALYZED DOCUMENTS:
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {report.document_info.file_names.map((name, i) => (
                      <span
                        key={i}
                        className={`text-xs px-2 py-1 rounded ${
                          effectiveTheme === 'dark' ? 'bg-gray-800 text-gray-300' : 'bg-white text-gray-700'
                        }`}
                      >
                        {name}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Risk Assessment Card - CLICKABLE */}
            <div 
              onClick={() => handleChatAboutSection('Risk Assessment', report.risk_level.reasoning)}
              className={`p-6 rounded-xl border cursor-pointer transition-all ${
                effectiveTheme === 'dark' ? 'bg-[#0d1425] border-gray-800 hover:border-emerald-500/50' : 'bg-white border-gray-200 hover:border-emerald-400'
              }`}
            >
              <div className="flex items-center gap-3 mb-4">
                <Shield size={24} className={effectiveTheme === 'dark' ? 'text-emerald-400' : 'text-emerald-600'} />
                <h3 className={`text-lg font-bold ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  Risk Assessment
                </h3>
                <span className={`ml-auto text-xs ${effectiveTheme === 'dark' ? 'text-gray-500' : 'text-gray-400'}`}>
                  Click to chat about this
                </span>
              </div>
              <p className={`text-sm leading-relaxed ${effectiveTheme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                {report.risk_level.reasoning}
              </p>
            </div>

            {/* Compliance Coverage - CLICKABLE */}
            <div className={`p-6 rounded-xl border ${
              effectiveTheme === 'dark' ? 'bg-[#0d1425] border-gray-800' : 'bg-white border-gray-200'
            }`}>
              <div className="flex items-center gap-3 mb-4">
                <FileCheck size={24} className={effectiveTheme === 'dark' ? 'text-blue-400' : 'text-blue-600'} />
                <h3 className={`text-lg font-bold ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  Compliance Coverage
                </h3>
              </div>
              
              <p className={`text-sm mb-4 leading-relaxed ${effectiveTheme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                {report.compliance_coverage_assessment.overview}
              </p>

              <div className="space-y-3">
                {report.compliance_coverage_assessment.coverage_points.map((point, index) => (
                  <div
                    key={index}
                    onClick={() => handleChatAboutSection(point.title, point.summary)}
                    className={`p-4 rounded-lg border cursor-pointer transition-all ${
                      effectiveTheme === 'dark' ? 'bg-[#151b2e] border-gray-700 hover:border-emerald-500/50' : 'bg-gray-50 border-gray-200 hover:border-emerald-300'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <CheckCircle size={20} className={effectiveTheme === 'dark' ? 'text-emerald-400 flex-shrink-0 mt-0.5' : 'text-emerald-600 flex-shrink-0 mt-0.5'} />
                      <div className="flex-1">
                        <h4 className={`font-semibold text-sm mb-1 ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                          {point.title}
                        </h4>
                        <p className={`text-sm ${effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                          {point.summary}
                        </p>
                        <span className={`text-xs mt-2 inline-block ${effectiveTheme === 'dark' ? 'text-gray-500' : 'text-gray-500'}`}>
                          {point.source}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Key Gaps - CLICKABLE */}
            <div className={`p-6 rounded-xl border ${
              effectiveTheme === 'dark' ? 'bg-[#0d1425] border-gray-800' : 'bg-white border-gray-200'
            }`}>
              <div className="flex items-center gap-3 mb-4">
                <AlertTriangle size={24} className="text-yellow-400" />
                <h3 className={`text-lg font-bold ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  Key Compliance Gaps ({report.key_gaps_identified.length})
                </h3>
              </div>

              {report.key_gaps_identified.length === 0 ? (
                <p className={`text-sm ${effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                  No significant compliance gaps identified.
                </p>
              ) : (
                <div className="space-y-3">
                  {report.key_gaps_identified.map((gap, index) => (
                    <div
                      key={index}
                      onClick={() => handleChatAboutSection(gap.area, gap.issue)}
                      className={`p-4 rounded-lg border transition-all cursor-pointer ${
                        effectiveTheme === 'dark' 
                          ? 'bg-yellow-500/10 border-yellow-500/30 hover:bg-yellow-500/20' 
                          : 'bg-yellow-50 border-yellow-200 hover:bg-yellow-100'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <AlertCircle size={20} className="text-yellow-400 flex-shrink-0 mt-0.5" />
                        <div className="flex-1">
                          <h4 className={`font-semibold text-sm mb-1 ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                            {gap.area}
                          </h4>
                          <p className={`text-sm ${
                            expandedGaps.has(index) ? '' : 'line-clamp-2'
                          } ${effectiveTheme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                            {gap.issue}
                          </p>
                          {expandedGaps.has(index) && (
                            <span className={`text-xs mt-2 inline-block ${effectiveTheme === 'dark' ? 'text-gray-500' : 'text-gray-500'}`}>
                              {gap.source}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Top Recommendations - CLICKABLE */}
            <div className={`p-6 rounded-xl border ${
              effectiveTheme === 'dark' ? 'bg-[#0d1425] border-gray-800' : 'bg-white border-gray-200'
            }`}>
              <div className="flex items-center gap-3 mb-4">
                <Target size={24} className={effectiveTheme === 'dark' ? 'text-purple-400' : 'text-purple-600'} />
                <h3 className={`text-lg font-bold ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  Top Recommendations
                </h3>
              </div>

              <div className="space-y-3">
                {report.top_recommendations.map((rec, index) => (
                  <div
                    key={index}
                    onClick={() => handleChatAboutSection(rec.title, rec.recommendation)}
                    className={`p-4 rounded-lg border transition-all cursor-pointer ${
                      effectiveTheme === 'dark' ? 'bg-[#151b2e] border-gray-700 hover:border-purple-500/50' : 'bg-gray-50 border-gray-200 hover:border-purple-300'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`px-2 py-1 rounded text-xs font-bold border ${getPriorityColor(rec.priority)}`}>
                        P{rec.priority}
                      </div>
                      <div className="flex-1">
                        <h4 className={`font-semibold text-sm mb-1 ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                          {rec.title}
                        </h4>
                        <p className={`text-sm ${
                          expandedRecs.has(index) ? '' : 'line-clamp-2'
                        } ${effectiveTheme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                          {rec.recommendation}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-center gap-4 pt-4">
              <button
                onClick={() => {
                  setReport(null);
                  setUploadedFiles([]);
                  setAnalysisLogs([]);
                }}
                className={`px-6 py-3 rounded-lg font-medium border transition-colors ${
                  effectiveTheme === 'dark'
                    ? 'bg-[#151b2e] border-gray-700 text-white hover:border-gray-600'
                    : 'bg-white border-gray-300 text-gray-900 hover:border-gray-400'
                }`}
              >
                Analyze New Documents
              </button>
              
              <button
                onClick={() => router.push(`/project/${projectId}`)}
                className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all ${
                  effectiveTheme === 'dark'
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white hover:shadow-lg'
                    : 'bg-gradient-to-r from-emerald-400 to-teal-500 text-white hover:shadow-lg'
                }`}
              >
                <MessageSquare size={18} />
                Start Chatting About This Analysis
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
