'use client';

import { useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { ArrowLeft, Upload, FileText, X, Save } from 'lucide-react';

export default function UpdateContextPage() {
  const params = useParams();
  const router = useRouter();
  const projectId = params.id as string;
  
  const [files, setFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles([...files, ...Array.from(e.target.files)]);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files) {
      setFiles([...files, ...Array.from(e.dataTransfer.files)]);
    }
  };

  const removeFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  const handleUpdate = async () => {
    setUploading(true);
    // Simulate upload
    setTimeout(() => {
      setUploading(false);
      alert('Context updated successfully!');
      router.push('/');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-[#0a0f1e]">
      {/* Top Bar */}
      <header className="border-b border-gray-800 bg-[#0d1425]">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => router.push('/')}
              className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
            >
              <ArrowLeft className="text-gray-400" size={20} />
            </button>
            <h1 className="text-xl font-bold text-white">Update Context</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-3">
            Update Project Context
          </h2>
          <p className="text-gray-400">
            Upload additional documents to enhance compliance knowledge base.
          </p>
        </div>

        {/* Upload Area */}
        <div
          onDrop={handleDrop}
          onDragOver={(e) => e.preventDefault()}
          className="relative border-2 border-dashed border-gray-700 rounded-2xl p-12 text-center hover:border-emerald-500 transition-colors bg-[#151b2e] mb-6"
        >
          <input
            type="file"
            multiple
            accept=".pdf,.docx,.doc"
            onChange={handleFileSelect}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          
          <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-emerald-500/10 flex items-center justify-center">
            <Upload className="text-emerald-400" size={32} />
          </div>
          
          <h3 className="text-xl font-semibold text-white mb-2">
            Click to Upload Documents
          </h3>
          <p className="text-gray-400">
            PDF, DOCX up to 50MB
          </p>
        </div>

        {/* File List */}
        {files.length > 0 && (
          <div className="space-y-3 mb-8">
            <h3 className="text-lg font-semibold text-white mb-3">
              Selected Files ({files.length})
            </h3>
            {files.map((file, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-4 bg-[#151b2e] border border-gray-800 rounded-xl"
              >
                <div className="flex items-center gap-3">
                  <FileText className="text-emerald-400" size={24} />
                  <div>
                    <p className="text-white font-medium">{file.name}</p>
                    <p className="text-sm text-gray-400">
                      {(file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => removeFile(index)}
                  className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
                >
                  <X className="text-gray-400" size={20} />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center gap-4">
          <button
            onClick={handleUpdate}
            disabled={files.length === 0 || uploading}
            className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl hover:from-emerald-600 hover:to-teal-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all font-medium"
          >
            <Save size={20} />
            {uploading ? 'Updating...' : 'Update Context'}
          </button>
          <button
            onClick={() => router.push('/')}
            className="px-6 py-3 bg-[#151b2e] text-gray-300 rounded-xl hover:bg-[#1a2235] transition-all border border-gray-800"
          >
            Cancel
          </button>
        </div>
      </main>
    </div>
  );
}
