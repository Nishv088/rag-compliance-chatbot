'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Upload, FileText, X, ArrowLeft, Sun, Moon } from 'lucide-react';

export default function NewProjectPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const projectId = searchParams.get('id');
  const projectName = searchParams.get('name');
  
  const [files, setFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const [darkMode, setDarkMode] = useState(true);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files) {
      setFiles(Array.from(e.dataTransfer.files));
    }
  };

  const handleAnalyze = async () => {
    setUploading(true);
    setTimeout(() => {
      setUploading(false);
      router.push(`/project/${projectId}/report`);
    }, 2000);
  };

  const removeFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  return (
    <div className={darkMode ? 'min-h-screen bg-[#0a0f1e]' : 'min-h-screen bg-gray-50'}>
      {/* Top Bar */}
      <header className={`border-b ${darkMode ? 'border-gray-800 bg-[#0d1425]' : 'border-gray-200 bg-white'}`}>
        <div className="flex items-center justify-between px-5 py-3">
          <div className="flex items-center gap-3">
            <button
              onClick={() => router.push('/')}
              className={`p-1.5 rounded-lg transition-colors ${darkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-200'}`}
            >
              <ArrowLeft className={darkMode ? 'text-gray-400' : 'text-gray-600'} size={18} />
            </button>
            <h1 className={`text-lg font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
              {projectName || 'Upload Documents'}
            </h1>
          </div>
          <button
            onClick={() => setDarkMode(!darkMode)}
            className={`p-2 rounded-lg transition-colors ${darkMode ? 'bg-gray-800 text-yellow-400' : 'bg-gray-200 text-gray-700'}`}
          >
            {darkMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-5 py-8">
        <div className="text-center mb-6">
          <h2 className={`text-2xl font-bold mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
            Upload Documents
          </h2>
          <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            Upload documents to analyze against Dubai Regulations.
          </p>
        </div>

        {/* Upload Area */}
        <div
          onDrop={handleDrop}
          onDragOver={(e) => e.preventDefault()}
          className={`relative border-2 border-dashed rounded-xl p-10 text-center transition-colors ${
            darkMode 
              ? 'border-gray-700 hover:border-emerald-500 bg-[#151b2e]'
              : 'border-gray-300 hover:border-emerald-400 bg-white'
          }`}
        >
          <input
            type="file"
            multiple
            accept=".pdf,.docx,.doc"
            onChange={handleFileSelect}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          
          <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center ${
            darkMode ? 'bg-emerald-500/10' : 'bg-emerald-100'
          }`}>
            <Upload className={darkMode ? 'text-emerald-400' : 'text-emerald-600'} size={28} />
          </div>
          
          <h3 className={`text-lg font-semibold mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
            Click to Upload
          </h3>
          <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            PDF, DOCX up to 50MB
          </p>
        </div>

        {/* File List */}
        {files.length > 0 && (
          <div className="mt-5 space-y-2">
            {files.map((file, index) => (
              <div
                key={index}
                className={`flex items-center justify-between p-3 rounded-lg border ${
                  darkMode ? 'bg-[#151b2e] border-gray-800' : 'bg-white border-gray-200'
                }`}
              >
                <div className="flex items-center gap-2">
                  <FileText className={darkMode ? 'text-emerald-400' : 'text-emerald-600'} size={20} />
                  <div>
                    <p className={`font-medium text-sm ${darkMode ? 'text-white' : 'text-gray-900'}`}>{file.name}</p>
                    <p className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      {(file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => removeFile(index)}
                  className={`p-1.5 rounded-lg transition-colors ${darkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-200'}`}
                >
                  <X className={darkMode ? 'text-gray-400' : 'text-gray-600'} size={18} />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Analyze Button */}
        {files.length > 0 && (
          <div className="mt-6 flex justify-center">
            <button
              onClick={handleAnalyze}
              disabled={uploading}
              className={`px-6 py-2.5 text-sm rounded-lg font-medium shadow-lg transition-all ${
                darkMode
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white hover:from-emerald-600 hover:to-teal-700'
                  : 'bg-gradient-to-r from-emerald-400 to-teal-500 text-white hover:from-emerald-500 hover:to-teal-600'
              } disabled:opacity-50 disabled:cursor-not-allowed`}
            >
              {uploading ? 'Analyzing...' : 'Analyze Documents'}
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
