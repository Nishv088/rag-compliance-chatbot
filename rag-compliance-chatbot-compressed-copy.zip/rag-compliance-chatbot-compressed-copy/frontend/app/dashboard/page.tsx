//frontend\app\dashboard\page.tsx
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { 
  FolderOpen, Plus, Trash2, Calendar, MessageSquare,
  Search, X, Upload, Sun, Moon, Monitor  // ADDED: Sun, Moon, Monitor
} from 'lucide-react';
import { useTheme } from '@/contexts/ThemeContext';

interface Project {
  id: string;
  name: string;
  description?: string;
  created_at: string;
  updated_at?: string;
}

export default function DashboardPage() {
  const router = useRouter();
  const { theme, setTheme, effectiveTheme } = useTheme();  // ADDED: theme, setTheme
  
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectDesc, setNewProjectDesc] = useState('');
  const [creating, setCreating] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      const response = await fetch('http://localhost:8000/api/projects/');
      const data = await response.json();
      setProjects(data.projects || []);
    } catch (error) {
      console.error('Failed to fetch projects:', error);
    } finally {
      setLoading(false);
    }
  };

  const createProject = async () => {
    if (!newProjectName.trim()) return;

    setCreating(true);
    try {
      const response = await fetch('http://localhost:8000/api/projects/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newProjectName,
          description: newProjectDesc
        })
      });

      if (response.ok) {
        const data = await response.json();
        await fetchProjects();
        setShowCreateModal(false);
        setNewProjectName('');
        setNewProjectDesc('');
        
        // Redirect to analyze page to start uploading documents
        router.push(`/project/${data.project.id}/analyze`);
      }
    } catch (error) {
      console.error('Failed to create project:', error);
    } finally {
      setCreating(false);
    }
  };

  const deleteProject = async (projectId: string) => {
    try {
      const response = await fetch(`http://localhost:8000/api/projects/${projectId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        await fetchProjects();
        setDeleteConfirm(null);
      }
    } catch (error) {
      console.error('Failed to delete project:', error);
    }
  };

  const filteredProjects = projects.filter(p =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className={`min-h-screen ${effectiveTheme === 'dark' ? 'bg-[#0a0f1e]' : 'bg-gray-50'}`}>
      {/* Header */}
      <header className={`border-b ${effectiveTheme === 'dark' ? 'bg-[#0d1425] border-gray-800' : 'bg-white border-gray-200'}`}>
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div>
            <h1 className={`text-2xl font-bold ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              Dubai Compliance Projects
            </h1>
            <p className={`text-sm ${effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
              Manage your compliance projects
            </p>
          </div>

          {/* ADDED: Theme Switcher + New Project Button */}
          <div className="flex items-center gap-3">
            {/* Theme Switcher */}
            <div className={`flex items-center rounded-lg border ${
              effectiveTheme === 'dark' ? 'bg-[#151b2e] border-gray-700' : 'bg-white border-gray-300'
            }`}>
              <button
                onClick={() => setTheme('light')}
                className={`p-2 rounded-l-lg transition-colors ${
                  theme === 'light'
                    ? effectiveTheme === 'dark' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-emerald-100 text-emerald-700'
                    : effectiveTheme === 'dark' ? 'text-gray-400 hover:text-gray-200' : 'text-gray-600 hover:text-gray-900'
                }`}
                title="Light Mode"
              >
                <Sun size={18} />
              </button>
              <button
                onClick={() => setTheme('dark')}
                className={`p-2 transition-colors ${
                  theme === 'dark'
                    ? effectiveTheme === 'dark' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-emerald-100 text-emerald-700'
                    : effectiveTheme === 'dark' ? 'text-gray-400 hover:text-gray-200' : 'text-gray-600 hover:text-gray-900'
                }`}
                title="Dark Mode"
              >
                <Moon size={18} />
              </button>
              <button
                onClick={() => setTheme('system')}
                className={`p-2 rounded-r-lg transition-colors ${
                  theme === 'system'
                    ? effectiveTheme === 'dark' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-emerald-100 text-emerald-700'
                    : effectiveTheme === 'dark' ? 'text-gray-400 hover:text-gray-200' : 'text-gray-600 hover:text-gray-900'
                }`}
                title="System Theme"
              >
                <Monitor size={18} />
              </button>
            </div>

            {/* New Project Button */}
            <button
              onClick={() => setShowCreateModal(true)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
                effectiveTheme === 'dark'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white hover:shadow-lg'
                  : 'bg-gradient-to-r from-emerald-400 to-teal-500 text-white hover:shadow-lg'
              }`}
            >
              <Plus size={18} />
              New Project
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Search Bar */}
        <div className="mb-6">
          <div className={`flex items-center gap-3 px-4 py-3 rounded-lg border ${
            effectiveTheme === 'dark' ? 'bg-[#0d1425] border-gray-800' : 'bg-white border-gray-200'
          }`}>
            <Search size={20} className={effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'} />
            <input
              type="text"
              placeholder="Search projects..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`flex-1 bg-transparent border-none outline-none ${
                effectiveTheme === 'dark' ? 'text-white placeholder-gray-500' : 'text-gray-900 placeholder-gray-400'
              }`}
            />
          </div>
        </div>

        {/* Projects Grid */}
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-emerald-500 border-t-transparent"></div>
          </div>
        ) : filteredProjects.length === 0 ? (
          <div className="text-center py-16">
            <FolderOpen size={64} className={`mx-auto mb-4 ${effectiveTheme === 'dark' ? 'text-gray-700' : 'text-gray-300'}`} />
            <h3 className={`text-lg font-semibold mb-2 ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              {searchQuery ? 'No projects found' : 'No projects yet'}
            </h3>
            <p className={`text-sm mb-6 ${effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
              {searchQuery ? 'Try a different search term' : 'Create your first project to get started'}
            </p>
            {!searchQuery && (
              <button
                onClick={() => setShowCreateModal(true)}
                className={`px-6 py-2 rounded-lg font-medium ${
                  effectiveTheme === 'dark'
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white'
                    : 'bg-gradient-to-r from-emerald-400 to-teal-500 text-white'
                }`}
              >
                Create Project
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map(project => (
              <div
                key={project.id}
                className={`relative p-6 rounded-xl border transition-all ${
                  effectiveTheme === 'dark'
                    ? 'bg-[#0d1425] border-gray-800 hover:border-emerald-500/50'
                    : 'bg-white border-gray-200 hover:border-emerald-400'
                }`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className={`p-3 rounded-lg ${
                    effectiveTheme === 'dark' ? 'bg-emerald-500/20' : 'bg-emerald-100'
                  }`}>
                    <FolderOpen size={24} className={effectiveTheme === 'dark' ? 'text-emerald-400' : 'text-emerald-600'} />
                  </div>
                  
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setDeleteConfirm(project.id);
                    }}
                    className={`p-2 rounded-lg transition-colors ${
                      effectiveTheme === 'dark' ? 'hover:bg-red-500/20 text-red-400' : 'hover:bg-red-100 text-red-600'
                    }`}
                  >
                    <Trash2 size={16} />
                  </button>
                </div>

                <h3 className={`text-lg font-semibold mb-2 ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                  {project.name}
                </h3>
                
                {project.description && (
                  <p className={`text-sm mb-4 line-clamp-2 ${effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                    {project.description}
                  </p>
                )}

                <div className={`flex items-center gap-4 text-xs mb-4 ${effectiveTheme === 'dark' ? 'text-gray-500' : 'text-gray-500'}`}>
                  <div className="flex items-center gap-1">
                    <Calendar size={14} />
                    <span>{new Date(project.created_at).toLocaleDateString()}</span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className={`flex items-center gap-2 pt-3 border-t ${effectiveTheme === 'dark' ? 'border-gray-800' : 'border-gray-200'}`}>
                  <button
                    onClick={() => router.push(`/project/${project.id}/analyze`)}
                    className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 text-sm rounded-lg font-medium transition-all ${
                      effectiveTheme === 'dark'
                        ? 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 border border-emerald-500/30'
                        : 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200 border border-emerald-300'
                    }`}
                  >
                    <Upload size={14} />
                    Analyze
                  </button>
                  
                  <button
                    onClick={() => router.push(`/project/${project.id}`)}
                    className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 text-sm rounded-lg font-medium transition-all ${
                      effectiveTheme === 'dark'
                        ? 'bg-blue-500/20 text-blue-300 hover:bg-blue-500/30 border border-blue-500/30'
                        : 'bg-blue-100 text-blue-700 hover:bg-blue-200 border border-blue-300'
                    }`}
                  >
                    <MessageSquare size={14} />
                    Chat
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Create Project Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className={`w-full max-w-md rounded-xl p-6 ${
            effectiveTheme === 'dark' ? 'bg-[#0d1425]' : 'bg-white'
          }`}>
            <div className="flex items-center justify-between mb-6">
              <h2 className={`text-xl font-bold ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                Create New Project
              </h2>
              <button
                onClick={() => {
                  setShowCreateModal(false);
                  setNewProjectName('');
                  setNewProjectDesc('');
                }}
                className={`p-1 rounded-lg ${
                  effectiveTheme === 'dark' ? 'hover:bg-gray-800' : 'hover:bg-gray-100'
                }`}
              >
                <X size={20} className={effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'} />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className={`block text-sm font-medium mb-2 ${
                  effectiveTheme === 'dark' ? 'text-gray-300' : 'text-gray-700'
                }`}>
                  Project Name *
                </label>
                <input
                  type="text"
                  value={newProjectName}
                  onChange={(e) => setNewProjectName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && newProjectName.trim()) {
                      createProject();
                    }
                  }}
                  placeholder="e.g., Dubai Marina Tower Project"
                  className={`w-full px-4 py-2 rounded-lg border outline-none ${
                    effectiveTheme === 'dark'
                      ? 'bg-[#151b2e] border-gray-700 text-white placeholder-gray-500 focus:border-emerald-500'
                      : 'bg-white border-gray-300 text-gray-900 placeholder-gray-400 focus:border-emerald-400'
                  }`}
                  autoFocus
                />
              </div>

              <div>
                <label className={`block text-sm font-medium mb-2 ${
                  effectiveTheme === 'dark' ? 'text-gray-300' : 'text-gray-700'
                }`}>
                  Description (Optional)
                </label>
                <textarea
                  value={newProjectDesc}
                  onChange={(e) => setNewProjectDesc(e.target.value)}
                  placeholder="Brief description of the project..."
                  rows={3}
                  className={`w-full px-4 py-2 rounded-lg border outline-none resize-none ${
                    effectiveTheme === 'dark'
                      ? 'bg-[#151b2e] border-gray-700 text-white placeholder-gray-500 focus:border-emerald-500'
                      : 'bg-white border-gray-300 text-gray-900 placeholder-gray-400 focus:border-emerald-400'
                  }`}
                />
              </div>
            </div>

            <div className="flex items-center gap-3 mt-6">
              <button
                onClick={() => {
                  setShowCreateModal(false);
                  setNewProjectName('');
                  setNewProjectDesc('');
                }}
                className={`flex-1 px-4 py-2 rounded-lg font-medium transition-colors ${
                  effectiveTheme === 'dark'
                    ? 'bg-gray-800 text-white hover:bg-gray-700'
                    : 'bg-gray-200 text-gray-900 hover:bg-gray-300'
                }`}
              >
                Cancel
              </button>
              <button
                onClick={createProject}
                disabled={!newProjectName.trim() || creating}
                className={`flex-1 px-4 py-2 rounded-lg font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
                  effectiveTheme === 'dark'
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white'
                    : 'bg-gradient-to-r from-emerald-400 to-teal-500 text-white'
                }`}
              >
                {creating ? (
                  <span className="flex items-center justify-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Creating...
                  </span>
                ) : (
                  'Create Project'
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className={`w-full max-w-sm rounded-xl p-6 ${
            effectiveTheme === 'dark' ? 'bg-[#0d1425]' : 'bg-white'
          }`}>
            <h2 className={`text-lg font-bold mb-3 ${effectiveTheme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              Delete Project?
            </h2>
            <p className={`text-sm mb-6 ${effectiveTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
              This action cannot be undone. All chats and analysis will be permanently deleted.
            </p>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setDeleteConfirm(null)}
                className={`flex-1 px-4 py-2 rounded-lg font-medium ${
                  effectiveTheme === 'dark'
                    ? 'bg-gray-800 text-white hover:bg-gray-700'
                    : 'bg-gray-200 text-gray-900 hover:bg-gray-300'
                }`}
              >
                Cancel
              </button>
              <button
                onClick={() => deleteProject(deleteConfirm)}
                className="flex-1 px-4 py-2 rounded-lg font-medium bg-red-600 text-white hover:bg-red-700 transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
