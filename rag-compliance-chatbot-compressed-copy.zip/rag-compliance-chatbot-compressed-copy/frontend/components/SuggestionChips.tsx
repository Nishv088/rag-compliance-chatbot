/**
 * Suggestion chips component for starter questions
 */

'use client';

interface SuggestionChipsProps {
  suggestions: string[];
  onSuggestionClick: (suggestion: string) => void;
}

export default function SuggestionChips({ suggestions, onSuggestionClick }: SuggestionChipsProps) {
  if (suggestions.length === 0) return null;

  return (
    <div className="space-y-3">
      <p className="text-sm font-medium text-slate-700">Try asking:</p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {suggestions.map((suggestion, idx) => (
          <button
            key={idx}
            onClick={() => onSuggestionClick(suggestion)}
            className="text-left px-4 py-3 bg-white hover:bg-blue-50 border border-slate-200 hover:border-blue-300 rounded-xl text-sm text-slate-700 transition-all shadow-sm hover:shadow-md"
          >
            {suggestion}
          </button>
        ))}
      </div>
    </div>
  );
}
