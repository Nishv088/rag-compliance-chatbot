'use client';

import { useState, useEffect } from 'react';
import { Pencil, Trash2, Plus, MessageSquare } from 'lucide-react';

interface Session {
  session_id: string;
  title: string;
  created_at: string;
  updated_at: string;
  message_count: number;
}

interface SidebarProps {
  currentSessionId: string;
  onSessionChange: (sessionId: string) => void;
  onNewChat: () => void;
}

export default function Sidebar({ currentSessionId, onSessionChange, onNewChat }: SidebarProps) {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [loading, setLoading] = useState(true);

  const fetchSessions = async () => {
    try {
      const response = await fetch('http://localhost:8000/api/sessions');
      if (response.ok) {
        const data = await response.json();
        setSessions(data);
      }
    } catch (error) {
      console.error('Failed to fetch sessions:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSessions();
    // Refresh every 10 seconds
    const interval = setInterval(fetchSessions, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleDelete = async (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (!confirm('Delete this conversation?')) return;
    
    try {
      const response = await fetch(`http://localhost:8000/api/sessions/${sessionId}`, {
        method: 'DELETE',
      });
      
      if (response.ok) {
        setSessions(sessions.filter(s => s.session_id !== sessionId));
        
        // If deleting current session, create new one
        if (sessionId === currentSessionId) {
          onNewChat();
        }
      }
    } catch (error) {
      console.error('Failed to delete session:', error);
    }
  };

  const handleEdit = (session: Session, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(session.session_id);
    setEditTitle(session.title);
  };

  const handleSaveEdit = async (sessionId: string) => {
    if (!editTitle.trim()) return;
    
    try {
      const response = await fetch(`http://localhost:8000/api/sessions/${sessionId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: editTitle }),
      });
      
      if (response.ok) {
        const updated = await response.json();
        setSessions(sessions.map(s => 
          s.session_id === sessionId ? updated : s
        ));
        setEditingId(null);
      }
    } catch (error) {
      console.error('Failed to update session:', error);
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    if (days < 7) return `${days} days ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="w-64 bg-gray-900 text-white flex flex-col h-full border-r border-gray-700">
      {/* Header */}
      <div className="p-4 border-b border-gray-700">
        <button
          onClick={onNewChat}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center justify-center gap-2 transition-colors"
        >
          <Plus size={20} />
          New Chat
        </button>
      </div>

      {/* Sessions List */}
      <div className="flex-1 overflow-y-auto p-2">
        {loading ? (
          <div className="text-center text-gray-400 py-4">Loading...</div>
        ) : sessions.length === 0 ? (
          <div className="text-center text-gray-400 py-8 text-sm">
            No conversations yet
          </div>
        ) : (
          sessions.map((session) => (
            <div
              key={session.session_id}
              onClick={() => onSessionChange(session.session_id)}
              className={`group p-3 rounded-lg mb-2 cursor-pointer transition-all ${
                session.session_id === currentSessionId
                  ? 'bg-gray-700 border border-blue-500'
                  : 'bg-gray-800 hover:bg-gray-750 border border-transparent'
              }`}
            >
              {editingId === session.session_id ? (
                <input
                  type="text"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  onBlur={() => handleSaveEdit(session.session_id)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSaveEdit(session.session_id);
                    if (e.key === 'Escape') setEditingId(null);
                  }}
                  className="w-full bg-gray-600 text-white px-2 py-1 rounded text-sm"
                  autoFocus
                  onClick={(e) => e.stopPropagation()}
                />
              ) : (
                <>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <MessageSquare size={14} className="text-gray-400 flex-shrink-0" />
                        <h3 className="text-sm font-medium truncate">
                          {session.title}
                        </h3>
                      </div>
                      <div className="flex items-center justify-between text-xs text-gray-400">
                        <span>{formatDate(session.updated_at)}</span>
                        <span>{session.message_count} msgs</span>
                      </div>
                    </div>
                    
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={(e) => handleEdit(session, e)}
                        className="p-1 hover:bg-gray-600 rounded"
                        title="Edit title"
                      >
                        <Pencil size={14} />
                      </button>
                      <button
                        onClick={(e) => handleDelete(session.session_id, e)}
                        className="p-1 hover:bg-red-600 rounded"
                        title="Delete"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
