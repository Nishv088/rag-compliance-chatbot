/**
 * Individual message bubble component
 */

'use client';

import { useState } from 'react';
import { Bot, User } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { ChatMessage, Citation } from '../lib/types';

interface MessageBubbleProps {
  message: ChatMessage;
  onSuggestionClick?: (suggestion: string) => void;
}

export default function MessageBubble({ message, onSuggestionClick }: MessageBubbleProps) {
  const isUser = message.role === 'user';

  return (
    <div className={`flex gap-4 ${isUser ? 'justify-end' : 'justify-start'}`}>
      {/* Avatar */}
      {!isUser && (
        <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center flex-shrink-0 shadow-md">
          <Bot className="w-5 h-5 text-white" />
        </div>
      )}

      {/* Message Content */}
      <div className={`flex flex-col max-w-3xl ${isUser ? 'items-end' : 'items-start'}`}>
        {/* Message Bubble */}
        <div
          className={`px-5 py-4 rounded-2xl shadow-md ${
            isUser
              ? 'bg-gradient-to-br from-blue-600 to-indigo-600 text-white'
              : 'bg-white text-slate-800 border border-slate-200'
          }`}
        >
          {isUser ? (
            <p className="text-sm leading-relaxed">{message.content}</p>
          ) : (
            <div className="prose prose-sm max-w-none">
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={{
                  table: ({ node, ...props }) => (
                    <div className="overflow-x-auto my-4">
                      <table className="min-w-full border-collapse border border-slate-300" {...props} />
                    </div>
                  ),
                  th: ({ node, ...props }) => (
                    <th className="border border-slate-300 px-4 py-2 bg-slate-100 font-semibold" {...props} />
                  ),
                  td: ({ node, ...props }) => (
                    <td className="border border-slate-300 px-4 py-2" {...props} />
                  ),
                }}
              >
                {message.content}
              </ReactMarkdown>
            </div>
          )}
        </div>

        {/* Confidence & Citations */}
        {!isUser && (
          <div className="mt-2 flex flex-wrap items-center gap-3">
            {message.confidence !== undefined && (
              <span className="text-xs text-slate-500">
                Confidence: {message.confidence}%
              </span>
            )}
            {message.citations && message.citations.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {message.citations.map((cite) => (
                  <CitationBadge key={cite.id} citation={cite} />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Follow-up Suggestions */}
        {!isUser && message.suggestions && message.suggestions.length > 0 && onSuggestionClick && (
          <div className="mt-4 space-y-2 w-full">
            <p className="text-xs font-medium text-slate-600">Follow-up questions:</p>
            {message.suggestions.map((suggestion, idx) => (
              <button
                key={idx}
                onClick={() => onSuggestionClick(suggestion)}
                className="w-full text-left px-3 py-2 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg text-xs text-slate-700 transition-colors"
              >
                {suggestion}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* User Avatar */}
      {isUser && (
        <div className="w-8 h-8 bg-slate-700 rounded-lg flex items-center justify-center flex-shrink-0 shadow-md">
          <User className="w-5 h-5 text-white" />
        </div>
      )}
    </div>
  );
}

// Citation Badge Component
function CitationBadge({ citation }: { citation: Citation }) {
  const [showTooltip, setShowTooltip] = useState(false);

  return (
    <div
      className="relative"
      onMouseEnter={() => setShowTooltip(true)}
      onMouseLeave={() => setShowTooltip(false)}
    >
      <span className="inline-flex items-center gap-1 px-2 py-1 bg-blue-100 hover:bg-blue-200 text-blue-700 text-xs font-medium rounded-md cursor-pointer transition-colors">
        [{citation.id}]
      </span>

      {/* Tooltip */}
      {showTooltip && (
        <div className="absolute bottom-full left-0 mb-2 w-72 p-3 bg-slate-900 text-white text-xs rounded-lg shadow-xl z-50">
          <div className="font-semibold mb-1">{citation.document_name}</div>
          <div className="text-slate-300 mb-2">{citation.title}</div>
          <div className="text-slate-400 space-y-1">
            {citation.section_no && <div>Section: {citation.section_no}</div>}
            {citation.page_no && <div>Page: {citation.page_no}</div>}
            {citation.confidence && <div>Confidence: {citation.confidence}%</div>}
          </div>
          <div className="mt-2 text-slate-300 text-xs leading-relaxed">
            {citation.text}
          </div>
        </div>
      )}
    </div>
  );
}
