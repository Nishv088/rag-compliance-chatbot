// frontend/types/index.ts

export interface Message {
  role: 'user' | 'assistant';
  content: string;
  confidence?: number;
  citations?: Citation[];
  suggestions?: string[];
  timestamp: string;
  isStreaming?: boolean;
}

export interface Citation {
  id: string;
  title: string;
  score: number;
  type: 'compliance' | 'proposal';
}

export interface Conversation {
  id: string;
  title: string;
  projectId: string;
  messages: Message[];
  createdAt: string;
}

export interface Project {
  id: string;
  name: string;
  description?: string;
  conversations: Conversation[];
  hasProposal?: boolean;
  proposalModified?: boolean;
  riskLevel?: 'Low' | 'Medium' | 'High';
  createdAt: string;
  lastModified: string;
}

export interface AnalysisReport {
  document_info: {
    report_title: string;
    processing_note: string;
    date: string;
    file_name: string;
    page_count: number;
  };
  compliance_coverage_assessment: {
    overview: string;
    coverage_points: CoveragePoint[];
  };
  key_gaps_identified: Gap[];
  risk_level: {
    assessment: 'Low' | 'Medium' | 'High';
    reasoning: string;
  };
  top_recommendations: Recommendation[];
  source_reference_key?: SourceReference[];
}

export interface CoveragePoint {
  title: string;
  summary: string;
  source: string;
}

export interface Gap {
  area: string;
  issue: string;
  source: string;
}

export interface Recommendation {
  priority: number;
  title: string;
  recommendation: string;
}

export interface SourceReference {
  source: string;
  reference: string;
  document_id: string;
  category: string;
  score: number;
}
