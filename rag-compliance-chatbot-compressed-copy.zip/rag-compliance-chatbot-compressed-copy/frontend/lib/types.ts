export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp?: string;
  citations?: Citation[];
  suggestions?: string[];
  confidence?: number;
}

export interface Citation {
  id: string;
  title: string;
  text: string;
  section_no?: string;
  page_no?: string;
  confidence?: number;
  document_name?: string;
}

export interface ChatRequest {
  session_id: string;
  message: string;
  history: ChatMessage[];
}

export interface ChatResponse {
  session_id: string;
  message: ChatMessage;
  processing_time: number;
}

export interface Session {
  session_id: string;
  created_at: string;
  message_count: number;
  title: string;
}

export interface SessionHistory {
  session_id: string;
  messages: ChatMessage[];
  title?: string;
}
