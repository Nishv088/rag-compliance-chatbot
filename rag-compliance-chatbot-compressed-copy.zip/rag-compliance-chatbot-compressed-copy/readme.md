# Dubai Compliance RAG Chatbot with Proposal Analysis

AI-powered chatbot for Dubai construction compliance with integrated proposal document analysis.

## 🚀 Features

- **Dual Collection Search**: Searches both compliance regulations and project proposals
- **Proposal Analysis**: Upload and analyze proposal documents against Dubai regulations
- **Gap Identification**: Automatically identifies compliance gaps
- **Risk Assessment**: Provides risk levels and recommendations
- **Multi-Project Support**: Manage multiple projects with separate conversations
- **Theme Support**: Light, dark, and system themes
- **Real-time Chat**: Streaming responses with confidence scores

## 📋 Prerequisites

- Python 3.11+
- Node.js 18+
- Docker & Docker Compose
- OpenAI API Key

## 🛠️ Setup Instructions

### 1. Clone Repository

```bash
git clone <your-repo>
cd rag-compliance-chatbot
2. Backend Setup
bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env and add your API keys
3. Initialize Database
bash
# Start Qdrant
docker-compose up -d qdrant

# Initialize collections
python scripts/init_database.py
4. Frontend Setup
bash
cd frontend

# Install dependencies
npm install

# Create environment file
echo "NEXT_PUBLIC_API_URL=http://localhost:8000" > .env.local
5. Start Application
Option A: Development Mode

bash
# Terminal 1 - Backend
cd backend
source venv/bin/activate
uvicorn app.api.main:app --reload --host 0.0.0.0 --port 8000

# Terminal 2 - Frontend
cd frontend
npm run dev
Option B: Docker

bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f
6. Access Application
Frontend: http://localhost:3000

Backend API: http://localhost:8000

API Docs: http://localhost:8000/docs

Qdrant Dashboard: http://localhost:6333/dashboard