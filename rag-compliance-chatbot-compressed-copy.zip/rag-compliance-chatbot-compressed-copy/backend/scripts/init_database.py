"""
Initialize Qdrant collections for the application
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams

from app.config import settings
from app.utils.logger import setup_logger

logger = setup_logger("init_database")

def init_collections():
    """Initialize Qdrant collections"""
    try:
        logger.info("🔄 Connecting to Qdrant...")
        client = QdrantClient(host=settings.QDRANT_HOST, port=settings.QDRANT_PORT)
        
        # Get existing collections
        existing_collections = {c.name for c in client.get_collections().collections}
        
        # Compliance collection (already exists: dubai_compliance)
        if settings.QDRANT_COLLECTION in existing_collections:
            logger.info(f"✓ Compliance collection exists: {settings.QDRANT_COLLECTION}")
        else:
            logger.warning(f"⚠️  Compliance collection NOT found: {settings.QDRANT_COLLECTION}")
            logger.info("Please ensure you have ingested compliance documents first")
        
        # Proposal Documents Collection (NEW)
        proposal_collection = "proposal_documents"
        if proposal_collection not in existing_collections:
            logger.info(f"Creating collection: {proposal_collection}")
            client.create_collection(
                collection_name=proposal_collection,
                vectors_config=VectorParams(
                    size=1024,  # BGE-large dimension
                    distance=Distance.COSINE
                )
            )
            logger.info(f"✅ Created: {proposal_collection}")
        else:
            logger.info(f"✓ Collection exists: {proposal_collection}")
        
        # Verify collections
        collections = client.get_collections().collections
        logger.info(f"\n📊 Available collections:")
        
        for collection in collections:
            info = client.get_collection(collection.name)
            logger.info(f"  - {collection.name}: {info.vectors_count} vectors")
        
        logger.info("\n✅ Database initialization completed")
        
    except Exception as e:
        logger.error(f"❌ Database initialization failed: {e}")
        raise

if __name__ == "__main__":
    init_collections()
