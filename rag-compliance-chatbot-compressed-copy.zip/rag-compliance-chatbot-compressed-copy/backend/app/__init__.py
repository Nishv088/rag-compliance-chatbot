"""
Dubai Compliance RAG Chatbot Backend
"""

__version__ = "1.0.0"
