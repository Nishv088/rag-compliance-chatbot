from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime

class ChatMessage(BaseModel):
    role: str = Field(..., description="'user' or 'assistant'")
    content: str
    timestamp: Optional[datetime] = None
    citations: Optional[List[Dict[str, Any]]] = None
    suggestions: Optional[List[str]] = None
    confidence: Optional[float] = None

class ChatRequest(BaseModel):
    session_id: str
    message: str
    history: Optional[List[ChatMessage]] = []

class ChatResponse(BaseModel):
    session_id: str
    message: ChatMessage
    processing_time: float

class SessionCreate(BaseModel):
    session_id: Optional[str] = None

class SessionResponse(BaseModel):
    session_id: str
    created_at: datetime
    message_count: int
    title: Optional[str] = None

class SessionListResponse(BaseModel):
    sessions: List[SessionResponse]

class SessionHistoryResponse(BaseModel):
    session_id: str
    messages: List[ChatMessage]
    title: Optional[str] = None

class Citation(BaseModel):
    id: str
    title: str
    text: str
    section_no: Optional[str] = None
    page_no: Optional[str] = None
    confidence: Optional[float] = None
    document_name: Optional[str] = None

class SuggestionsResponse(BaseModel):
    suggestions: List[str]

class HealthResponse(BaseModel):
    status: str
    timestamp: datetime
    version: str
