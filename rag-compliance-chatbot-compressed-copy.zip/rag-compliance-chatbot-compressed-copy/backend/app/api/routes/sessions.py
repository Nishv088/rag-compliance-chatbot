"""
Session management endpoints with persistence
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import json
from pathlib import Path
from datetime import datetime
from app.utils.logger import setup_logger

router = APIRouter()
logger = setup_logger("sessions")

# Session storage
SESSIONS_FILE = Path("data/sessions/sessions.json")
SESSIONS_FILE.parent.mkdir(parents=True, exist_ok=True)


class SessionCreate(BaseModel):
    title: Optional[str] = "New Chat"


class SessionUpdate(BaseModel):
    title: str


class SessionResponse(BaseModel):
    session_id: str
    title: str
    created_at: str
    updated_at: str
    message_count: int


def ensure_session_exists(session_id: str) -> dict:
    """Ensure session exists, create if not"""
    sessions = load_sessions()
    
    if session_id not in sessions:
        now = datetime.now().isoformat()
        sessions[session_id] = {
            "title": "New Chat",
            "created_at": now,
            "updated_at": now,
            "messages": []
        }
        save_sessions(sessions)
        logger.info(f"✅ Auto-created session: {session_id}")
    
    return sessions[session_id]

def load_sessions():
    """Load sessions from file"""
    if SESSIONS_FILE.exists():
        try:
            with open(SESSIONS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}
    return {}


def save_sessions(sessions):
    """Save sessions to file"""
    with open(SESSIONS_FILE, 'w', encoding='utf-8') as f:
        json.dump(sessions, f, indent=2, ensure_ascii=False)


def update_session_messages(session_id: str, messages: list):
    """Update session messages (called from chat endpoint)"""
    try:
        sessions = load_sessions()
        
        # Ensure session exists
        if session_id not in sessions:
            now = datetime.now().isoformat()
            sessions[session_id] = {
                "title": "New Chat",
                "created_at": now,
                "updated_at": now,
                "messages": []
            }
            logger.info(f"✅ Auto-created session: {session_id}")
        
        # Update messages
        sessions[session_id]["messages"] = messages
        sessions[session_id]["updated_at"] = datetime.now().isoformat()
        
        # Auto-generate title from first user message if still "New Chat"
        if sessions[session_id]["title"] == "New Chat" and len(messages) > 0:
            first_user_msg = next((m for m in messages if m.get("role") == "user"), None)
            if first_user_msg:
                title = first_user_msg.get("content", "")[:60]
                sessions[session_id]["title"] = title.strip() if title.strip() else "New Chat"
        
        save_sessions(sessions)
        logger.info(f"💾 Session {session_id} updated: {len(messages)} messages, title: '{sessions[session_id]['title']}'")
        
    except Exception as e:
        logger.error(f"❌ Error updating session messages: {e}")
        import traceback
        traceback.print_exc()


@router.get("/", response_model=List[SessionResponse])
async def list_sessions():
    """Get all sessions sorted by most recent"""
    try:
        sessions = load_sessions()
        
        session_list = []
        for session_id, session_data in sessions.items():
            session_list.append(SessionResponse(
                session_id=session_id,
                title=session_data.get("title", "New Chat"),
                created_at=session_data.get("created_at", datetime.now().isoformat()),
                updated_at=session_data.get("updated_at", datetime.now().isoformat()),
                message_count=len(session_data.get("messages", []))
            ))
        
        # Sort by updated_at descending
        session_list.sort(key=lambda x: x.updated_at, reverse=True)
        
        logger.info(f"📋 Retrieved {len(session_list)} sessions")
        return session_list
    except Exception as e:
        logger.error(f"Error listing sessions: {e}")
        return []


@router.post("/", response_model=SessionResponse)
async def create_session(session: SessionCreate):
    """Create a new session"""
    try:
        sessions = load_sessions()
        
        session_id = str(int(datetime.now().timestamp() * 1000))
        now = datetime.now().isoformat()
        
        sessions[session_id] = {
            "title": session.title or "New Chat",
            "created_at": now,
            "updated_at": now,
            "messages": []
        }
        
        save_sessions(sessions)
        
        logger.info(f"✅ Created new session: {session_id}")
        
        return SessionResponse(
            session_id=session_id,
            title=sessions[session_id]["title"],
            created_at=now,
            updated_at=now,
            message_count=0
        )
    except Exception as e:
        logger.error(f"Error creating session: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{session_id}")
async def get_session(session_id: str):
    """Get session details"""
    try:
        sessions = load_sessions()
        
        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")
        
        return {
            "session_id": session_id,
            **sessions[session_id]
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting session: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.patch("/{session_id}", response_model=SessionResponse)
async def update_session(session_id: str, update: SessionUpdate):
    """Update session title"""
    try:
        sessions = load_sessions()
        
        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")
        
        sessions[session_id]["title"] = update.title
        sessions[session_id]["updated_at"] = datetime.now().isoformat()
        
        save_sessions(sessions)
        
        logger.info(f"✏️ Updated session {session_id} title: '{update.title}'")
        
        return SessionResponse(
            session_id=session_id,
            title=sessions[session_id]["title"],
            created_at=sessions[session_id]["created_at"],
            updated_at=sessions[session_id]["updated_at"],
            message_count=len(sessions[session_id].get("messages", []))
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating session: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{session_id}")
async def delete_session(session_id: str):
    """Delete a session"""
    try:
        sessions = load_sessions()
        
        if session_id not in sessions:
            raise HTTPException(status_code=404, detail="Session not found")
        
        del sessions[session_id]
        save_sessions(sessions)
        
        logger.info(f"🗑️ Deleted session: {session_id}")
        
        return {"message": "Session deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting session: {e}")
        raise HTTPException(status_code=500, detail=str(e))
