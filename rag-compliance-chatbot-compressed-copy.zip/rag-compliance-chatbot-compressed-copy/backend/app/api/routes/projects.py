"""
Project management endpoints with persistent JSON storage
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import json
from pathlib import Path
from datetime import datetime

from app.config import settings
from app.utils.logger import setup_logger

router = APIRouter()
logger = setup_logger("projects_api")

# Projects storage file in data directory
PROJECTS_FILE = settings.DATA_DIR / "projects" / "projects.json"


class ProjectCreate(BaseModel):
    name: str
    description: str = ""


class ProjectUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None


class ProjectResponse(BaseModel):
    id: str
    name: str
    description: str = ""
    created_at: str
    updated_at: str


def load_projects() -> dict:
    """Load projects from JSON file"""
    try:
        PROJECTS_FILE.parent.mkdir(parents=True, exist_ok=True)
        
        if PROJECTS_FILE.exists():
            with open(PROJECTS_FILE, 'r', encoding='utf-8') as f:
                projects = json.load(f)
                logger.info(f"📂 Loaded {len(projects)} projects from storage")
                return projects
        
        logger.info("📂 No existing projects file, starting fresh")
        return {}
    except Exception as e:
        logger.error(f"❌ Failed to load projects: {e}")
        return {}


def save_projects(projects: dict):
    """Save projects to JSON file"""
    try:
        PROJECTS_FILE.parent.mkdir(parents=True, exist_ok=True)
        
        with open(PROJECTS_FILE, 'w', encoding='utf-8') as f:
            json.dump(projects, f, indent=2, ensure_ascii=False)
        
        logger.info(f"💾 Saved {len(projects)} projects to storage")
    except Exception as e:
        logger.error(f"❌ Failed to save projects: {e}")
        raise


@router.get("/")
async def list_projects():
    """Get all projects"""
    try:
        projects = load_projects()
        
        projects_list = []
        for project_id, project_data in projects.items():
            projects_list.append({
                "id": project_id,
                "name": project_data.get("name", "Untitled Project"),
                "description": project_data.get("description", ""),
                "created_at": project_data.get("created_at", datetime.now().isoformat()),
                "updated_at": project_data.get("updated_at", datetime.now().isoformat())
            })
        
        # Sort by creation date (newest first)
        projects_list.sort(key=lambda x: x.get("created_at", ""), reverse=True)
        
        logger.info(f"📋 Retrieved {len(projects_list)} projects")
        return {"projects": projects_list}
    
    except Exception as e:
        logger.error(f"❌ Error listing projects: {e}")
        return {"projects": []}


@router.post("/")
async def create_project(project: ProjectCreate):
    """Create a new project"""
    try:
        projects = load_projects()
        
        # Generate unique project ID
        project_id = f"p{int(datetime.now().timestamp() * 1000)}"
        now = datetime.now().isoformat()
        
        new_project = {
            "name": project.name,
            "description": project.description,
            "created_at": now,
            "updated_at": now
        }
        
        projects[project_id] = new_project
        save_projects(projects)
        
        logger.info(f"✅ Created new project: {project_id} - {project.name}")
        
        return {
            "project": {
                "id": project_id,
                "name": new_project["name"],
                "description": new_project["description"],
                "created_at": new_project["created_at"],
                "updated_at": new_project["updated_at"]
            }
        }
    
    except Exception as e:
        logger.error(f"❌ Error creating project: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{project_id}")
async def get_project(project_id: str):
    """Get a specific project"""
    try:
        projects = load_projects()
        
        if project_id not in projects:
            logger.warning(f"⚠️ Project not found: {project_id}")
            raise HTTPException(status_code=404, detail="Project not found")
        
        project_data = projects[project_id]
        
        return {
            "project": {
                "id": project_id,
                "name": project_data.get("name", "Untitled Project"),
                "description": project_data.get("description", ""),
                "created_at": project_data.get("created_at"),
                "updated_at": project_data.get("updated_at")
            }
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Error getting project: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.patch("/{project_id}")
async def update_project(project_id: str, updates: ProjectUpdate):
    """Update a project"""
    try:
        projects = load_projects()
        
        if project_id not in projects:
            raise HTTPException(status_code=404, detail="Project not found")
        
        # Update fields
        if updates.name is not None:
            projects[project_id]["name"] = updates.name
        
        if updates.description is not None:
            projects[project_id]["description"] = updates.description
        
        # Update timestamp
        projects[project_id]["updated_at"] = datetime.now().isoformat()
        
        save_projects(projects)
        
        logger.info(f"✏️ Updated project: {project_id}")
        
        return {
            "project": {
                "id": project_id,
                **projects[project_id]
            }
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Error updating project: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{project_id}")
async def delete_project(project_id: str):
    """Delete a project and all associated data"""
    try:
        projects = load_projects()
        
        if project_id not in projects:
            raise HTTPException(status_code=404, detail="Project not found")
        
        # Delete from projects
        project_name = projects[project_id].get("name", project_id)
        del projects[project_id]
        save_projects(projects)
        
        logger.info(f"🗑️ Deleted project from storage: {project_id}")
        
        # Delete proposal documents from vector DB
        try:
            from app.services.proposal_analyzer import ProposalAnalyzer
            analyzer = ProposalAnalyzer()
            analyzer.delete_project_proposals(project_id)
            logger.info(f"🗑️ Deleted vector DB entries for: {project_id}")
        except Exception as e:
            logger.warning(f"⚠️ Failed to delete vector DB entries: {e}")
        
        # Delete uploaded proposal files
        proposals_dir = settings.DATA_DIR / "proposals"
        if proposals_dir.exists():
            deleted_files = 0
            for file in proposals_dir.glob(f"{project_id}_*"):
                try:
                    file.unlink()
                    deleted_files += 1
                except Exception as e:
                    logger.warning(f"⚠️ Failed to delete file {file}: {e}")
            
            if deleted_files > 0:
                logger.info(f"🗑️ Deleted {deleted_files} proposal file(s)")
        
        # Delete analysis reports
        reports_dir = settings.DATA_DIR / "reports"
        if reports_dir.exists():
            deleted_reports = 0
            for file in reports_dir.glob(f"{project_id}_*"):
                try:
                    file.unlink()
                    deleted_reports += 1
                except Exception as e:
                    logger.warning(f"⚠️ Failed to delete report {file}: {e}")
            
            if deleted_reports > 0:
                logger.info(f"🗑️ Deleted {deleted_reports} report file(s)")
        
        logger.info(f"✅ Successfully deleted project: {project_name}")
        
        return {
            "status": "deleted",
            "project_id": project_id,
            "message": f"Project '{project_name}' and all associated data deleted successfully"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Error deleting project: {e}")
        raise HTTPException(status_code=500, detail=str(e))
