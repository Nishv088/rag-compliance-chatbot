"""
Document management endpoints - for future document upload/management features
"""

from typing import List, Optional
from fastapi import APIRouter, UploadFile, File, HTTPException, Form
from pathlib import Path
import aiofiles
import uuid
from datetime import datetime

from app.config import settings
from app.services.document_processor import DocumentProcessor
from app.utils.logger import setup_logger

router = APIRouter()
logger = setup_logger("documents_api")

document_processor = DocumentProcessor()

class DocumentResponse:
    """Document upload response"""
    def __init__(self, document_id: str, filename: str, status: str, message: str):
        self.document_id = document_id
        self.filename = filename
        self.status = status
        self.message = message


@router.post("/documents/upload")
async def upload_document(
    file: UploadFile = File(...),
    session_id: Optional[str] = Form(None)
):
    """
    Upload a document for processing (PDF, DOCX, TXT)
    This endpoint allows users to upload additional documents for context
    """
    
    try:
        # Validate file type
        allowed_extensions = ['.pdf', '.docx', '.txt']
        file_extension = Path(file.filename).suffix.lower()
        
        if file_extension not in allowed_extensions:
            raise HTTPException(
                status_code=400,
                detail=f"File type {file_extension} not supported. Allowed: {', '.join(allowed_extensions)}"
            )
        
        # Generate unique document ID
        document_id = str(uuid.uuid4())
        
        # Create session-specific upload directory
        upload_dir = settings.SESSION_UPLOADS_DIR / (session_id or "default")
        upload_dir.mkdir(parents=True, exist_ok=True)
        
        # Save file
        file_path = upload_dir / f"{document_id}_{file.filename}"
        
        async with aiofiles.open(file_path, 'wb') as f:
            content = await file.read()
            await f.write(content)
        
        logger.info(f"✅ Document uploaded: {file.filename} ({len(content)} bytes)")
        
        # Process document (extract text)
        try:
            extracted_text = document_processor.process_document(str(file_path))
            
            return {
                "document_id": document_id,
                "filename": file.filename,
                "status": "success",
                "message": "Document uploaded and processed successfully",
                "file_size": len(content),
                "text_length": len(extracted_text),
                "upload_path": str(file_path)
            }
            
        except Exception as processing_error:
            logger.error(f"❌ Document processing failed: {processing_error}")
            
            return {
                "document_id": document_id,
                "filename": file.filename,
                "status": "uploaded_not_processed",
                "message": f"Document uploaded but processing failed: {str(processing_error)}",
                "file_size": len(content)
            }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Upload error: {e}")
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")


@router.get("/documents/session/{session_id}")
async def list_session_documents(session_id: str):
    """
    List all documents uploaded for a specific session
    """
    
    try:
        upload_dir = settings.SESSION_UPLOADS_DIR / session_id
        
        if not upload_dir.exists():
            return {"session_id": session_id, "documents": []}
        
        documents = []
        for file_path in upload_dir.glob("*"):
            if file_path.is_file():
                stat = file_path.stat()
                
                # Extract document ID and original filename
                parts = file_path.name.split("_", 1)
                document_id = parts[0] if len(parts) > 0 else "unknown"
                original_name = parts[1] if len(parts) > 1 else file_path.name
                
                documents.append({
                    "document_id": document_id,
                    "filename": original_name,
                    "file_size": stat.st_size,
                    "uploaded_at": datetime.fromtimestamp(stat.st_ctime).isoformat(),
                    "file_path": str(file_path)
                })
        
        return {
            "session_id": session_id,
            "document_count": len(documents),
            "documents": documents
        }
    
    except Exception as e:
        logger.error(f"❌ Error listing documents: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/documents/{document_id}")
async def delete_document(document_id: str, session_id: Optional[str] = None):
    """
    Delete a specific document
    """
    
    try:
        upload_dir = settings.SESSION_UPLOADS_DIR / (session_id or "default")
        
        # Find file with matching document_id
        matching_files = list(upload_dir.glob(f"{document_id}_*"))
        
        if not matching_files:
            raise HTTPException(status_code=404, detail="Document not found")
        
        file_path = matching_files[0]
        file_path.unlink()
        
        logger.info(f"🗑️ Deleted document: {file_path.name}")
        
        return {
            "status": "deleted",
            "document_id": document_id,
            "message": "Document deleted successfully"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Delete error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/documents/stats")
async def get_document_stats():
    """
    Get overall document statistics
    """
    
    try:
        total_documents = 0
        total_size = 0
        sessions_with_docs = 0
        
        for session_dir in settings.SESSION_UPLOADS_DIR.iterdir():
            if session_dir.is_dir():
                files = list(session_dir.glob("*"))
                if files:
                    sessions_with_docs += 1
                    for file_path in files:
                        if file_path.is_file():
                            total_documents += 1
                            total_size += file_path.stat().st_size
        
        return {
            "total_documents": total_documents,
            "total_size_bytes": total_size,
            "total_size_mb": round(total_size / (1024 * 1024), 2),
            "sessions_with_documents": sessions_with_docs
        }
    
    except Exception as e:
        logger.error(f"❌ Stats error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
