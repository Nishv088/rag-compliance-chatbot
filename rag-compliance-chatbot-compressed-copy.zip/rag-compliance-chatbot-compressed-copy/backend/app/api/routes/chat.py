# backend\app\api\routes\chat.py
"""
Enhanced chat endpoint with intent-based routing, file handling, and DUAL COLLECTION support
"""

import time
from typing import List, Optional
import os
from pathlib import Path
from fastapi import APIRouter, HTTPException, UploadFile, File, Form

from app.models.schemas import (
    ChatRequest, ChatResponse, ChatMessage, SuggestionsResponse
)
from app.services.retriever import QdrantRetriever
from app.services.intelligent_retriever import IntelligentRetriever
from app.services.llm_synthesizer import MultiTierLLMSynthesizer
from app.services.confidence_scorer import ConfidenceScorer
from app.services.chat_manager import ChatManager
from app.services.semantic_cache import SemanticQueryCache
from app.services.vision_analyzer import VisionAnalyzer
from app.services.document_processor import DocumentProcessor
from app.services.intent_detector import IntentDetector, GreetingDetector
from app.utils.logger import setup_logger
from app.api.routes.sessions import update_session_messages
from app.config import settings

router = APIRouter()
logger = setup_logger("chat_api")

# Setup upload directory
UPLOADS_DIR = settings.UPLOADS_DIR
logger.info(f"📁 Upload directory: {UPLOADS_DIR}")

# Initialize services
base_retriever = QdrantRetriever()
intelligent_retriever = IntelligentRetriever(base_retriever)
llm_synthesizer = MultiTierLLMSynthesizer()
chat_manager = ChatManager()
semantic_cache = SemanticQueryCache()
vision_analyzer = VisionAnalyzer()
document_processor = DocumentProcessor()
intent_detector = IntentDetector()
greeting_detector = GreetingDetector()

# Suggestion pool
SUGGESTION_POOL = [
    "What are the employer duties under Occupational Health & Safety Regulations?",
    "What are the minimum contents of a Health and Safety Plan before construction begins?",
    "What are the mandatory PPE requirements for workers on construction sites?",
    "What are the emergency and rescue arrangements for working at height?",
    "What are the documentation requirements for occupational accidents and incidents?",
    "What are the housekeeping and sanitation rules for workplaces under?",
    "What environmental nuisance controls are required for construction activities?",
    "What should be included in a Construction Environmental Management Plan (CEMP)?",
    "What are the main requirements of the Green Building thermal insulation regulation?",
    "When are Toolbox Talks or safety briefings mandatory at construction sites?",
    "What are the contractor's responsibilities for risk assessments on site?",
    "What are the key safety precautions for excavation works?",
    "What are the general requirements for personal protective equipment (PPE)?",
    "What are the rules for work at height under the construction safety code?",
    "What are the general duties of employees under Occupational Health & Safety law?",
]

# Store uploaded files per session
session_uploads = {}


@router.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """Main chat endpoint with intent-based routing and DUAL COLLECTION SEARCH"""
    start_time = time.time()
    try:
        logger.info(f"📩 Chat request from session {request.session_id}: {request.message[:100]}")
        
        # Extract project_id from session_id (format: "p123_conv456")
        project_id = None
        if hasattr(request, 'project_id'):
            project_id = request.project_id
        elif '_' in request.session_id:
            parts = request.session_id.split('_')
            if len(parts) >= 2 and parts[0].startswith('p'):
                project_id = parts[0]
        
        # Ensure session exists
        session_data = chat_manager.get_session(request.session_id)
        if not session_data:
            chat_manager.create_session(request.session_id)
        
        # Check for greeting first
        greeting_response = greeting_detector.detect_and_respond(request.message)
        if greeting_response:
            logger.info("👋 Responding to greeting")
            assistant_message = ChatMessage(
                role="assistant",
                content=greeting_response,
                confidence=100.0,
                citations=[],
                suggestions=[],
                followup_questions=[]  # ADDED
            )
            
            chat_manager.save_message(request.session_id, {"role": "user", "content": request.message})
            chat_manager.save_message(request.session_id, assistant_message.dict())
            
            processing_time = time.time() - start_time
            return ChatResponse(
                session_id=request.session_id,
                message=assistant_message,
                processing_time=processing_time
            )
        
        # Save user message
        chat_manager.save_message(request.session_id, {"role": "user", "content": request.message})
        
        # Check session uploads
        has_files = (
            request.session_id in session_uploads and
            'files' in session_uploads[request.session_id] and
            len(session_uploads[request.session_id]['files']) > 0
        )
        
        has_images = (
            request.session_id in session_uploads and
            'images' in session_uploads[request.session_id] and
            len(session_uploads[request.session_id]['images']) > 0
        )
        
        logger.info(f"📊 Session state - Files: {has_files}, Images: {has_images}, Project: {project_id}")
        
        # Detect intent
        intent = intent_detector.detect_intent(
            query=request.message,
            has_uploaded_files=has_files,
            has_uploaded_images=has_images,
            chat_history=request.history
        )
        
        response_text = ""
        confidence = 50.0
        citations = []
        suggestions = []
        followup_questions = []  # ADDED
        
        # ==================== ROUTE BY INTENT ====================
        
        # CASE 1: AUTO-SUMMARIZE FILE
        if intent == "auto_summarize":
            logger.info("📄 Processing: Auto-summarize file")
            if not has_files:
                response_text = "No file found to summarize. Please upload a file first."
                confidence = 30.0
            else:
                file_content = session_uploads[request.session_id]['files'][0]['content']
                summary_prompt = f"""Please provide a comprehensive summary of the uploaded file.

**File Content:**
{file_content[:8000]}

**Instructions:**
- Provide a well-structured summary
- Highlight key points and main topics
- Use clear headings and bullet points
- Keep the summary professional and concise"""
                
                try:
                    llm_result = llm_synthesizer.clients['openai'].chat.completions.create(
                        model="gpt-4o-mini",
                        messages=[{"role": "user", "content": summary_prompt}],
                        temperature=0.3,
                        max_tokens=1500
                    )
                    response_text = llm_result.choices[0].message.content
                    confidence = 92.0
                except Exception as e:
                    logger.error(f"Auto-summarize failed: {e}")
                    response_text = f"**File Summary:**\n\n{file_content[:2000]}..."
                    confidence = 75.0
        
        # CASE 2: AUTO-SUMMARIZE IMAGE
        elif intent == "auto_summarize_image":
            logger.info("🖼️ Processing: Auto-summarize image")
            if not has_images:
                response_text = "No image found to analyze. Please upload an image first."
                confidence = 30.0
            else:
                auto_prompt = """Provide a comprehensive analysis of this image:
1. **Main Content:** What is shown in the image?
2. **Key Details:** Any measurements, dimensions, specifications, text, or labels visible
3. **Context:** Purpose, setting, or application
4. **Notable Features:** Materials, colors, construction, conditions
5. **Technical Information:** Any diagrams, charts, or technical elements

Be thorough and professional in your analysis."""
                
                try:
                    image_data = session_uploads[request.session_id]['images'][0]
                    result = vision_analyzer.analyze_image(
                        image_data=image_data['data'],
                        user_prompt=auto_prompt,
                        mime_type=image_data['mime_type']
                    )
                    response_text = f"## 🖼️ Image Analysis\n\n{result}"
                    confidence = 90.0
                except Exception as e:
                    logger.error(f"Image auto-summarize failed: {e}")
                    response_text = "I couldn't analyze the uploaded image. Please try again."
                    confidence = 30.0
        
        # CASE 3: FILE-ONLY ANALYSIS
        elif intent == "file_only":
            logger.info("📄 Processing: File-only analysis")
            if not has_files:
                response_text = "No file found to analyze. Please upload a file first."
                confidence = 30.0
            else:
                file_content = session_uploads[request.session_id]['files'][0]['content']
                file_prompt = f"""Answer the user's question based ONLY on the uploaded file content.

**User Question:**
{request.message}

**File Content:**
{file_content[:8000]}

**Instructions:**
- Answer directly and accurately
- Quote relevant sections from the file
- Stay focused on the file content only
- Format your answer professionally"""
                
                try:
                    llm_result = llm_synthesizer.clients['openai'].chat.completions.create(
                        model="gpt-4o-mini",
                        messages=[{"role": "user", "content": file_prompt}],
                        temperature=0.2,
                        max_tokens=2000
                    )
                    response_text = llm_result.choices[0].message.content
                    confidence = 90.0
                except Exception as e:
                    logger.error(f"File-only analysis failed: {e}")
                    response_text = f"Error analyzing file: {e}"
                    confidence = 30.0
        
        # CASE 4: IMAGE VISION ANALYSIS
        elif intent == "image_vision":
            logger.info("🖼️ Processing: Image vision analysis")
            if not has_images:
                response_text = "No image found to analyze. Please upload an image first."
                confidence = 30.0
            else:
                try:
                    image_data = session_uploads[request.session_id]['images'][0]
                    result = vision_analyzer.analyze_image(
                        image_data=image_data['data'],
                        user_prompt=request.message,
                        mime_type=image_data['mime_type']
                    )
                    response_text = result
                    confidence = 88.0
                except Exception as e:
                    logger.error(f"Image vision failed: {e}")
                    response_text = f"Error analyzing image: {e}"
                    confidence = 30.0
        
        # CASE 5: FILE + KB HYBRID
        elif intent == "file_kb_hybrid":
            logger.info("🔗 Processing: File + KB hybrid")
            if not has_files:
                response_text = "No file found. Please upload a file first."
                confidence = 30.0
            else:
                # Retrieve from KB
                chunks = intelligent_retriever.retrieve_with_intelligence(
                    query=request.message,
                    top_k=5
                )
                
                # Add file content as high-priority chunk
                file_content = session_uploads[request.session_id]['files'][0]['content']
                file_chunk = {
                    'metadata': {
                        'text': f"**UPLOADED FILE CONTENT (High Priority):**\n\n{file_content[:10000]}",
                        'section_title': "Uploaded File Content",
                        'section_no': "FILE-001",
                        'document_name': "Uploaded File"
                    },
                    'merged_text': file_content[:10000],
                    'score': 0.95,
                    'id': "uploaded_file"
                }
                
                # Combine
                combined_chunks = [file_chunk] + chunks
                context = base_retriever.get_context_string(combined_chunks)
                
                # Generate response
                llm_result = llm_synthesizer.generate_response(
                    query=request.message,
                    context=context,
                    conversation_history=request.history
                )
                
                if llm_result["success"]:
                    response_text = llm_result["response"]
                    is_followup = len(request.history) > 0
                    confidence = ConfidenceScorer.calculate_confidence(
                        retrieved_chunks=chunks,
                        query=request.message,
                        response_text=response_text,
                        is_followup=is_followup
                    )
                    
                    # Build citations from KB chunks only
                    for i, chunk in enumerate(chunks[:5], 1):
                        metadata = chunk["metadata"]
                        citations.append({
                            "id": f"S{i}",
                            "title": metadata.get("section_title", "Unknown"),
                            "text": chunk.get("text", chunk.get("merged_text", ""))[:200] + "...",
                            "section_no": metadata.get("section_no", "N/A"),
                            "page_no": str(metadata.get("page_no", "N/A")),
                            "confidence": round(chunk["score"] * 100, 1),
                            "document_name": metadata.get("document_name", "Unknown")
                        })
                else:
                    response_text = "I couldn't generate a response. Please try again."
                    confidence = 30.0
        
        # CASE 6: KB ONLY (Standard RAG) - WITH DUAL COLLECTION SUPPORT
        else:
            logger.info("📚 Processing: Standard KB query (with proposal support)")
            
            # Check cache first
            cached = semantic_cache.get(request.session_id, request.message)
            if cached:
                logger.info("🎯 Using cached response")
                response_text = cached['response']
                confidence = cached['confidence']
                citations = cached.get('citations', [])
                followup_questions = cached.get('followup_questions', [])  # ADDED
            else:
                # ====== DUAL COLLECTION SEARCH ======
                # Search compliance collection (main KB)
                chunks = intelligent_retriever.retrieve_with_intelligence(
                    query=request.message,
                    top_k=5
                )
                
                # Search proposal collection if project_id exists
                proposal_chunks = []
                if project_id:
                    try:
                        from app.services.vector_store import VectorStore
                        vector_store = VectorStore()
                        proposal_results = vector_store.search_proposals(
                            query=request.message,
                            project_id=project_id,
                            top_k=3
                        )
                        
                        if proposal_results:
                            logger.info(f"📋 Found {len(proposal_results)} proposal matches")
                            # Convert proposal results to chunk format
                            import json
                            for result in proposal_results:
                                payload = result.get('payload', {})
                                report = payload.get('report', {})
                                proposal_chunks.append({
                                    'metadata': {
                                        'text': json.dumps(report, indent=2)[:2000],
                                        'section_title': f"Proposal: {payload.get('document_name', 'Unknown')}",
                                        'section_no': 'PROPOSAL',
                                        'document_name': payload.get('document_name', 'Unknown'),
                                        'type': 'proposal'
                                    },
                                    'merged_text': json.dumps(report, indent=2)[:2000],
                                    'score': result.get('score', 0.7),
                                    'id': result.get('id', 'proposal')
                                })
                    except Exception as e:
                        logger.warning(f"Proposal search failed: {e}")
                
                # Combine compliance + proposal chunks
                all_chunks = chunks + proposal_chunks
                
                if not all_chunks:
                    response_text = "I couldn't find relevant information to answer your question."
                    confidence = 40.0
                else:
                    # Generate response with dual context awareness
                    context = base_retriever.get_context_string(all_chunks)
                    
                    # Use enhanced generation if we have both types
                    has_proposals = len(proposal_chunks) > 0
                    if has_proposals and hasattr(llm_synthesizer, 'generate_response_with_proposal'):
                        # Build separate contexts
                        compliance_context = base_retriever.get_context_string(chunks)
                        proposal_context = base_retriever.get_context_string(proposal_chunks)
                        
                        llm_result = llm_synthesizer.generate_response_with_proposal(
                            query=request.message,
                            compliance_context=compliance_context,
                            proposal_context=proposal_context,
                            conversation_history=request.history,
                            has_proposal=True
                        )
                    else:
                        # Standard generation
                        llm_result = llm_synthesizer.generate_response(
                            query=request.message,
                            context=context,
                            conversation_history=request.history
                        )
                    
                    if llm_result["success"]:
                        response_text = llm_result["response"]
                        
                        # Calculate confidence
                        is_followup = len(request.history) > 0
                        confidence = ConfidenceScorer.calculate_confidence(
                            retrieved_chunks=all_chunks,
                            query=request.message,
                            response_text=response_text,
                            is_followup=is_followup
                        )
                        
                        # Build citations (mark proposal sources differently)
                        for i, chunk in enumerate(all_chunks[:7], 1):
                            metadata = chunk["metadata"]
                            is_proposal = metadata.get('type') == 'proposal'
                            
                            citations.append({
                                "id": f"{'P' if is_proposal else 'S'}{i}",
                                "title": metadata.get("section_title", "Unknown"),
                                "text": chunk.get("text", chunk.get("merged_text", ""))[:200] + "...",
                                "section_no": metadata.get("section_no", "N/A"),
                                "page_no": str(metadata.get("page_no", "N/A")),
                                "confidence": round(chunk["score"] * 100, 1),
                                "document_name": metadata.get("document_name", "Unknown"),
                                "type": "proposal" if is_proposal else "compliance"
                            })
                        
                        # Cache response with followup questions
                        semantic_cache.set(
                            session_id=request.session_id,
                            query=request.message,
                            response=response_text,
                            confidence=confidence,
                            chunks=all_chunks,
                            followup_questions=followup_questions  # ADDED
                        )
                    else:
                        response_text = "I couldn't generate a response. Please try again."
                        confidence = 30.0
        
        # ENHANCED: Generate follow-up questions (not just suggestions)
        if confidence >= 70:
            try:
                # Generate intelligent follow-up questions
                followup_questions = llm_synthesizer.generate_followup_questions(
                    answer=response_text,
                    original_question=request.message
                )
                logger.info(f"✅ Generated {len(followup_questions)} follow-up questions")
            except Exception as e:
                logger.warning(f"⚠️ Failed to generate follow-up questions: {e}")
                followup_questions = []
            
            # Still generate quick suggestions for backward compatibility
            suggestions = followup_questions[:3] if followup_questions else []
        
        # Create assistant message with followup_questions
        assistant_message = ChatMessage(
            role="assistant",
            content=response_text,
            confidence=confidence,
            citations=citations,
            suggestions=suggestions,
            followup_questions=followup_questions  # ADDED
        )
        
        # Save assistant message
        chat_manager.save_message(request.session_id, assistant_message.dict())
        
        # Update session storage
        try:
            all_messages = chat_manager.get_messages(request.session_id)
            serializable_messages = []
            for msg in all_messages:
                if hasattr(msg, 'dict'):
                    serializable_messages.append(msg.dict())
                elif hasattr(msg, 'model_dump'):
                    serializable_messages.append(msg.model_dump())
                elif isinstance(msg, dict):
                    serializable_messages.append(msg)
                else:
                    # Fallback for unknown types
                    serializable_messages.append({
                        "role": getattr(msg, 'role', 'assistant'),
                        "content": getattr(msg, 'content', str(msg))
                    })
            
            update_session_messages(request.session_id, serializable_messages)
            logger.info(f"💾 Updated session {request.session_id} with {len(serializable_messages)} messages")
        except Exception as e:
            logger.warning(f"⚠️ Failed to update session storage: {e}")
        
        processing_time = time.time() - start_time
        logger.info(f"✅ Response generated in {processing_time:.2f}s (confidence: {confidence}%)")
        
        return ChatResponse(
            session_id=request.session_id,
            message=assistant_message,
            processing_time=processing_time
        )
    
    except Exception as e:
        logger.error(f"❌ Chat error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/upload")
async def upload_file(
    session_id: str = Form(...),
    file: UploadFile = File(...)
):
    """Upload and process a file for the session"""
    try:
        logger.info(f"📎 Uploading file: {file.filename} for session {session_id}")
        
        # Read file content
        file_data = await file.read()
        
        # Initialize session uploads
        if session_id not in session_uploads:
            session_uploads[session_id] = {'files': [], 'images': []}
        
        # Check if image
        if file.content_type and file.content_type.startswith('image/'):
            session_uploads[session_id]['images'].append({
                'filename': file.filename,
                'data': file_data,
                'mime_type': file.content_type
            })
            logger.info(f"✅ Image uploaded: {file.filename}")
            return {
                "status": "success",
                "type": "image",
                "filename": file.filename,
                "message": "Image uploaded successfully"
            }
        
        # Process document
        else:
            # Save to uploads directory
            file_path = UPLOADS_DIR / f"{session_id}_{file.filename}"
            with open(file_path, 'wb') as f:
                f.write(file_data)
            logger.info(f"💾 File saved to: {file_path}")
            
            # Extract text
            try:
                extracted_text = document_processor.process_document(str(file_path))
            except Exception as e:
                logger.warning(f"Document processing failed, using raw content: {e}")
                try:
                    extracted_text = file_data.decode('utf-8', errors='ignore')
                except:
                    extracted_text = "Unable to extract text from file."
            
            session_uploads[session_id]['files'].append({
                'filename': file.filename,
                'content': extracted_text,
                'size': len(file_data),
                'path': str(file_path)
            })
            
            logger.info(f"✅ File processed: {file.filename} ({len(extracted_text)} chars)")
            return {
                "status": "success",
                "type": "document",
                "filename": file.filename,
                "text_length": len(extracted_text),
                "message": "File uploaded and processed successfully"
            }
    
    except Exception as e:
        logger.error(f"❌ Upload error: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/upload/{session_id}")
async def clear_uploads(session_id: str):
    """Clear uploaded files for a session"""
    if session_id in session_uploads:
        # Delete physical files
        if 'files' in session_uploads[session_id]:
            for file_info in session_uploads[session_id]['files']:
                if 'path' in file_info:
                    try:
                        file_path = Path(file_info['path'])
                        if file_path.exists():
                            file_path.unlink()
                        logger.info(f"🗑️ Deleted file: {file_path}")
                    except Exception as e:
                        logger.warning(f"Failed to delete file: {e}")
        
        del session_uploads[session_id]
        logger.info(f"🗑️ Cleared uploads for session {session_id}")
    
    return {"status": "cleared", "session_id": session_id}


@router.get("/suggestions", response_model=SuggestionsResponse)
async def get_suggestions():
    """Get random starter suggestions"""
    import random
    suggestions = random.sample(SUGGESTION_POOL, min(6, len(SUGGESTION_POOL)))
    return SuggestionsResponse(suggestions=suggestions)
