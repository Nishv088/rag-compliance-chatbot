"""
Proposal document upload and analysis endpoints
"""

from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from typing import List
from pathlib import Path
import json
import shutil

from app.services.proposal_analyzer import ProposalAnalyzer
from app.services.retriever import QdrantRetriever
from app.config import settings
from app.utils.logger import setup_logger

router = APIRouter()
logger = setup_logger("proposals_api")

# Initialize services
analyzer = ProposalAnalyzer()
retriever = QdrantRetriever()


@router.post("/upload")
async def upload_proposal(
    project_id: str = Form(...),
    files: List[UploadFile] = File(...)
):
    """Upload proposal documents for a project"""
    try:
        uploaded_files = []
        proposals_dir = settings.DATA_DIR / "proposals"
        proposals_dir.mkdir(parents=True, exist_ok=True)
        
        for file in files:
            # Generate unique filename
            file_path = proposals_dir / f"{project_id}_{file.filename}"
            
            # Save file
            with open(file_path, "wb") as buffer:
                content = await file.read()
                buffer.write(content)
            
            uploaded_files.append({
                "filename": file.filename,
                "path": str(file_path),
                "size": len(content)
            })
            
            logger.info(f"✅ Uploaded: {file.filename} ({len(content)} bytes)")
        
        return {
            "success": True,
            "files": uploaded_files,
            "message": f"Successfully uploaded {len(uploaded_files)} file(s)"
        }
    
    except Exception as e:
        logger.error(f"❌ Upload failed: {e}")
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")


@router.post("/analyze")
async def analyze_proposals(
    project_id: str = Form(...),
    conversation_id: str = Form(...),
    file_paths: List[str] = Form(...)
):
    """Analyze uploaded proposal documents against compliance requirements"""
    logger.info(f"🔍 Starting analysis for project {project_id}")
    logger.info(f"📄 Files to analyze: {len(file_paths)}")
    
    try:
        # Validate files exist
        for file_path in file_paths:
            if not Path(file_path).exists():
                raise HTTPException(status_code=404, detail=f"File not found: {file_path}")
        
        # Get compliance context from knowledge base
        compliance_query = "Dubai construction compliance health safety environment energy requirements regulations"
        compliance_chunks = retriever.retrieve(compliance_query, top_k=10)
        
        logger.info(f"✅ Retrieved {len(compliance_chunks)} compliance chunks")
        
        if len(compliance_chunks) == 0:
            logger.warning("⚠️ No compliance chunks retrieved, using empty context")
        
        # Perform analysis
        result = analyzer.analyze_and_save(
            file_paths=file_paths,
            project_id=project_id,
            conversation_id=conversation_id,
            compliance_sources=compliance_chunks
        )
        
        if not result.get("success", False):
            error_msg = result.get("error", "Unknown analysis error")
            logger.error(f"❌ Analysis failed: {error_msg}")
            return {
                "success": False,
                "error": error_msg
            }
        
        logger.info(f"✅ Analysis completed successfully")
        logger.info(f"📊 Analysis ID: {result.get('analysis_id')}")
        logger.info(f"📁 Report saved to: {result.get('report_path')}")
        
        return {
            "success": True,
            "analysis_id": result["analysis_id"],
            "report": result["report"],
            "report_path": result["report_path"],
            "message": "Analysis completed successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Analysis error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")


@router.post("/update-context")
async def update_context(
    project_id: str = Form(...),
    conversation_id: str = Form(...),
    file_paths: List[str] = Form(...)
):
    """Update proposal context - deletes old analysis and creates new one"""
    logger.info(f"🔄 Updating context for project {project_id}")
    
    try:
        # Delete old analysis from vector DB
        analyzer.delete_project_proposals(project_id)
        logger.info(f"🗑️ Deleted old analysis for project {project_id}")
        
        # Delete old report files
        reports_dir = settings.DATA_DIR / "reports"
        if reports_dir.exists():
            for report_file in reports_dir.glob(f"{project_id}_*.json"):
                report_file.unlink()
                logger.info(f"🗑️ Deleted old report: {report_file.name}")
        
        # Perform new analysis
        return await analyze_proposals(project_id, conversation_id, file_paths)
    
    except Exception as e:
        logger.error(f"❌ Update context failed: {e}")
        raise HTTPException(status_code=500, detail=f"Update failed: {str(e)}")


@router.get("/report/{project_id}")
async def get_report(project_id: str):
    """Get the latest analysis report for a project"""
    logger.info(f"📊 Fetching report for project {project_id}")
    
    try:
        # First try to get from vector DB
        report = analyzer.get_project_report(project_id)
        
        if report:
            logger.info(f"✅ Retrieved report from vector DB")
            return {
                "success": True,
                "report": report,
                "source": "vector_db"
            }
        
        # If not in vector DB, try to load from file system
        reports_dir = settings.DATA_DIR / "reports"
        
        if not reports_dir.exists():
            logger.warning(f"⚠️ Reports directory does not exist")
            raise HTTPException(status_code=404, detail="No reports found")
        
        report_files = list(reports_dir.glob(f"{project_id}_*.json"))
        
        if not report_files:
            logger.warning(f"⚠️ No report files found for project {project_id}")
            raise HTTPException(status_code=404, detail="No report found for this project")
        
        # Get most recent report
        latest_report = max(report_files, key=lambda p: p.stat().st_mtime)
        
        logger.info(f"✅ Loading report from file: {latest_report.name}")
        
        with open(latest_report, 'r', encoding='utf-8') as f:
            report_data = json.load(f)
        
        return {
            "success": True,
            "report": report_data,
            "source": "file_system",
            "file": latest_report.name
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Failed to get report: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve report: {str(e)}")


@router.get("/files/{project_id}")
async def get_project_files(project_id: str):
    """Get list of uploaded proposal files for a project"""
    try:
        proposals_dir = settings.DATA_DIR / "proposals"
        
        if not proposals_dir.exists():
            return {"files": []}
        
        files = list(proposals_dir.glob(f"{project_id}_*"))
        
        file_list = []
        for file in files:
            file_list.append({
                "filename": file.name.replace(f"{project_id}_", ""),
                "path": str(file),
                "size": file.stat().st_size,
                "uploaded_at": file.stat().st_mtime,
                "modified": datetime.fromtimestamp(file.stat().st_mtime).isoformat()
            })
        
        # Sort by upload time (most recent first)
        file_list.sort(key=lambda x: x["uploaded_at"], reverse=True)
        
        logger.info(f"📁 Retrieved {len(file_list)} file(s) for project {project_id}")
        
        return {
            "success": True,
            "files": file_list,
            "count": len(file_list)
        }
    
    except Exception as e:
        logger.error(f"❌ Failed to get files: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve files: {str(e)}")


@router.delete("/files/{project_id}")
async def delete_project_files(project_id: str):
    """Delete all proposal files for a project"""
    try:
        proposals_dir = settings.DATA_DIR / "proposals"
        
        if not proposals_dir.exists():
            return {"success": True, "deleted": 0, "message": "No files to delete"}
        
        files = list(proposals_dir.glob(f"{project_id}_*"))
        deleted_count = 0
        
        for file in files:
            try:
                file.unlink()
                deleted_count += 1
                logger.info(f"🗑️ Deleted file: {file.name}")
            except Exception as e:
                logger.warning(f"⚠️ Failed to delete file {file.name}: {e}")
        
        return {
            "success": True,
            "deleted": deleted_count,
            "message": f"Deleted {deleted_count} file(s)"
        }
    
    except Exception as e:
        logger.error(f"❌ Failed to delete files: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Import datetime for file metadata
from datetime import datetime
