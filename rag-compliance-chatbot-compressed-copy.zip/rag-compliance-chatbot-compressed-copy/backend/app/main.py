"""
Main FastAPI application entry point
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime
from pathlib import Path

from app.config import settings
from app.models.schemas import HealthResponse
from app.api.routes import chat, sessions, projects, proposals  # ADD proposals
from app.utils.logger import setup_logger

logger = setup_logger("main")

# Create data directories
Path("data/sessions").mkdir(parents=True, exist_ok=True)
Path("data/projects").mkdir(parents=True, exist_ok=True)
Path("data/cache").mkdir(parents=True, exist_ok=True)
Path("data/uploads").mkdir(parents=True, exist_ok=True)
Path("data/proposals").mkdir(parents=True, exist_ok=True)  # NEW
Path("data/reports").mkdir(parents=True, exist_ok=True)    # NEW

# Create FastAPI app
app = FastAPI(
    title=settings.API_TITLE,
    version=settings.API_VERSION,
    description="Dubai Compliance RAG Chatbot API with Proposal Analysis"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ✅ Register all routers
app.include_router(chat.router, prefix="/api", tags=["Chat"])
app.include_router(sessions.router, prefix="/api/sessions", tags=["Sessions"])
app.include_router(projects.router, prefix="/api/projects", tags=["Projects"])
app.include_router(proposals.router, prefix="/api/proposals", tags=["Proposals"])  # NEW

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": settings.API_TITLE,
        "version": settings.API_VERSION,
        "status": "running",
        "endpoints": {
            "chat": "/api/chat",
            "sessions": "/api/sessions",
            "projects": "/api/projects",
            "proposals": "/api/proposals",  # NEW
            "upload": "/api/upload"
        }
    }

@app.get("/health", response_model=HealthResponse)
async def health():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy",
        timestamp=datetime.now(),
        version=settings.API_VERSION
    )

@app.on_event("startup")
async def startup_event():
    """Run on startup"""
    logger.info(f"🚀 {settings.API_TITLE} v{settings.API_VERSION} starting...")
    logger.info(f"📁 Data directory: {settings.DATA_DIR}")
    logger.info(f"🗄️ Qdrant: {settings.QDRANT_HOST}:{settings.QDRANT_PORT}")
    logger.info(f"📚 Collections: {settings.QDRANT_COLLECTION}, proposal_documents")
    logger.info(f"✅ API Endpoints: /api/chat, /api/sessions, /api/projects, /api/proposals")

@app.on_event("shutdown")
async def shutdown_event():
    """Run on shutdown"""
    logger.info("👋 Shutting down...")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host=settings.API_HOST,
        port=settings.API_PORT,
        reload=True
    )
