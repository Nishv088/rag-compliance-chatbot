# backend\app\config.py
import os
from pathlib import Path
from pydantic_settings import BaseSettings
from dotenv import load_dotenv

load_dotenv()

class Settings(BaseSettings):
    # API Configuration
    API_TITLE: str = "Dubai Compliance RAG API"
    API_VERSION: str = "1.0.0"
    API_HOST: str = "0.0.0.0"
    API_PORT: int = 8000
    
    # CORS
    CORS_ORIGINS: list = ["http://localhost:3000", "http://127.0.0.1:3000"]
    
    # Paths
    PROJECT_ROOT: Path = Path(__file__).parent.parent.parent
    DATA_DIR: Path = PROJECT_ROOT / "backend" / "data"

    # data subdirectories
    CHAT_HISTORIES_DIR: Path = DATA_DIR / "chat_histories"
    CACHE_DIR: Path = DATA_DIR / "cache"
    SESSION_DIR: Path = DATA_DIR / "sessions"
    UPLOADS_DIR: Path = DATA_DIR / "uploads"    
    PROJECTS_DIR: Path = DATA_DIR / "projects" 
    PROPOSALS_DIR: Path = DATA_DIR / "proposals" 
    REPORTS_DIR: Path = DATA_DIR / "reports"         
    LOGS_DIR: Path = DATA_DIR / "logs"
    WF2_OUTPUT_DIR: Path = DATA_DIR / "categorized_chunks_output"
    WF3_OUTPUT_DIR: Path = DATA_DIR / "qdrant_ingested_output"

    # Qdrant Configuration
    QDRANT_HOST: str = os.getenv("QDRANT_HOST", "localhost")
    QDRANT_PORT: int = int(os.getenv("QDRANT_PORT", "6333"))
    QDRANT_COLLECTION: str = os.getenv("QDRANT_COLLECTION", "dubai_compliance")
    QDRANT_PROPOSAL_COLLECTION: str = os.getenv("QDRANT_PROPOSAL_COLLECTION", "proposal_documents")
    
    # OpenAI Configuration
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    OPENAI_RESPONSE_MODEL: str = os.getenv("OPENAI_RESPONSE_MODEL", "gpt-4o-mini")
    OPENAI_EMBEDDING_MODEL: str = os.getenv("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small")
    
    # Groq Configuration (Fallback)
    GROQ_API_KEY: str = os.getenv("GROQ_API_KEY", "")
    GROQ_RESPONSE_MODEL: str = os.getenv("GROQ_RESPONSE_MODEL", "mixtral-8x7b-32768")
    
    # RAG Configuration
    TOP_K_CHUNKS: int = 10
    SIMILARITY_THRESHOLD: float = 0.35
    MAX_CONTEXT_LENGTH: int = 12000
    
    # LLM Configuration
    LLM_TEMPERATURE: float = 0.1
    MAX_TOKENS: int = 3000
    
    #embedding configuration
    EMBEDDING_DIMENSION: int = 1024

    class Config:
        env_file = ".env"

# Create directories
settings = Settings()
settings.CHAT_HISTORIES_DIR.mkdir(parents=True, exist_ok=True)
settings.CACHE_DIR.mkdir(parents=True, exist_ok=True)
settings.SESSION_DIR.mkdir(parents=True, exist_ok=True)
settings.UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
settings.PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
settings.PROPOSALS_DIR.mkdir(parents=True, exist_ok=True)
settings.REPORTS_DIR.mkdir(parents=True, exist_ok=True)
settings.LOGS_DIR.mkdir(parents=True, exist_ok=True)
