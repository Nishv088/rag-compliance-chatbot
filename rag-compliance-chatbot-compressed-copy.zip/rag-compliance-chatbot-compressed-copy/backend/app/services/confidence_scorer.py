import re
from typing import List, Dict

class ConfidenceScorer:
    """Calculate confidence scores for responses"""
    
    @staticmethod
    def calculate_confidence(
        retrieved_chunks: List[Dict],
        query: str,
        response_text: str,
        is_followup: bool = False
    ) -> float:
        """Calculate overall confidence score (50-95% range)"""
        
        if not retrieved_chunks or not response_text:
            return 50.0
        
        # Component scores
        retrieval_score = ConfidenceScorer._score_retrieval(retrieved_chunks, query)
        response_score = ConfidenceScorer._score_response(response_text, query)
        specificity_score = ConfidenceScorer._score_query_specificity(query)
        alignment_score = ConfidenceScorer._score_alignment(response_text, retrieved_chunks)
        
        # Weighted combination
        confidence = (
            0.30 * retrieval_score +
            0.40 * response_score +
            0.15 * specificity_score +
            0.15 * alignment_score
        )
        
        # Follow-up boost
        if is_followup:
            confidence *= 1.05
        
        # Apply penalties
        confidence = ConfidenceScorer._apply_penalties(confidence, response_text, query)
        
        # Floor at 50%, cap at 95%
        return min(max(round(confidence, 0), 50), 95)
    
    @staticmethod
    def _score_retrieval(chunks: List[Dict], query: str) -> float:
        """Score based on retrieval quality"""
        
        if not chunks:
            return 50.0
        
        scores = [c.get('score', 0) for c in chunks]
        max_score = max(scores) if scores else 0
        avg_score = sum(scores) / len(scores) if scores else 0
        
        # Adjust thresholds for Pinecone scores (typically 0.40-0.75)
        if max_score > 0.68:
            base_confidence = 95
        elif max_score > 0.60:
            base_confidence = 92
        elif max_score > 0.52:
            base_confidence = 88
        elif max_score > 0.45:
            base_confidence = 84
        elif max_score > 0.38:
            base_confidence = 78
        else:
            base_confidence = 70
        
        # Boost for consistent high scores
        if avg_score > 0.55 and max_score > 0.60:
            base_confidence = min(98, base_confidence + 6)
        elif avg_score > 0.48 and max_score > 0.52:
            base_confidence = min(95, base_confidence + 4)
        
        return min(base_confidence, 98)
    
    @staticmethod
    def _score_response(response: str, query: str) -> float:
        """Score response quality"""
        
        if not response or len(response) < 10:
            return 40.0
        
        score = 75.0
        
        # Has numbers/data
        if re.search(r'\d+', response):
            score += 8
        
        # Has structure
        if any(indicator in response for indicator in ['##', '|', '\n-', '\n1.', 'Table']):
            score += 10
        
        # Has citations
        citations = len(re.findall(r'Section|Table|Article|Page', response))
        if citations > 0:
            score += min(citations * 2, 10)
        
        # Comprehensive answer
        word_count = len(response.split())
        if word_count > 100:
            score += 5
        if word_count > 200:
            score += 5
        
        # Query keyword overlap
        query_words = set(query.lower().split())
        response_words = set(response.lower().split())
        overlap = len(query_words & response_words)
        if overlap > 3:
            score += min(overlap, 8)
        
        return min(score, 95.0)
    
    @staticmethod
    def _score_query_specificity(query: str) -> float:
        """Score query specificity"""
        
        query_lower = query.lower()
        
        # Very specific references
        if re.search(r'section\s+\d+\.\d+\.\d+', query_lower):
            return 95
        if re.search(r'table\s+\d+|item\s+[a-z]-?\d+', query_lower):
            return 95
        
        # Quantitative queries
        if re.search(r'\d+\s+\w+', query_lower):
            return 90
        
        # Definition/calculation queries
        if any(w in query_lower for w in ['how many', 'calculate', 'what is', 'definition']):
            return 90
        
        # Requirement queries
        if any(w in query_lower for w in ['requirement', 'mandatory', 'must']):
            return 85
        
        return 75
    
    @staticmethod
    def _score_alignment(response: str, chunks: List[Dict]) -> float:
        """Check source-response alignment"""
        
        chunk_texts = ' '.join([
            c.get('merged_text', c.get('metadata', {}).get('text', ''))[:500]
            for c in chunks[:3]
        ]).lower()
        
        response_lower = response.lower()
        score = 50
        
        # Technical terms alignment
        technical_terms = ['section', 'table', 'requirement', 'regulation', 'compliance', 'mandatory']
        alignment = sum(1 for term in technical_terms if term in chunk_texts and term in response_lower)
        score += min(alignment * 5, 30)
        
        # Numeric alignment
        chunk_numbers = set(re.findall(r'\d+\.?\d*', chunk_texts))
        response_numbers = set(re.findall(r'\d+\.?\d*', response_lower))
        
        if chunk_numbers and response_numbers:
            overlap = len(chunk_numbers & response_numbers) / len(chunk_numbers)
            score += overlap * 20
        
        return min(score, 100)
    
    @staticmethod
    def _apply_penalties(score: float, response: str, query: str) -> float:
        """Apply penalties for quality issues"""
        
        # Penalty for failed responses
        negative_phrases = ['could not find', 'no information available', 'unable to locate', 
                          'I cannot find', 'not available in']
        if any(p in response.lower() for p in negative_phrases):
            score *= 0.80
        
        # Penalty for very short responses
        if len(response.split()) < 10:
            score *= 0.90
        
        # Penalty for missing tables
        if 'table' in query.lower():
            has_table = ('|' in response or 'Table' in response or '---' in response)
            has_structure = (bool(re.search(r'\d+\s*[:\-]\s*\d+', response)) or 
                           response.count('\n') > 5)
            if not (has_table or has_structure):
                score *= 0.92
        
        return round(min(max(score, 0), 98), 0)
