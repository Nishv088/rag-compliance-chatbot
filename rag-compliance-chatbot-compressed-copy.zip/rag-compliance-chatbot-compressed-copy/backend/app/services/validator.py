"""
Response validation service - validates responses against retrieved chunks
"""

import re
from typing import List, Dict, Any
from app.utils.logger import setup_logger

logger = setup_logger("validator")


class ResponseValidator:
    """Validates responses against retrieved chunks to ensure accuracy"""
    
    def __init__(self):
        self.validation_patterns = {
            'numerical_mismatch': r'\d+\.?\d*\s*(minutes?|meters?|km/h|knots|%|m²)',
            'table_indicators': r'(table|column|row)',
            'formula_indicators': r'(formula|equation|calculate)'
        }
    
    def validate_response(
        self,
        response: str,
        chunks: List[Dict],
        query: str
    ) -> Dict[str, Any]:
        """
        Validate response completeness and accuracy.
        Returns validation results with specific issues found.
        """
        
        issues = []
        warnings = []
        
        # 1. Check if table query has complete table
        if any(word in query.lower() for word in ['table', 'show', 'display', 'complete']):
            table_check = self._validate_table_completeness(response, chunks, query)
            if not table_check['is_complete']:
                issues.extend(table_check['missing_elements'])
        
        # 2. Check numerical consistency between chunks and response
        numerical_check = self._validate_numerical_consistency(response, chunks)
        if not numerical_check['consistent']:
            warnings.append(f"Numerical values may be inconsistent: {numerical_check['details']}")
        
        # 3. Check formula rendering
        if 'formula' in query.lower() or 'equation' in query.lower():
            formula_check = self._validate_formula_rendering(response)
            if not formula_check['valid']:
                issues.append(f"Formula rendering issue: {formula_check['problem']}")
        
        # 4. Check citation presence
        citation_check = self._validate_citations(response, chunks)
        if not citation_check['has_citations']:
            warnings.append("Response lacks specific citations (sections, tables, pages)")
        
        return {
            'valid': len(issues) == 0,
            'issues': issues,
            'warnings': warnings,
            'confidence_adjustment': -5 * len(issues) if issues else 0
        }
    
    def _validate_table_completeness(
        self,
        response: str,
        chunks: List[Dict],
        query: str
    ) -> Dict:
        """Check if table in response matches source completeness"""
        
        # Extract table from chunks (if exists)
        source_tables = []
        for chunk in chunks:
            metadata = chunk.get('metadata', {})
            if metadata.get('has_tables'):
                source_tables.append({
                    'id': metadata.get('table_id'),
                    'column_count': len(metadata.get('table_headers', [])),
                    'row_count': metadata.get('table_row_count', 0)
                })
        
        # Extract table from response
        response_tables = self._extract_markdown_tables(response)
        
        missing_elements = []
        
        if source_tables and not response_tables:
            missing_elements.append("Table mentioned in source but not displayed in response")
        elif source_tables and response_tables:
            # Compare structure
            for src_table in source_tables:
                matching_resp = None
                for resp_table in response_tables:
                    if abs(resp_table['column_count'] - src_table['column_count']) <= 1:
                        matching_resp = resp_table
                        break
                
                if matching_resp:
                    if matching_resp['column_count'] < src_table['column_count']:
                        missing_elements.append(
                            f"Table incomplete: {matching_resp['column_count']} cols shown, "
                            f"{src_table['column_count']} cols in source"
                        )
        
        return {
            'is_complete': len(missing_elements) == 0,
            'missing_elements': missing_elements
        }
    
    def _extract_markdown_tables(self, text: str) -> List[Dict]:
        """Extract markdown tables from text and analyze structure"""
        
        tables = []
        lines = text.split('\n')
        in_table = False
        current_table = {'rows': [], 'column_count': 0}
        
        for line in lines:
            if '|' in line and len(line.split('|')) > 2:
                if not in_table:
                    in_table = True
                    current_table = {'rows': [], 'column_count': 0}
                
                if '---' not in line and '===' not in line:
                    cols = [c.strip() for c in line.split('|') if c.strip()]
                    current_table['rows'].append(cols)
                    current_table['column_count'] = max(current_table['column_count'], len(cols))
            
            elif in_table and '|' not in line:
                # Table ended
                if current_table['rows']:
                    tables.append({
                        'column_count': current_table['column_count'],
                        'row_count': len(current_table['rows']) - 1  # Exclude header
                    })
                in_table = False
        
        return tables
    
    def _validate_numerical_consistency(
        self,
        response: str,
        chunks: List[Dict]
    ) -> Dict:
        """Check if numbers in response exist in source chunks"""
        
        # Extract all numbers from response
        response_numbers = set(re.findall(r'\d+\.?\d*', response))
        
        # Extract all numbers from chunks
        chunk_numbers = set()
        for chunk in chunks:
            text = chunk.get('metadata', {}).get('text', '')
            chunk_numbers.update(re.findall(r'\d+\.?\d*', text))
        
        # Check if response numbers are subset of chunk numbers
        unmatched = response_numbers - chunk_numbers
        
        # Filter out common numbers that don't matter (years, common values)
        significant_unmatched = [
            n for n in unmatched 
            if n and float(n) > 1900 or float(n) < 1
        ]
        
        return {
            'consistent': len(significant_unmatched) < 3,
            'details': f"{len(significant_unmatched)} numbers not found in source" if significant_unmatched else "OK"
        }
    
    def _validate_formula_rendering(self, response: str) -> Dict:
        """Check if LaTeX formulas are properly formatted"""
        
        # Check for broken LaTeX (missing delimiters, etc.)
        latex_patterns = [
            r'\\\[.*?\\\]',  # Block formulas
            r'\\\(.*?\\\)',  # Inline formulas
        ]
        
        has_latex = any(re.search(pattern, response) for pattern in latex_patterns)
        
        # Check for common LaTeX errors
        issues = []
        
        if '\\text{' in response and not has_latex:
            issues.append("LaTeX commands without proper delimiters")
        
        if '$$' in response:
            issues.append("Using $$ instead of \\[ \\] for block formulas")
        
        return {
            'valid': len(issues) == 0,
            'problem': '; '.join(issues) if issues else None
        }
    
    def _validate_citations(self, response: str, chunks: List[Dict]) -> Dict:
        """Check if response contains proper citations"""
        
        # Look for citation patterns
        citation_patterns = [
            r'Section\s+\d+',
            r'Table\s+\d+',
            r'Article\s+\d+',
            r'Page\s+\d+',
            r'Subsection\s+\d+'
        ]
        
        has_citations = any(re.search(pattern, response, re.IGNORECASE) for pattern in citation_patterns)
        
        return {
            'has_citations': has_citations,
            'citation_count': sum(
                len(re.findall(pattern, response, re.IGNORECASE)) 
                for pattern in citation_patterns
            )
        }
    
    def validate_table_completeness_in_response(
        self,
        response: str,
        query: str
    ) -> Dict[str, Any]:
        """
        Validate if response contains complete table when table query detected.
        """
        
        result = {
            'complete': True,
            'has_table': False,
            'row_count': 0,
            'column_count': 0,
            'warnings': [],
            'table_type': 'none'
        }
        
        # Check if this is a table query
        table_keywords = ['table', 'show', 'display', 'list all', 'what are', 'complete', 'full', 'entire', 'all columns']
        is_table_query = any(keyword in query.lower() for keyword in table_keywords)
        
        if not is_table_query:
            return result
        
        # Check for markdown tables
        has_markdown_table = '|' in response and ('---' in response or '|---|' in response)
        
        # Check for structured data (fallback)
        has_structured_data = bool(re.search(r'\d+\s*[:\-]\s*\w+', response))
        
        # Check for bullet lists with data
        has_bullet_lists = response.count('\n- ') > 3 or response.count('\n* ') > 3
        
        result['has_table'] = has_markdown_table or has_structured_data or has_bullet_lists
        
        if has_markdown_table:
            result['table_type'] = 'markdown'
            
            # Extract table lines
            lines = response.split('\n')
            table_lines = [line for line in lines if '|' in line and len(line.split('|')) > 2]
            
            # Count rows (excluding header and separator)
            data_rows = [l for l in table_lines if '---' not in l and '===' not in l]
            result['row_count'] = max(0, len(data_rows) - 1)
            
            # Count columns
            if table_lines:
                result['column_count'] = len(table_lines[0].split('|')) - 2
            
            # Validation rules
            if result['row_count'] < 2:
                result['warnings'].append('⚠️ Table appears incomplete (less than 2 data rows)')
                result['complete'] = False
            
            if result['column_count'] < 2:
                result['warnings'].append('⚠️ Table has insufficient columns (< 2)')
                result['complete'] = False
            
            # Check for truncation indicators
            if '...' in response or 'truncated' in response.lower():
                result['warnings'].append('⚠️ Table appears to be truncated')
                result['complete'] = False
        
        elif has_structured_data:
            result['table_type'] = 'structured'
        
        elif has_bullet_lists:
            result['table_type'] = 'list'
        
        elif is_table_query:
            result['warnings'].append('❌ Table query but no table found in response')
            result['complete'] = False
        
        return result
