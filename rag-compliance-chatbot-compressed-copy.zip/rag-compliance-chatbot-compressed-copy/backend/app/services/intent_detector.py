"""
Intent detection for routing queries to appropriate handlers
"""

from typing import Dict, Any, Optional, List
from app.utils.logger import setup_logger

logger = setup_logger("intent_detector")


class IntentDetector:
    """
    Detect user intent to route queries appropriately:
    - auto_summarize: User wants auto-summary of uploaded file
    - auto_summarize_image: User wants auto-analysis of uploaded image
    - file_only: Question about uploaded file only
    - image_vision: Question about uploaded image
    - file_kb_hybrid: Question requiring both file and KB
    - kb_only: Standard KB query (no files)
    """
    
    @staticmethod
    def detect_intent(
        query: str,
        has_uploaded_files: bool,
        has_uploaded_images: bool,
        chat_history: List[Dict] = None
    ) -> str:
        """
        Detect the intent of user query based on context
        
        Args:
            query: User's question
            has_uploaded_files: Whether files are uploaded
            has_uploaded_images: Whether images are uploaded
            chat_history: Previous conversation history
            
        Returns:
            Intent string: auto_summarize, file_only, image_vision, file_kb_hybrid, kb_only
        """
        
        query_lower = query.lower().strip()
        
        # ==================== IMPORTANT: Verify uploads exist ====================
        # Prevent false positive intent detection when no files are actually uploaded
        if not has_uploaded_files and not has_uploaded_images:
            logger.info("🎯 Intent: KB_ONLY (no files uploaded)")
            return "kb_only"
        
        # ==================== AUTO-SUMMARIZE FILE ====================
        if has_uploaded_files and not has_uploaded_images:
            auto_summarize_triggers = [
                'summarize', 'summary', 'what is this file', 'what does this file contain',
                'overview', 'tell me about this file', 'analyze this file',
                'what is in this file', 'content of this file', 'main points',
                'what does this say', 'explain this', 'what is this about'
            ]
            
            # Check if query is very short (likely auto-summarize request)
            if len(query.split()) <= 4:
                logger.info("🎯 Intent: AUTO_SUMMARIZE (short query)")
                return "auto_summarize"
            
            # Check if query matches triggers
            if any(trigger in query_lower for trigger in auto_summarize_triggers):
                logger.info("🎯 Intent: AUTO_SUMMARIZE (trigger match)")
                return "auto_summarize"
        
        # ==================== AUTO-SUMMARIZE IMAGE ====================
        if has_uploaded_images and not has_uploaded_files:
            image_auto_triggers = [
                'what is this', 'describe this', 'analyze this', 'what do you see',
                'tell me about', 'explain this', 'what does this show',
                'summarize', 'summary', 'overview', 'what is in'
            ]
            
            # Check for auto-summarize request for images
            if len(query.split()) <= 5:
                logger.info("🎯 Intent: AUTO_SUMMARIZE_IMAGE (short query)")
                return "auto_summarize_image"
            
            if any(trigger in query_lower for trigger in image_auto_triggers):
                logger.info("🎯 Intent: AUTO_SUMMARIZE_IMAGE (trigger match)")
                return "auto_summarize_image"
        
        # ==================== IMAGE VISION ANALYSIS ====================
        if has_uploaded_images:
            image_question_indicators = [
                'image', 'photo', 'picture', 'diagram', 'chart', 'drawing',
                'what is shown', 'what does it show', 'visible in', 'see in',
                'dimensions', 'measurements', 'specifications', 'details',
                'in the image', 'from the image', 'according to image'
            ]
            
            if any(indicator in query_lower for indicator in image_question_indicators):
                logger.info("🎯 Intent: IMAGE_VISION (specific question)")
                return "image_vision"
            
            # Default for image uploads: auto-summarize
            logger.info("🎯 Intent: AUTO_SUMMARIZE_IMAGE (default)")
            return "auto_summarize_image"
        
        # ==================== FILE-ONLY ANALYSIS ====================
        if has_uploaded_files:
            file_only_indicators = [
                'in this file', 'from the file', 'in the document', 'from this document',
                'according to this file', 'based on this file', 'in the uploaded',
                'what does the file say', 'file mentions', 'document states',
                'the file shows', 'file content', 'document content'
            ]
            
            # Strong file-only indicators
            if any(indicator in query_lower for indicator in file_only_indicators):
                logger.info("🎯 Intent: FILE_ONLY (explicit reference)")
                return "file_only"
        
        # ==================== FILE + KB HYBRID ====================
        if has_uploaded_files:
            hybrid_indicators = [
                'compare', 'difference', 'how does this compare', 'vs regulation',
                'compliant', 'compliance', 'meets requirements', 'according to dubai',
                'regulation', 'requirement', 'standard', 'code', 'does this meet',
                'is this compliant', 'check against', 'verify'
            ]
            
            # Question suggests comparing file with regulations
            if any(indicator in query_lower for indicator in hybrid_indicators):
                logger.info("🎯 Intent: FILE_KB_HYBRID (comparison/compliance check)")
                return "file_kb_hybrid"
            
            # Default for file uploads: use hybrid (safer approach)
            logger.info("🎯 Intent: FILE_KB_HYBRID (default for uploaded files)")
            return "file_kb_hybrid"
        
        # ==================== KB ONLY (DEFAULT) ====================
        logger.info("🎯 Intent: KB_ONLY (standard RAG)")
        return "kb_only"


class GreetingDetector:
    """Detect and handle greeting intents"""
    
    def __init__(self):
        self.greetings = {
            'hello', 'hi', 'hey', 'greetings', 'good morning', 'good afternoon',
            'good evening', 'howdy', 'hiya', 'sup', "what's up", 'yo',
            'hola', 'namaste', 'salaam', 'bonjour'
        }
        
        self.greeting_questions = {
            'how are you', 'how do you do', "how's it going", 'how are things',
            'how are you doing', "what's going on", 'how have you been'
        }
        
        self.thanks = {
            'thank', 'thanks', 'thank you', 'thx', 'appreciate', 'grateful',
            'cheers', 'kudos'
        }
        
        self.help_requests = {
            'help', 'assist', 'guide', 'support', 'what can you do',
            'how does this work', 'how to use', 'capabilities'
        }
    
    def is_greeting(self, query: str) -> bool:
        """Check if query is a simple greeting"""
        q_lower = query.lower().strip().strip('!?.,')
        
        # Exact match
        if q_lower in self.greetings:
            return True
        
        # Starts with greeting and is short
        for greeting in self.greetings:
            if q_lower.startswith(greeting) and len(q_lower.split()) <= 3:
                return True
        
        return False
    
    def is_greeting_question(self, query: str) -> bool:
        """Check if query is a greeting question"""
        q_lower = query.lower().strip()
        return any(pattern in q_lower for pattern in self.greeting_questions)
    
    def is_thanks(self, query: str) -> bool:
        """Check if query is expressing thanks"""
        q_lower = query.lower().strip()
        return any(word in q_lower for word in self.thanks)
    
    def is_help_request(self, query: str) -> bool:
        """Check if user is asking for help"""
        q_lower = query.lower().strip()
        return any(phrase in q_lower for phrase in self.help_requests)
    
    def detect_and_respond(self, query: str) -> Optional[str]:
        """Detect greeting and return appropriate response"""
        
        if self.is_greeting(query):
            return """👋 Hello! I'm the Dubai Compliance Assistant, powered by advanced AI to help you navigate Dubai's construction and safety regulations.

**I can help you with:**
- 📋 Dubai Municipality regulations
- 🏗️ Construction safety requirements
- 🌍 Environmental compliance
- ⚖️ Legal and regulatory questions
- 📊 Specific regulation lookups

**Just ask me anything about Dubai compliance!** 🚀"""
        
        elif self.is_greeting_question(query):
            return """I'm functioning perfectly and ready to assist you! 😊

I'm your expert guide for Dubai compliance regulations. Feel free to ask me:
- Specific regulation requirements
- Safety standards and protocols
- Environmental guidelines
- Documentation requirements
- Compliance procedures

**What would you like to know about Dubai regulations?**"""
        
        elif self.is_thanks(query):
            return """You're very welcome! 😊

I'm here to help anytime you need guidance on Dubai compliance regulations. Feel free to ask more questions!

**Need anything else?**"""
        
        elif self.is_help_request(query):
            return """**🎯 How to Use Dubai Compliance Assistant:**

**1. Ask Direct Questions:**
   - "What are the PPE requirements for construction sites?"
   - "Safety staff requirements for 500 employees"
   - "EER requirements for 4.0 TR AC unit"

**2. Upload Documents:**
   - Upload PDFs, Word files, or images
   - Ask questions about your uploaded files

**3. Follow-Up Questions:**
   - I remember context from previous messages
   - Ask related follow-up questions naturally

**💡 Try asking: "What are the employer duties for workplace safety?"**"""
        
        return None
