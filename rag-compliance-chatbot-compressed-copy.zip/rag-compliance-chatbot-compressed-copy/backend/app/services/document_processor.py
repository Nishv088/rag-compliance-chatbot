"""
Document processing service - extracts text from various document formats
"""

import pdfplumber
import docx
from pathlib import Path
from typing import Optional
from PIL import Image
import pytesseract
from app.utils.logger import setup_logger

logger = setup_logger("document_processor")


class DocumentProcessor:
    """Process and extract text from documents"""
    
    def __init__(self):
        self.supported_formats = ['.pdf', '.docx', '.txt', '.png', '.jpg', '.jpeg']
    
    def process_document(self, file_path: str) -> str:
        """
        Process a document and extract text
        
        Args:
            file_path: Path to the document file
            
        Returns:
            Extracted text content
        """
        
        path = Path(file_path)
        
        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        extension = path.suffix.lower()
        
        if extension not in self.supported_formats:
            raise ValueError(f"Unsupported file format: {extension}")
        
        logger.info(f"📄 Processing document: {path.name}")
        
        try:
            if extension == '.pdf':
                text = self._process_pdf(path)
            elif extension == '.docx':
                text = self._process_docx(path)
            elif extension == '.txt':
                text = self._process_txt(path)
            elif extension in ['.png', '.jpg', '.jpeg']:
                text = self._process_image(path)
            else:
                raise ValueError(f"Unsupported format: {extension}")
            
            logger.info(f"✅ Extracted {len(text)} characters from {path.name}")
            return text
            
        except Exception as e:
            logger.error(f"❌ Error processing {path.name}: {e}")
            raise
    
    def _process_pdf(self, path: Path) -> str:
        """Extract text from PDF"""
        
        text_parts = []
        
        with pdfplumber.open(path) as pdf:
            for page_num, page in enumerate(pdf.pages, 1):
                # Extract text
                page_text = page.extract_text()
                
                if page_text:
                    text_parts.append(f"--- Page {page_num} ---\n{page_text}\n")
                
                # Extract tables
                tables = page.extract_tables()
                for table_idx, table in enumerate(tables, 1):
                    if table:
                        table_text = self._format_table(table)
                        text_parts.append(f"\n[Table {table_idx} on Page {page_num}]\n{table_text}\n")
        
        return "\n".join(text_parts)
    
    def _process_docx(self, path: Path) -> str:
        """Extract text from DOCX"""
        
        doc = docx.Document(path)
        text_parts = []
        
        # Extract paragraphs
        for para in doc.paragraphs:
            if para.text.strip():
                text_parts.append(para.text)
        
        # Extract tables
        for table_idx, table in enumerate(doc.tables, 1):
            table_text = self._format_docx_table(table)
            text_parts.append(f"\n[Table {table_idx}]\n{table_text}\n")
        
        return "\n".join(text_parts)
    
    def _process_txt(self, path: Path) -> str:
        """Extract text from TXT"""
        
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read()
    
    def _process_image(self, path: Path) -> str:
        """Extract text from image using OCR"""
        
        try:
            image = Image.open(path)
            text = pytesseract.image_to_string(image)
            return text
        except Exception as e:
            logger.error(f"❌ OCR failed: {e}")
            return ""
    
    def _format_table(self, table: list) -> str:
        """Format PDF table as markdown"""
        
        if not table or not table[0]:
            return ""
        
        # Create markdown table
        lines = []
        
        # Header
        header = " | ".join(str(cell or "") for cell in table[0])
        lines.append(f"| {header} |")
        
        # Separator
        separator = " | ".join(["---"] * len(table[0]))
        lines.append(f"| {separator} |")
        
        # Data rows
        for row in table[1:]:
            row_text = " | ".join(str(cell or "") for cell in row)
            lines.append(f"| {row_text} |")
        
        return "\n".join(lines)
    
    def _format_docx_table(self, table) -> str:
        """Format DOCX table as markdown"""
        
        lines = []
        
        # Extract all rows
        rows = [[cell.text for cell in row.cells] for row in table.rows]
        
        if not rows:
            return ""
        
        # Header
        header = " | ".join(rows[0])
        lines.append(f"| {header} |")
        
        # Separator
        separator = " | ".join(["---"] * len(rows[0]))
        lines.append(f"| {separator} |")
        
        # Data rows
        for row in rows[1:]:
            row_text = " | ".join(row)
            lines.append(f"| {row_text} |")
        
        return "\n".join(lines)
    
    def extract_metadata(self, file_path: str) -> dict:
        """Extract metadata from document"""
        
        path = Path(file_path)
        
        stat = path.stat()
        
        metadata = {
            'filename': path.name,
            'extension': path.suffix,
            'size_bytes': stat.st_size,
            'size_mb': round(stat.st_size / (1024 * 1024), 2),
            'created_at': stat.st_ctime,
            'modified_at': stat.st_mtime
        }
        
        # Additional format-specific metadata
        if path.suffix == '.pdf':
            try:
                with pdfplumber.open(path) as pdf:
                    metadata['page_count'] = len(pdf.pages)
            except:
                pass
        
        elif path.suffix == '.docx':
            try:
                doc = docx.Document(path)
                metadata['paragraph_count'] = len(doc.paragraphs)
                metadata['table_count'] = len(doc.tables)
            except:
                pass
        
        return metadata
