from typing import List, Dict, Any
from qdrant_client import QdrantClient
from qdrant_client.http import models
from app.config import settings
from app.services.embedder import BGEEmbedder
from app.utils.logger import setup_logger

logger = setup_logger("retriever")

class QdrantRetriever:
    """Retrieve relevant chunks from Qdrant vector database"""
    
    def __init__(self):
        self.client = QdrantClient(
            host=settings.QDRANT_HOST,
            port=settings.QDRANT_PORT
        )
        self.embedder = BGEEmbedder()
        self.collection_name = settings.QDRANT_COLLECTION
        
        logger.info(f"✅ Qdrant client connected: {settings.QDRANT_HOST}:{settings.QDRANT_PORT}")
    
    def retrieve(
        self,
        query: str,
        top_k: int = None,
        score_threshold: float = None
    ) -> List[Dict[str, Any]]:
        """Retrieve relevant chunks for a query"""
        
        top_k = top_k or settings.TOP_K_CHUNKS
        score_threshold = score_threshold or settings.SIMILARITY_THRESHOLD
        
        try:
            # Generate query embedding
            query_vector = self.embedder.embed_query(query)
            
            # Search in Qdrant
            search_results = self.client.search(
                collection_name=self.collection_name,
                query_vector=query_vector,
                limit=top_k,
                score_threshold=score_threshold
            )
            
            # Process results
            chunks = []
            for result in search_results:
                chunk = {
                    "id": result.id,
                    "score": result.score,
                    "metadata": result.payload,
                    "text": result.payload.get("text", ""),
                    "merged_text": result.payload.get("merged_text", result.payload.get("text", ""))
                }
                chunks.append(chunk)
            
            logger.info(f"✅ Retrieved {len(chunks)} chunks (threshold: {score_threshold})")
            
            return chunks
            
        except Exception as e:
            logger.error(f"❌ Retrieval error: {e}")
            return []
    
    def get_context_string(self, chunks: List[Dict[str, Any]], max_length: int = None) -> str:
        """Build context string from retrieved chunks"""
        
        max_length = max_length or settings.MAX_CONTEXT_LENGTH
        
        context_parts = []
        current_length = 0
        
        for i, chunk in enumerate(chunks, 1):
            metadata = chunk["metadata"]
            text = chunk["merged_text"]
            
            # Format chunk with metadata
            chunk_text = f"""---
[Source {i}]
Document: {metadata.get('document_name', 'Unknown')}
Section: {metadata.get('section_title', 'N/A')} ({metadata.get('section_no', 'N/A')})
Page: {metadata.get('page_no', 'N/A')}
Confidence: {chunk['score']:.2f}

{text}
---
"""
            
            chunk_length = len(chunk_text)
            
            if current_length + chunk_length > max_length:
                break
            
            context_parts.append(chunk_text)
            current_length += chunk_length
        
        return "\n".join(context_parts)
