"""
Adaptive ranking service with numeric value extraction and intelligent re-ranking
"""

import re
from typing import List, Dict, Any, Optional
from app.utils.logger import setup_logger

logger = setup_logger("adaptive_ranker")


class AdaptiveRanker:
    """
    Advanced ranking with numeric value extraction and context-aware re-ranking
    """
    
    @staticmethod
    def extract_numeric_value_from_query(query: str) -> Optional[Dict[str, Any]]:
        """
        Extract numeric values and units from user queries for table lookups.
        
        Examples:
        - "What is required for 1000 m² building?" → 1000, "m²"
        - "Speed limit at 4.5 km/h?" → 4.5, "km/h"
        - "Height above 50 meters" → 50, "meters"
        """
        
        query_lower = query.lower()
        
        # Pattern: number + optional decimal + unit
        patterns = [
            # Metric units
            (r'(\d+\.?\d*)\s*(m²|m2|square\s*meters?|sqm)', 'm²', 'area'),
            (r'(\d+\.?\d*)\s*(m³|m3|cubic\s*meters?)', 'm³', 'volume'),
            (r'(\d+\.?\d*)\s*(meters?|m\b)', 'meters', 'distance'),
            (r'(\d+\.?\d*)\s*(km|kilometers?)', 'km', 'distance'),
            (r'(\d+\.?\d*)\s*(cm|centimeters?)', 'cm', 'distance'),
            (r'(\d+\.?\d*)\s*(mm|millimeters?)', 'mm', 'distance'),
            
            # Weight
            (r'(\d+\.?\d*)\s*(kg|kilograms?)', 'kg', 'weight'),
            (r'(\d+\.?\d*)\s*(tons?|tonnes?)', 'tons', 'weight'),
            (r'(\d+\.?\d*)\s*(lbs?|pounds?)', 'lbs', 'weight'),
            
            # Speed
            (r'(\d+\.?\d*)\s*(km/h|kmph|kph)', 'km/h', 'speed'),
            (r'(\d+\.?\d*)\s*(m/s|mps)', 'm/s', 'speed'),
            (r'(\d+\.?\d*)\s*(knots?)', 'knots', 'speed'),
            
            # Percentage
            (r'(\d+\.?\d*)\s*%', '%', 'percentage'),
            (r'(\d+\.?\d*)\s*percent', '%', 'percentage'),
            
            # Workers/People
            (r'(\d+)\s*(workers?|employees?|persons?|people)', 'workers', 'count'),
            
            # Floors/Levels
            (r'(\d+)\s*(floors?|levels?|storeys?|stories?)', 'floors', 'count'),
            
            # Generic number (fallback)
            (r'(\d+\.?\d*)', '', 'numeric')
        ]
        
        for pattern, unit, value_type in patterns:
            match = re.search(pattern, query_lower)
            if match:
                try:
                    value = float(match.group(1))
                    
                    # Determine query type
                    query_type = AdaptiveRanker._classify_numeric_query(query_lower, value, unit)
                    
                    result = {
                        'value': value,
                        'unit': unit,
                        'value_type': value_type,
                        'query_type': query_type,
                        'context': query,
                        'match_text': match.group(0)
                    }
                    
                    logger.info(f"📊 Extracted numeric value: {value} {unit} (type: {query_type})")
                    return result
                    
                except (ValueError, IndexError) as e:
                    logger.warning(f"Failed to parse numeric value: {e}")
                    continue
        
        return None
    
    @staticmethod
    def _classify_numeric_query(query: str, value: float, unit: str) -> str:
        """Classify the type of numeric query"""
        
        query_lower = query.lower()
        
        # Table range lookup indicators
        table_indicators = [
            'what is required', 'requirement for', 'requirements for',
            'what applies', 'which category', 'which range',
            'table', 'lookup', 'find in table'
        ]
        if any(indicator in query_lower for indicator in table_indicators):
            return 'table_range_lookup'
        
        # Threshold comparison indicators
        threshold_indicators = [
            'above', 'below', 'more than', 'less than',
            'exceeds', 'threshold', 'limit', 'maximum', 'minimum'
        ]
        if any(indicator in query_lower for indicator in threshold_indicators):
            return 'threshold_comparison'
        
        # Calculation indicators
        calc_indicators = [
            'calculate', 'compute', 'determine', 'formula',
            'how much', 'how many'
        ]
        if any(indicator in query_lower for indicator in calc_indicators):
            return 'calculation'
        
        return 'general_numeric'
    
    @staticmethod
    def rerank_chunks_by_numeric_context(
        chunks: List[Dict],
        numeric_info: Dict[str, Any],
        boost_factor: float = 1.5
    ) -> List[Dict]:
        """
        Re-rank chunks to prioritize those containing relevant numeric values or tables
        """
        
        if not numeric_info:
            return chunks
        
        target_value = numeric_info['value']
        target_unit = numeric_info['unit']
        
        scored_chunks = []
        
        for chunk in chunks:
            text = chunk.get('merged_text', chunk.get('metadata', {}).get('text', ''))
            metadata = chunk.get('metadata', {})
            base_score = chunk.get('score', 0.5)
            
            boost = 0.0
            
            # Boost 1: Contains tables
            if metadata.get('has_tables') or '|' in text:
                boost += 0.15
            
            # Boost 2: Contains target unit
            if target_unit and target_unit.lower() in text.lower():
                boost += 0.10
            
            # Boost 3: Contains similar numeric values
            numbers_in_chunk = re.findall(r'\d+\.?\d*', text)
            for num_str in numbers_in_chunk:
                try:
                    num = float(num_str)
                    # Check if number is in similar range (within 50%)
                    if 0.5 * target_value <= num <= 1.5 * target_value:
                        boost += 0.05
                        break
                except:
                    continue
            
            # Boost 4: Query type specific
            if numeric_info['query_type'] == 'table_range_lookup':
                if 'table' in text.lower() or metadata.get('has_tables'):
                    boost += 0.20
            
            new_score = base_score * (1 + boost)
            
            scored_chunks.append({
                **chunk,
                'original_score': base_score,
                'score': new_score,
                'boost_applied': boost
            })
        
        # Sort by new score
        scored_chunks.sort(key=lambda x: x['score'], reverse=True)
        
        logger.info(f"📈 Re-ranked {len(scored_chunks)} chunks with numeric context boost")
        
        return scored_chunks
