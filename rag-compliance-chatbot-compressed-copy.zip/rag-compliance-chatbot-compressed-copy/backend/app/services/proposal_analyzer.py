"""
Integrated Proposal Document Analyzer Service
Combines PDF validation, text extraction, analysis, and vector storage
"""

import os
import json
import base64
import hashlib
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from datetime import datetime
import fitz  # PyMuPDF
from openai import OpenAI
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct

from app.services.embedder import BGEEmbedder
from app.config import settings
from app.utils.logger import setup_logger

logger = setup_logger("proposal_analyzer")


class ProposalAnalyzer:
    """Integrated service for proposal document analysis"""
    
    def __init__(self):
        self.proposals_dir = settings.PROPOSALS_DIR
        self.reports_dir = settings.REPORTS_DIR
        
        # Create directories
        for dir_path in [self.proposals_dir, self.reports_dir]:
            dir_path.mkdir(parents=True, exist_ok=True)
        
        # Initialize services
        self.embedder = BGEEmbedder()
        self.openai_client = OpenAI(api_key=settings.OPENAI_API_KEY)
        self.qdrant_client = QdrantClient(host=settings.QDRANT_HOST, port=settings.QDRANT_PORT)
        self.collection_name = "proposal_documents"
        
        # Initialize collection
        self._init_collection()
        
        logger.info("✅ ProposalAnalyzer initialized")
    
    def _init_collection(self):
        """Initialize Qdrant collection for proposals"""
        try:
            collections = self.qdrant_client.get_collections().collections
            exists = any(c.name == self.collection_name for c in collections)
            
            if not exists:
                self.qdrant_client.create_collection(
                    collection_name=self.collection_name,
                    vectors_config=VectorParams(size=1024, distance=Distance.COSINE)
                )
                logger.info(f"✅ Created collection: {self.collection_name}")
            else:
                logger.info(f"📦 Collection exists: {self.collection_name}")
        except Exception as e:
            logger.error(f"❌ Failed to initialize collection: {e}")
            raise
    
    def validate_pdf(self, pdf_path: str) -> Tuple[bool, int, str]:
        """
        Validate PDF file
        Returns: (is_valid, page_count, error_message)
        """
        try:
            pdf_file = Path(pdf_path)
            
            if not pdf_file.exists():
                return False, 0, f"PDF file not found: {pdf_path}"
            
            if pdf_file.suffix.lower() not in ['.pdf', '.doc', '.docx']:
                return False, 0, f"Unsupported file type: {pdf_file.suffix}"
            
            # For PDF files
            if pdf_file.suffix.lower() == '.pdf':
                doc = fitz.open(pdf_path)
                page_count = doc.page_count
                
                if page_count == 0:
                    doc.close()
                    return False, 0, "PDF file is empty (0 pages)"
                
                # Test first page
                first_page = doc[0]
                text_content = first_page.get_text()
                doc.close()
                
                logger.info(f"✅ Valid PDF: {pdf_file.name} ({page_count} pages)")
                return True, page_count, ""
            
            # For DOC/DOCX - basic validation
            return True, 1, ""
            
        except Exception as e:
            return False, 0, f"Validation error: {str(e)}"
    
    def extract_text_from_pdf(self, pdf_path: str) -> Tuple[str, int]:
        """
        Extract complete text content from PDF using PyMuPDF
        Returns: (extracted_text, page_count)
        """
        try:
            doc = fitz.open(pdf_path)
            page_count = len(doc)
            
            text_content = []
            
            for page_num in range(page_count):
                page = doc[page_num]
                text = page.get_text("text")
                
                # Add page separator
                text_content.append(f"--- PAGE {page_num + 1} ---\n{text}")
            
            doc.close()
            
            full_text = "\n\n".join(text_content)
            
            logger.info(f"✅ Extracted {len(full_text)} characters from {page_count} pages")
            return full_text, page_count
            
        except Exception as e:
            logger.error(f"❌ Text extraction failed: {e}")
            raise
    
    def pdf_to_base64(self, pdf_path: str) -> Optional[str]:
        """Convert PDF to base64 for API transmission (backup method)"""
        try:
            with open(pdf_path, 'rb') as file:
                pdf_binary = file.read()
            
            base64_string = base64.b64encode(pdf_binary).decode('utf-8')
            file_size_mb = len(pdf_binary) / (1024 * 1024)
            
            logger.info(f"✅ PDF converted to base64: {file_size_mb:.2f} MB")
            return base64_string
        except Exception as e:
            logger.error(f"❌ Failed to convert PDF: {e}")
            return None
    
    def analyze_document(
        self,
        pdf_path: str,
        filename: str,
        compliance_context: str
    ) -> Dict:
        """
        Analyze proposal document against compliance requirements using text extraction
        """
        try:
            # Extract text from PDF
            document_content, page_count = self.extract_text_from_pdf(pdf_path)
            
            logger.info(f"📄 Analyzing: {filename} ({page_count} pages)")
            
            # Truncate if too long (GPT-4 context limit)
            max_chars = 30000
            if len(document_content) > max_chars:
                logger.warning(f"⚠️ Truncating document from {len(document_content)} to {max_chars} chars")
                document_content = document_content[:max_chars] + "\n\n[... Document truncated due to length ...]"
            
            # Truncate compliance context
            if len(compliance_context) > 15000:
                compliance_context = compliance_context[:15000]
            
        except Exception as e:
            logger.error(f"❌ Text extraction failed: {e}")
            return {"error": f"Text extraction failed: {str(e)}"}
        
        # Compliance analysis prompt
        analysis_prompt = f"""You are a Dubai construction compliance expert. Analyze this proposal document against Dubai compliance requirements.

**PROPOSAL DOCUMENT CONTENT:**
{document_content}

**DUBAI COMPLIANCE REQUIREMENTS:**
{compliance_context}

**YOUR TASK:**
Provide a comprehensive compliance analysis in EXACT JSON format:

{{
  "compliance_coverage_assessment": {{
    "overview": "2-3 sentence overview of overall compliance status",
    "coverage_points": [
      {{
        "title": "Compliance area name (e.g., Health & Safety Plan)",
        "summary": "How this area is addressed in the proposal",
        "source": "Dubai regulation reference (e.g., SOURCE 1, Section 4.2)"
      }}
    ]
  }},
  "key_gaps_identified": [
    {{
      "area": "Compliance area with gap",
      "issue": "Detailed description of what's missing or inadequate and why it matters",
      "source": "Dubai regulation reference"
    }}
  ],
  "risk_level": {{
    "assessment": "Low/Medium/High",
    "reasoning": "Detailed reasoning for this risk level based on gaps identified"
  }},
  "top_recommendations": [
    {{
      "priority": 1,
      "title": "Recommendation title",
      "recommendation": "Detailed actionable recommendation with specific implementation steps"
    }}
  ]
}}

**INSTRUCTIONS:**
1. Identify at least 3-5 coverage points where proposal addresses compliance
2. Identify at least 2-4 gaps where compliance is missing or insufficient
3. Provide 3-5 prioritized recommendations (priority 1 = most critical)
4. Be specific and reference Dubai regulations
5. Return ONLY valid JSON, no markdown formatting"""
        
        try:
            # Call OpenAI for analysis
            analysis_response = self.openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are a Dubai construction compliance expert. Always respond with valid JSON only, no markdown."},
                    {"role": "user", "content": analysis_prompt}
                ],
                temperature=0.2,
                max_tokens=4000
            )
            
            analysis_text = analysis_response.choices[0].message.content.strip()
            
            # Clean JSON response (remove markdown if present)
            if "```json" in analysis_text:
                analysis_text = analysis_text.split("```json").split("```")[1]
            elif "```" in analysis_text:
                analysis_text = analysis_text.split("```").split("```")[0]
            
            analysis_text = analysis_text.strip()
            
            # Parse JSON
            analysis_dict = json.loads(analysis_text)
            
            # Add document metadata
            analysis_dict["document_info"] = {
                "report_title": f"Compliance Analysis Report - {filename}",
                "processing_note": "PyMuPDF Text Extraction + GPT-4 Analysis",
                "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "file_name": filename,
                "page_count": page_count,
                "text_length": len(document_content)
            }
            
            logger.info("✅ Analysis completed successfully")
            return analysis_dict
            
        except json.JSONDecodeError as e:
            logger.error(f"❌ JSON parsing failed: {e}")
            logger.error(f"Response text: {analysis_text[:500]}")
            
            # Return fallback report
            return self._create_fallback_report(filename, page_count, str(e))
            
        except Exception as e:
            logger.error(f"❌ Analysis failed: {e}")
            return {"error": f"Analysis failed: {str(e)}"}
    
    def batch_analyze(
        self,
        file_paths: List[str],
        project_id: str,
        compliance_context: str
    ) -> Dict:
        """
        Batch analyze multiple proposal documents
        """
        logger.info(f"📚 Batch analyzing {len(file_paths)} files for project {project_id}")
        
        filenames = []
        total_pages = 0
        combined_text = []
        
        for pdf_path in file_paths:
            is_valid, page_count, error = self.validate_pdf(pdf_path)
            if not is_valid:
                logger.warning(f"⚠️ Skipping invalid file: {Path(pdf_path).name} - {error}")
                continue
            
            try:
                text, pages = self.extract_text_from_pdf(pdf_path)
                filename = Path(pdf_path).name
                
                filenames.append(filename)
                total_pages += pages
                
                # Add document separator
                combined_text.append(f"\n\n========== DOCUMENT: {filename} ==========\n\n{text}")
                
                logger.info(f"  ✓ Processed: {filename} ({pages} pages)")
            except Exception as e:
                logger.error(f"  ✗ Failed: {Path(pdf_path).name} - {e}")
                continue
        
        if not combined_text:
            return {"error": "No valid documents to analyze"}
        
        # Combine all document texts
        full_combined_text = "\n".join(combined_text)
        
        # Truncate if needed
        max_chars = 30000
        if len(full_combined_text) > max_chars:
            logger.warning(f"⚠️ Truncating combined text from {len(full_combined_text)} to {max_chars} chars")
            full_combined_text = full_combined_text[:max_chars] + "\n\n[... Documents truncated due to length ...]"
        
        # Batch analysis prompt
        analysis_prompt = f"""You are a Dubai construction compliance expert. Analyze these {len(filenames)} proposal documents against Dubai compliance requirements.

**PROPOSAL DOCUMENTS:**
{full_combined_text}

**DUBAI COMPLIANCE REQUIREMENTS:**
{compliance_context[:15000]}

**YOUR TASK:**
Provide a comprehensive compliance analysis across ALL documents in EXACT JSON format:

{{
  "compliance_coverage_assessment": {{
    "overview": "Overall compliance assessment across all documents",
    "coverage_points": [
      {{
        "title": "Compliance area (mention which document if relevant)",
        "summary": "How this area is addressed",
        "source": "Dubai regulation reference"
      }}
    ]
  }},
  "key_gaps_identified": [
    {{
      "area": "Gap area (mention which document if relevant)",
      "issue": "What's missing or inadequate across the documents",
      "source": "Dubai regulation reference"
    }}
  ],
  "risk_level": {{
    "assessment": "Low/Medium/High",
    "reasoning": "Overall risk assessment across all documents"
  }},
  "top_recommendations": [
    {{
      "priority": 1,
      "title": "Recommendation title",
      "recommendation": "Actionable recommendation for the overall project"
    }}
  ]
}}

Return ONLY valid JSON, no markdown."""
        
        try:
            analysis_response = self.openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are a Dubai compliance expert. Return only valid JSON."},
                    {"role": "user", "content": analysis_prompt}
                ],
                temperature=0.2,
                max_tokens=4000
            )
            
            analysis_text = analysis_response.choices[0].message.content.strip()
            
            # Clean JSON
            if "```json" in analysis_text:
                analysis_text = analysis_text.split("```json").split("```")[1]
            elif "```" in analysis_text:
                analysis_text = analysis_text.split("```").split("```")[0]
            
            analysis_dict = json.loads(analysis_text.strip())
            
            # Add batch metadata
            analysis_dict["document_info"] = {
                "report_title": f"Batch Compliance Analysis Report - {len(filenames)} Documents",
                "processing_note": "Batch Analysis with PyMuPDF",
                "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "file_names": filenames,
                "page_count": total_pages,
                "batch_analysis": True
            }
            
            logger.info("✅ Batch analysis completed successfully")
            return analysis_dict
            
        except json.JSONDecodeError as e:
            logger.error(f"❌ Batch analysis JSON parsing failed: {e}")
            return self._create_fallback_report(
                ", ".join(filenames),
                total_pages,
                str(e),
                batch=True
            )
        except Exception as e:
            logger.error(f"❌ Batch analysis failed: {e}")
            return {"error": f"Batch analysis failed: {str(e)}"}
    
    def store_in_vector_db(
        self,
        analysis_report: Dict,
        project_id: str,
        conversation_id: str,
        analysis_id: str
    ):
        """Store analysis report in Qdrant vector database"""
        try:
            # Serialize report for embedding
            report_text = json.dumps(analysis_report, indent=2)
            
            # Generate embedding
            embedding = self.embedder.embed_text(report_text)
            
            # Create point ID (must be integer or string without special chars)
            point_id = hashlib.md5(analysis_id.encode()).hexdigest()
            
            # Store in Qdrant
            point = PointStruct(
                id=point_id,
                vector=embedding,
                payload={
                    "project_id": project_id,
                    "conversation_id": conversation_id,
                    "analysis_id": analysis_id,
                    "report": analysis_report,
                    "created_at": datetime.now().isoformat(),
                    "document_name": analysis_report.get("document_info", {}).get("file_name", "unknown"),
                    "batch_analysis": analysis_report.get("document_info", {}).get("batch_analysis", False)
                }
            )
            
            self.qdrant_client.upsert(
                collection_name=self.collection_name,
                points=[point]
            )
            
            logger.info(f"✅ Stored analysis in vector DB: {analysis_id}")
            
        except Exception as e:
            logger.error(f"❌ Failed to store in vector DB: {e}")
            raise
    
    def delete_project_proposals(self, project_id: str):
        """Delete all proposal analyses for a project"""
        try:
            from qdrant_client.models import Filter, FieldCondition, MatchValue
            
            self.qdrant_client.delete(
                collection_name=self.collection_name,
                points_selector=Filter(
                    must=[
                        FieldCondition(
                            key="project_id",
                            match=MatchValue(value=project_id)
                        )
                    ]
                )
            )
            logger.info(f"✅ Deleted proposals for project: {project_id}")
        except Exception as e:
            logger.error(f"❌ Failed to delete proposals: {e}")
    
    def get_project_report(self, project_id: str) -> Optional[Dict]:
        """Retrieve the most recent analysis report for a project"""
        try:
            from qdrant_client.models import Filter, FieldCondition, MatchValue
            
            results = self.qdrant_client.scroll(
                collection_name=self.collection_name,
                scroll_filter=Filter(
                    must=[
                        FieldCondition(
                            key="project_id",
                            match=MatchValue(value=project_id)
                        )
                    ]
                ),
                limit=1,
                with_payload=True
            )
            
            if results[0]:
                latest = results[0][0]
                return latest.payload.get("report")
            
            return None
            
        except Exception as e:
            logger.error(f"❌ Failed to retrieve report: {e}")
            return None
    
    def analyze_and_save(
        self,
        file_paths: List[str],
        project_id: str,
        conversation_id: str,
        compliance_sources: List[Dict]
    ) -> Dict:
        """
        Main entry point: Analyze proposals and save results
        """
        # Generate unique analysis ID
        analysis_id = hashlib.md5(
            f"{project_id}_{datetime.now().isoformat()}".encode()
        ).hexdigest()
        
        # Build compliance context from sources
        compliance_context = self._build_compliance_context(compliance_sources)
        
        # Single or batch analysis
        if len(file_paths) == 1:
            is_valid, page_count, error = self.validate_pdf(file_paths[0])
            if not is_valid:
                return {"error": error, "success": False}
            
            analysis_result = self.analyze_document(
                pdf_path=file_paths[0],
                filename=Path(file_paths[0]).name,
                compliance_context=compliance_context
            )
        else:
            analysis_result = self.batch_analyze(
                file_paths=file_paths,
                project_id=project_id,
                compliance_context=compliance_context
            )
        
        if "error" in analysis_result:
            return {"error": analysis_result["error"], "success": False}
        
        # Save report to file
        report_path = self.reports_dir / f"{project_id}_{analysis_id}.json"
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(analysis_result, f, indent=2, ensure_ascii=False)
        
        logger.info(f"💾 Saved report: {report_path}")
        
        # Store in vector DB
        try:
            self.store_in_vector_db(
                analysis_report=analysis_result,
                project_id=project_id,
                conversation_id=conversation_id,
                analysis_id=analysis_id
            )
        except Exception as e:
            logger.error(f"⚠️ Vector DB storage failed, but report saved: {e}")
        
        return {
            "success": True,
            "analysis_id": analysis_id,
            "report": analysis_result,
            "report_path": str(report_path)
        }
    
    def _build_compliance_context(self, sources: List[Dict]) -> str:
        """Build compliance context from retrieved sources"""
        if not sources:
            return "No specific compliance regulations retrieved."
        
        context = "DUBAI COMPLIANCE REGULATIONS:\n\n"
        for i, source in enumerate(sources, 1):
            metadata = source.get('metadata', {})
            text = source.get('merged_text') or source.get('text', 'No content')
            
            context += f"SOURCE {i}:\n"
            context += f"Document: {metadata.get('document_name', 'Unknown')}\n"
            context += f"Section: {metadata.get('section_title', 'N/A')}\n"
            context += f"Content: {text}\n\n"
        
        return context
    
    def _create_fallback_report(
        self,
        filename: str,
        page_count: int,
        error: str,
        batch: bool = False
    ) -> Dict:
        """Create a fallback report when analysis fails"""
        return {
            "document_info": {
                "report_title": f"Compliance Analysis Report - {filename}",
                "processing_note": "Fallback report due to analysis error",
                "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "file_name" if not batch else "file_names": filename,
                "page_count": page_count,
                "batch_analysis": batch,
                "error": error
            },
            "compliance_coverage_assessment": {
                "overview": "Analysis could not be completed due to technical issues. Please try again or contact support.",
                "coverage_points": []
            },
            "key_gaps_identified": [
                {
                    "area": "Analysis Error",
                    "issue": f"Could not complete analysis: {error}",
                    "source": "System"
                }
            ],
            "risk_level": {
                "assessment": "Unknown",
                "reasoning": "Analysis incomplete due to technical error"
            },
            "top_recommendations": [
                {
                    "priority": 1,
                    "title": "Retry Analysis",
                    "recommendation": "Please try uploading the document again. If the issue persists, ensure the PDF is not corrupted and contains readable text."
                }
            ]
        }
