"""
Embedding service using BGE-large model (1024 dimensions)
"""

from sentence_transformers import SentenceTransformer
from typing import List
import numpy as np
from app.utils.logger import setup_logger

logger = setup_logger("embedder")


class BGEEmbedder:
    """
    BGE-large embedding model (1024 dimensions)
    Matches the dimension of the existing Qdrant collection
    """
    
    def __init__(self):
        try:
            # Use BGE-large (1024 dimensions) to match collection
            logger.info("🔄 Loading BGE-large model...")
            self.model = SentenceTransformer('BAAI/bge-large-en-v1.5')
            logger.info("✅ BGE-large embedder initialized (1024 dims)")
        except Exception as e:
            logger.error(f"❌ Failed to initialize embedder: {e}")
            raise
    
    def embed_text(self, text: str) -> List[float]:
        """
        Generate embedding for a single text
        
        Args:
            text: Input text string
            
        Returns:
            List of floats representing the embedding (1024 dimensions)
        """
        try:
            if not text or not text.strip():
                logger.warning("Empty text provided for embedding")
                return [0.0] * 1024
            
            # Generate embedding
            embedding = self.model.encode(
                text,
                normalize_embeddings=True,
                show_progress_bar=False
            )
            
            return embedding.tolist()
            
        except Exception as e:
            logger.error(f"❌ Embedding generation failed: {e}")
            return [0.0] * 1024
    
    def embed_query(self, query: str) -> List[float]:
        """
        Generate embedding for query with 'query:' prefix for BGE
        
        Args:
            query: Query text string
            
        Returns:
            List of floats representing the embedding (1024 dimensions)
        """
        try:
            if not query or not query.strip():
                logger.warning("Empty query provided for embedding")
                return [0.0] * 1024
            
            # BGE-large uses "query: " prefix for queries
            prefixed_query = f"query: {query}"
            
            # Generate embedding
            embedding = self.model.encode(
                prefixed_query,
                normalize_embeddings=True,
                show_progress_bar=False
            )
            
            return embedding.tolist()
            
        except Exception as e:
            logger.error(f"❌ Query embedding failed: {e}")
            return [0.0] * 1024
    
    def embed_batch(self, texts: List[str], batch_size: int = 32) -> List[List[float]]:
        """
        Generate embeddings for multiple texts in batches
        
        Args:
            texts: List of input texts
            batch_size: Number of texts to process at once
            
        Returns:
            List of embeddings
        """
        try:
            if not texts:
                return []
            
            # Filter empty texts
            valid_texts = [text if text and text.strip() else " " for text in texts]
            
            # Generate embeddings in batches
            embeddings = self.model.encode(
                valid_texts,
                batch_size=batch_size,
                normalize_embeddings=True,
                show_progress_bar=False
            )
            
            return embeddings.tolist()
            
        except Exception as e:
            logger.error(f"❌ Batch embedding failed: {e}")
            return [[0.0] * 1024] * len(texts)
    
    @property
    def dimension(self) -> int:
        """Return embedding dimension"""
        return 1024
