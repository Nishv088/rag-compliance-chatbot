# backend/app/services/semantic_cache.py
"""
Semantic query caching with embedding-based similarity
"""

import json
import hashlib
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import numpy as np

from app.services.embedder import BGEEmbedder
from app.config import settings
from app.utils.logger import setup_logger

logger = setup_logger("semantic_cache")


class SemanticQueryCache:
    """Advanced semantic caching with embedding-based similarity"""
    
    def __init__(
        self,
        cache_dir: Optional[Path] = None,
        ttl_seconds: int = 3600,
        similarity_threshold: float = 0.95
    ):
        self.cache_dir = cache_dir or (settings.CACHE_DIR)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.ttl = ttl_seconds
        self.similarity_threshold = similarity_threshold
        self.embedder = BGEEmbedder()
        self.memory_cache = {}  # In-memory for speed
        
        logger.info(f"✅ Semantic cache initialized: {self.cache_dir}")
    
    def _normalize_query(self, query: str) -> str:
        """Normalize query for semantic matching"""
        if not query:
            return ""
        
        # Remove extra whitespace, lowercase, strip
        normalized = ' '.join(str(query).lower().strip().split())
        
        # Remove common punctuation that doesn't change meaning
        normalized = normalized.rstrip('?!.,;:')
        
        return normalized
    
    def _get_query_embedding(self, query: str) -> List[float]:
        """Get embedding for semantic comparison"""
        normalized = self._normalize_query(query)
        return self.embedder.embed_query(normalized)
    
    def _calculate_similarity(self, emb1: np.ndarray, emb2: np.ndarray) -> float:
        """Calculate cosine similarity between embeddings"""
        return np.dot(emb1, emb2) / (np.linalg.norm(emb1) * np.linalg.norm(emb2))
    
    def _find_similar_cached_query(
        self,
        query_embedding: List[float],
        session_id: str
    ) -> Optional[Dict]:
        """Find semantically similar cached query"""
        
        cache_file = self.cache_dir / f"session_{session_id}.json"
        if not cache_file.exists():
            return None
        
        try:
            with open(cache_file, 'r') as f:
                cached_data = json.load(f)
            
            query_emb = np.array(query_embedding)
            
            for cache_key, entry in cached_data.items():
                # Check expiration
                expires_at = datetime.fromisoformat(entry['expires_at'])
                if expires_at < datetime.now():
                    continue
                
                # Calculate cosine similarity
                cached_emb = np.array(entry['query_embedding'])
                similarity = self._calculate_similarity(cached_emb, query_emb)
                
                if similarity >= self.similarity_threshold:
                    logger.info(f"🎯 Semantic cache HIT! Similarity: {similarity:.3f}")
                    entry['similarity'] = similarity
                    return entry
        
        except Exception as e:
            logger.warning(f"Cache read error: {e}")
        
        return None
    
    def get(self, session_id: str, query: str) -> Optional[Dict]:
        """Get cached response using semantic similarity"""
        
        # Check memory cache first
        cache_key = f"{session_id}:{self._normalize_query(query)}"
        if cache_key in self.memory_cache:
            entry = self.memory_cache[cache_key]
            if datetime.fromisoformat(entry['expires_at']) > datetime.now():
                logger.info("🎯 Memory cache HIT")
                return {
                    'response': entry.get('response'),
                    'confidence': entry.get('confidence'),
                    'citations': entry.get('citations', []),
                    'followup_questions': entry.get('followup_questions', [])  # ADDED
                }
        
        # Check disk cache with semantic matching
        query_embedding = self._get_query_embedding(query)
        similar_entry = self._find_similar_cached_query(query_embedding, session_id)
        
        if similar_entry:
            return {
                'response': similar_entry.get('response'),
                'confidence': similar_entry.get('confidence'),
                'citations': similar_entry.get('citations', []),
                'followup_questions': similar_entry.get('followup_questions', [])  # ADDED
            }
        
        return None
    
    def set(
        self,
        session_id: str,
        query: str,
        response: str,
        confidence: float,
        chunks: List[Dict],
        followup_questions: Optional[List[str]] = None  # ADDED PARAMETER
    ):
        """Cache response with query embedding and followup questions"""
        
        cache_file = self.cache_dir / f"session_{session_id}.json"
        
        # Load existing cache
        cached_data = {}
        if cache_file.exists():
            try:
                with open(cache_file, 'r') as f:
                    cached_data = json.load(f)
            except:
                pass
        
        # Generate unique key
        query_hash = hashlib.md5(self._normalize_query(query).encode()).hexdigest()
        query_embedding = self._get_query_embedding(query)
        
        # Convert embedding to list
        if hasattr(query_embedding, 'tolist'):
            embedding_list = query_embedding.tolist()
        elif isinstance(query_embedding, list):
            embedding_list = query_embedding
        else:
            embedding_list = np.array(query_embedding).tolist()
        
        # Build citations from chunks
        citations = []
        for i, chunk in enumerate(chunks[:5], 1):
            metadata = chunk.get("metadata", {})
            citations.append({
                "id": f"S{i}",
                "title": metadata.get("section_title", "Unknown"),
                "text": chunk.get("text", chunk.get("merged_text", ""))[:200] + "...",
                "section_no": metadata.get("section_no", "N/A"),
                "page_no": str(metadata.get("page_no", "N/A")),
                "confidence": round(chunk.get("score", 0.7) * 100, 1),
                "document_name": metadata.get("document_name", "Unknown")
            })
        
        # Store with embedding and followup questions
        entry = {
            'query': query,
            'query_embedding': embedding_list,
            'response': response,
            'confidence': confidence,
            'citations': citations,  # ADDED
            'followup_questions': followup_questions or [],  # ADDED
            'chunk_ids': [c.get('id', '') for c in chunks[:5]],
            'timestamp': datetime.now().isoformat(),
            'expires_at': (datetime.now() + timedelta(seconds=self.ttl)).isoformat()
        }
        
        cached_data[query_hash] = entry
        
        # Write to disk
        try:
            with open(cache_file, 'w') as f:
                json.dump(cached_data, f, indent=2)
            
            # Update memory cache
            cache_key = f"{session_id}:{self._normalize_query(query)}"
            self.memory_cache[cache_key] = entry
            
            logger.info(f"💾 Cached response for session {session_id}")
        except Exception as e:
            logger.warning(f"⚠️ Failed to cache response: {e}")
    
    def clear_expired(self, session_id: Optional[str] = None):
        """Clear expired cache entries"""
        
        if session_id:
            files = [self.cache_dir / f"session_{session_id}.json"]
        else:
            files = list(self.cache_dir.glob("session_*.json"))
        
        for cache_file in files:
            if not cache_file.exists():
                continue
            
            try:
                with open(cache_file, 'r') as f:
                    cached_data = json.load(f)
                
                # Remove expired entries
                now = datetime.now()
                cleaned_data = {
                    k: v for k, v in cached_data.items()
                    if datetime.fromisoformat(v['expires_at']) > now
                }
                
                if len(cleaned_data) < len(cached_data):
                    with open(cache_file, 'w') as f:
                        json.dump(cleaned_data, f, indent=2)
                    
                    removed_count = len(cached_data) - len(cleaned_data)
                    logger.info(f"🧹 Cleared {removed_count} expired entries")
            
            except Exception as e:
                logger.warning(f"Failed to clean cache file {cache_file}: {e}")
