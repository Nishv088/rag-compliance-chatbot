"""
Chat session management with message history and metadata
"""

import json
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional
from app.config import settings
from app.utils.logger import setup_logger

logger = setup_logger("chat_manager")


class ChatManager:
    """Manage chat sessions and history"""
    
    def __init__(self):
        self.histories_dir = settings.CHAT_HISTORIES_DIR
        self.titles_file = self.histories_dir / "titles.json"
        self.sessions = {}  # In-memory cache
        self._ensure_titles_file()
    
    def _ensure_titles_file(self):
        """Ensure titles.json exists"""
        if not self.titles_file.exists():
            with open(self.titles_file, 'w') as f:
                json.dump({}, f)
    
    def create_session(self, session_id: str) -> Dict:
        """Create a new chat session"""
        session_file = self.histories_dir / f"{session_id}.json"
        
        if session_file.exists():
            logger.info(f"Session {session_id} already exists")
            return self.get_session(session_id)
        
        session_data = {
            "session_id": session_id,
            "created_at": datetime.now().isoformat(),
            "messages": []
        }
        
        # Save to memory
        self.sessions[session_id] = session_data
        
        # Save to disk
        with open(session_file, 'w') as f:
            json.dump(session_data, f, indent=2)
        
        logger.info(f"✅ Created session {session_id}")
        return session_data
    
    def get_session(self, session_id: str) -> Optional[Dict]:
        """Get session data"""
        # Check memory first
        if session_id in self.sessions:
            return self.sessions[session_id]
        
        # Load from disk
        session_file = self.histories_dir / f"{session_id}.json"
        
        if not session_file.exists():
            return None
        
        with open(session_file, 'r') as f:
            session_data = json.load(f)
            self.sessions[session_id] = session_data
            return session_data
    
    def save_message(self, session_id: str, message: Dict):
        """Save a message to session"""
        session_data = self.get_session(session_id)
        
        if not session_data:
            session_data = self.create_session(session_id)
        
        message["timestamp"] = datetime.now().isoformat()
        session_data["messages"].append(message)
        
        # Update memory
        self.sessions[session_id] = session_data
        
        # Save to disk
        session_file = self.histories_dir / f"{session_id}.json"
        with open(session_file, 'w') as f:
            json.dump(session_data, f, indent=2)
        
        # Update title if first user message
        if message["role"] == "user" and len([m for m in session_data["messages"] if m["role"] == "user"]) == 1:
            self._update_session_title(session_id, message["content"][:60])
    
    def get_messages(self, session_id: str) -> List[Dict]:
        """Get all messages from a session"""
        session_data = self.get_session(session_id)
        
        if not session_data:
            self.create_session(session_id)
            return []
        
        return session_data.get("messages", [])
    
    def get_history(self, session_id: str, max_messages: int = 10) -> List[Dict]:
        """Get recent chat history for session"""
        messages = self.get_messages(session_id)
        return messages[-max_messages:] if messages else []
    
    def list_sessions(self) -> List[Dict]:
        """List all sessions"""
        sessions = []
        
        for file in self.histories_dir.glob("*.json"):
            if file.name == "titles.json":
                continue
            
            with open(file, 'r') as f:
                data = json.load(f)
                
            sessions.append({
                "session_id": data["session_id"],
                "created_at": data["created_at"],
                "message_count": len(data["messages"]),
                "title": self._get_session_title(data["session_id"])
            })
        
        # Sort by creation date (newest first)
        sessions.sort(key=lambda x: x["created_at"], reverse=True)
        
        return sessions
    
    def delete_session(self, session_id: str) -> bool:
        """Delete a session"""
        session_file = self.histories_dir / f"{session_id}.json"
        
        if session_file.exists():
            session_file.unlink()
            self._remove_session_title(session_id)
            
            # Remove from memory
            if session_id in self.sessions:
                del self.sessions[session_id]
            
            logger.info(f"🗑️ Deleted session {session_id}")
            return True
        
        return False
    
    def _get_session_title(self, session_id: str) -> str:
        """Get session title from titles.json"""
        try:
            with open(self.titles_file, 'r') as f:
                titles = json.load(f)
            return titles.get(session_id, "Untitled Chat")
        except:
            return "Untitled Chat"
    
    def _update_session_title(self, session_id: str, title: str):
        """Update session title"""
        try:
            with open(self.titles_file, 'r') as f:
                titles = json.load(f)
            
            titles[session_id] = title
            
            with open(self.titles_file, 'w') as f:
                json.dump(titles, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to update title: {e}")
    
    def _remove_session_title(self, session_id: str):
        """Remove session title"""
        try:
            with open(self.titles_file, 'r') as f:
                titles = json.load(f)
            
            if session_id in titles:
                del titles[session_id]
                
                with open(self.titles_file, 'w') as f:
                    json.dump(titles, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to remove title: {e}")
