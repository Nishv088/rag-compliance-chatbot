"""
Vision analysis service using GPT-4 Vision API
"""

import base64
from io import BytesIO
from typing import Dict, Any, Optional
from PIL import Image

from openai import OpenAI
from app.config import settings
from app.utils.logger import setup_logger

logger = setup_logger("vision_analyzer")


class VisionAnalyzer:
    """Analyze images using GPT-4 Vision"""
    
    def __init__(self):
        self.client = OpenAI(api_key=settings.OPENAI_API_KEY)
        self.model = "gpt-4o-mini"  # or "gpt-4-vision-preview"
    
    def analyze_image(
        self,
        image_data: bytes,
        user_prompt: str,
        mime_type: str = "image/jpeg"
    ) -> str:
        """
        Analyze a single image with GPT-4 Vision
        
        Args:
            image_data: Raw image bytes
            user_prompt: User's question about the image
            mime_type: Image MIME type
            
        Returns:
            Analysis result text
        """
        
        try:
            # Encode image to base64
            base64_image = base64.b64encode(image_data).decode('utf-8')
            
            # Build messages
            messages = [
                {
                    "role": "system",
                    "content": "You are a precise image analyst. Describe images clearly and accurately, focusing on technical and compliance-related aspects."
                },
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": user_prompt},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:{mime_type};base64,{base64_image}"
                            }
                        }
                    ]
                }
            ]
            
            # Call Vision API
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=800
            )
            
            result = response.choices[0].message.content.strip()
            logger.info(f"✅ Image analyzed successfully ({len(result)} chars)")
            
            return result
        
        except Exception as e:
            logger.error(f"❌ Vision API error: {e}")
            return f"⚠️ Failed to analyze image: {str(e)}"
    
    def analyze_multiple_images(
        self,
        images: Dict[str, Dict[str, Any]],
        user_prompt: str
    ) -> str:
        """
        Analyze multiple images together
        
        Args:
            images: Dict of {filename: {data: bytes, mime_type: str}}
            user_prompt: User's question about the images
            
        Returns:
            Combined analysis result
        """
        
        try:
            # Build messages with multiple images
            content = [{"type": "text", "text": user_prompt}]
            
            for filename, image_info in images.items():
                base64_image = base64.b64encode(image_info['data']).decode('utf-8')
                
                content.append({
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:{image_info['mime_type']};base64,{base64_image}",
                        "detail": "high"
                    }
                })
                
                logger.info(f"📷 Added image: {filename}")
            
            messages = [
                {
                    "role": "system",
                    "content": "You are a precise image analyst. Analyze all provided images and provide a comprehensive response."
                },
                {
                    "role": "user",
                    "content": content
                }
            ]
            
            # Call Vision API
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=1200
            )
            
            result = response.choices[0].message.content.strip()
            logger.info(f"✅ Analyzed {len(images)} images successfully")
            
            return result
        
        except Exception as e:
            logger.error(f"❌ Vision API error: {e}")
            return f"⚠️ Failed to analyze images: {str(e)}"
