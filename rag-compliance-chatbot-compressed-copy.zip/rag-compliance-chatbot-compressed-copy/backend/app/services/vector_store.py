"""
Enhanced vector store with dual collection support
"""

from typing import List, Dict, Optional
from qdrant_client import QdrantClient
from qdrant_client.models import Filter, FieldCondition, MatchValue

from app.services.embedder import BGEEmbedder
from app.config import settings
from app.utils.logger import setup_logger

logger = setup_logger("vector_store")

class VectorStore:
    """Enhanced vector store with dual collection support"""
    
    def __init__(self):
        self.client = QdrantClient(host=settings.QDRANT_HOST, port=settings.QDRANT_PORT)
        self.embedder = BGEEmbedder()
        
        self.compliance_collection = settings.QDRANT_COLLECTION
        self.proposal_collection = settings.QDRANT_PROPOSAL_COLLECTION
    
    def search_compliance(
        self,
        query: str,
        top_k: int = 5,
        min_score: float = 0.70
    ) -> List[Dict]:
        """Search compliance regulations collection"""
        try:
            query_vector = self.embedder.embed_query(query)
            
            results = self.client.search(
                collection_name=self.compliance_collection,
                query_vector=query_vector,
                limit=top_k,
                score_threshold=min_score
            )
            
            formatted_results = []
            for result in results:
                formatted_results.append({
                    "id": result.id,
                    "score": result.score,
                    "content": result.payload.get("text", ""),
                    "metadata": result.payload,
                    "type": "compliance"
                })
            
            logger.info(f"📚 Compliance search: {len(formatted_results)} results above {min_score}")
            return formatted_results
        
        except Exception as e:
            logger.error(f"❌ Compliance search failed: {e}")
            return []
    
    def search_proposals(
        self,
        query: str,
        project_id: str,
        top_k: int = 3
    ) -> List[Dict]:
        """Search proposal documents for specific project"""
        try:
            query_vector = self.embedder.embed_query(query)
            
            # Filter by project_id
            results = self.client.search(
                collection_name=self.proposal_collection,
                query_vector=query_vector,
                limit=top_k,
                query_filter=Filter(
                    must=[
                        FieldCondition(
                            key="project_id",
                            match=MatchValue(value=project_id)
                        )
                    ]
                )
            )
            
            formatted_results = []
            for result in results:
                formatted_results.append({
                    "id": result.id,
                    "score": result.score,
                    "payload": result.payload,
                    "type": "proposal"
                })
            
            logger.info(f"📋 Proposal search: {len(formatted_results)} results for project {project_id}")
            return formatted_results
        
        except Exception as e:
            logger.error(f"❌ Proposal search failed: {e}")
            return []
