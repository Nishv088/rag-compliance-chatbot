"""
Intelligent retrieval with query expansion and intent detection
"""

from typing import List, Dict, Any
from app.services.retriever import QdrantRetriever
from app.services.adaptive_ranker import AdaptiveRanker
from app.utils.logger import setup_logger

logger = setup_logger("intelligent_retriever")


class QueryIntentDetector:
    """Detect query intent and type"""
    
    @staticmethod
    def detect_intent(query: str) -> Dict[str, Any]:
        """
        Detect the intent and type of user query
        
        Returns:
            Dict with intent, confidence, and metadata
        """
        
        query_lower = query.lower()
        
        intents = {
            'definition': {
                'keywords': ['what is', 'define', 'definition of', 'meaning of', 'explain'],
                'confidence': 0.0
            },
            'requirement': {
                'keywords': ['requirement', 'mandatory', 'must', 'required', 'obligation'],
                'confidence': 0.0
            },
            'procedure': {
                'keywords': ['how to', 'procedure', 'process', 'steps', 'method'],
                'confidence': 0.0
            },
            'list': {
                'keywords': ['list', 'what are', 'types of', 'categories', 'examples'],
                'confidence': 0.0
            },
            'comparison': {
                'keywords': ['difference', 'compare', 'versus', 'vs', 'distinction'],
                'confidence': 0.0
            },
            'table_lookup': {
                'keywords': ['table', 'show', 'display', 'complete table', 'all columns'],
                'confidence': 0.0
            },
            'calculation': {
                'keywords': ['calculate', 'compute', 'determine', 'how much', 'how many'],
                'confidence': 0.0
            },
            'compliance_check': {
                'keywords': ['compliant', 'comply', 'meets', 'satisfies', 'requirements'],
                'confidence': 0.0
            }
        }
        
        # Calculate confidence for each intent
        for intent_name, intent_data in intents.items():
            matches = sum(1 for keyword in intent_data['keywords'] if keyword in query_lower)
            intent_data['confidence'] = min(matches * 0.3, 1.0)
        
        # Find primary intent
        primary_intent = max(intents.items(), key=lambda x: x[1]['confidence'])
        
        # Detect if numeric query
        has_numeric = bool(AdaptiveRanker.extract_numeric_value_from_query(query))
        
        return {
            'primary_intent': primary_intent[0],
            'confidence': primary_intent[1]['confidence'],
            'all_intents': {k: v['confidence'] for k, v in intents.items() if v['confidence'] > 0},
            'has_numeric_value': has_numeric,
            'is_question': '?' in query,
            'query_length': len(query.split())
        }


class IntelligentRetriever:
    """Enhanced retriever with query expansion and intelligent ranking"""
    
    def __init__(self, base_retriever: QdrantRetriever):
        self.base_retriever = base_retriever
        self.intent_detector = QueryIntentDetector()
    
    def retrieve_with_intelligence(
        self,
        query: str,
        top_k: int = 10,
        use_query_expansion: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Intelligent retrieval with intent detection and adaptive ranking
        """
        
        # Step 1: Detect query intent
        intent_info = self.intent_detector.detect_intent(query)
        logger.info(f"🎯 Query intent: {intent_info['primary_intent']} (confidence: {intent_info['confidence']:.2f})")
        
        # Step 2: Extract numeric info if present
        numeric_info = AdaptiveRanker.extract_numeric_value_from_query(query)
        
        # Step 3: Query expansion based on intent
        queries = [query]
        if use_query_expansion:
            expanded = self._expand_query(query, intent_info)
            queries.extend(expanded)
            logger.info(f"📝 Expanded to {len(queries)} query variations")
        
        # Step 4: Retrieve chunks for all query variations
        all_chunks = []
        seen_ids = set()
        
        for q in queries:
            chunks = self.base_retriever.retrieve(q, top_k=top_k)
            for chunk in chunks:
                chunk_id = chunk.get('id')
                if chunk_id not in seen_ids:
                    all_chunks.append(chunk)
                    seen_ids.add(chunk_id)
        
        logger.info(f"✅ Retrieved {len(all_chunks)} unique chunks from {len(queries)} queries")
        
        # Step 5: Adaptive re-ranking
        if numeric_info:
            all_chunks = AdaptiveRanker.rerank_chunks_by_numeric_context(
                all_chunks,
                numeric_info,
                boost_factor=1.5
            )
        
        # Step 6: Return top K after re-ranking
        return all_chunks[:top_k]
    
    def _expand_query(self, query: str, intent_info: Dict) -> List[str]:
        """
        Expand query based on detected intent
        """
        
        expansions = []
        primary_intent = intent_info['primary_intent']
        
        if primary_intent == 'requirement':
            # Add requirement-focused variations
            expansions.append(f"mandatory requirements {query}")
            expansions.append(f"regulatory requirements {query}")
        
        elif primary_intent == 'procedure':
            # Add procedure-focused variations
            expansions.append(f"procedure for {query}")
            expansions.append(f"steps for {query}")
        
        elif primary_intent == 'definition':
            # Add definition-focused variations
            expansions.append(f"definition {query}")
            expansions.append(f"explanation {query}")
        
        elif primary_intent == 'table_lookup':
            # Add table-focused variations
            expansions.append(f"table {query}")
            expansions.append(f"requirements table {query}")
        
        # Limit to 2 expansions max
        return expansions[:2]
