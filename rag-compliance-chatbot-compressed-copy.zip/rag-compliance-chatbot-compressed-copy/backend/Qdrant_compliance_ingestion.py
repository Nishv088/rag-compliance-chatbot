"""
Production-grade ingestion pipeline for Dubai Compliance RAG
Updated for current project structure
"""

import json
from pathlib import Path
from collections import defaultdict
import hashlib
import logging
from datetime import datetime
import tiktoken
import os
import sys
import uuid

# Qdrant Imports
from qdrant_client import QdrantClient
from qdrant_client.http import models

# Add backend to path
backend_dir = Path(__file__).parent
sys.path.insert(0, str(backend_dir))

# Import BGEEmbedder from current project
from app.services.embedder import BGEEmbedder
from app.utils.logger import setup_logger
from app.config import settings

logger = setup_logger("ingestion")

# ==========================================
# CONFIGURATION
# ==========================================
QDRANT_HOST = settings.QDRANT_HOST
QDRANT_PORT = settings.QDRANT_PORT
COLLECTION_NAME = settings.QDRANT_COLLECTION
VECTOR_SIZE = settings.EMBEDDING_DIMENSION

# Paths
WF2_OUTPUT_DIR = settings.WF2_OUTPUT_DIR
WF3_OUTPUT_DIR = settings.WF3_OUTPUT_DIR


class TokenCounter:
    """Count tokens accurately using tiktoken"""
    def __init__(self):
        self.encoding = tiktoken.get_encoding("cl100k_base")
    
    def count_tokens(self, text: str) -> int:
        return len(self.encoding.encode(text))
    
    def split_into_token_chunks(self, text: str, chunk_size: int = 512, overlap: int = 51):
        """Split text into chunks of exact token size with overlap"""
        tokens = self.encoding.encode(text)
        chunks = []
        start = 0
        
        while start < len(tokens):
            end = min(start + chunk_size, len(tokens))
            chunk_tokens = tokens[start:end]
            chunk_text = self.encoding.decode(chunk_tokens)
            chunks.append(chunk_text)
            
            # Move start by chunk_size - overlap
            start = end - overlap if end < len(tokens) else end
            
        return chunks


class ProductionIngestionPipeline:
    def __init__(self, wf2_dir: str, output_dir: str = WF3_OUTPUT_DIR):
        self.wf2_dir = Path(wf2_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # ✅ Qdrant Connection (Version-Agnostic)
        try:
            self.client = QdrantClient(host=QDRANT_HOST, port=QDRANT_PORT)
            logger.info(f"✅ Connected to Qdrant at {QDRANT_HOST}:{QDRANT_PORT}")
            
            # Check if collection exists (version-agnostic way)
            try:
                self.client.get_collection(COLLECTION_NAME)
                logger.info(f"🗑️ Deleting existing collection: {COLLECTION_NAME}")
                self.client.delete_collection(COLLECTION_NAME)
                logger.info("✅ Old collection deleted")
            except Exception:
                logger.info(f"ℹ️ Collection '{COLLECTION_NAME}' doesn't exist yet")
            
            # Create fresh collection
            logger.info(f"⚙️ Creating new collection: {COLLECTION_NAME}")
            self.client.create_collection(
                collection_name=COLLECTION_NAME,
                vectors_config=models.VectorParams(
                    size=VECTOR_SIZE,
                    distance=models.Distance.COSINE
                )
            )
            self.db_available = True
            logger.info(f"✅ Collection '{COLLECTION_NAME}' created successfully")
            
        except Exception as e:
            logger.error(f"❌ Qdrant connection failed: {e}")
            self.db_available = False
            raise
        
        # Initialize embedder
        logger.info("🔄 Initializing BGE embedder...")
        self.embedder = BGEEmbedder()
        self.token_counter = TokenCounter()
        
        self.stats = {
            'total_input_sections': 0,
            'duplicates_removed': 0,
            'unique_sections': 0,
            'total_512token_chunks': 0,
            'ingested_to_db': 0,
            'local_files_created': 0,
            'errors': 0
        }
        
        # Storage for local JSON generation
        self.ingested_chunks_by_pdf = defaultdict(list)

    def _detect_table_in_chunk(self, text: str) -> bool:
        """Detect if this specific chunk contains table content"""
        table_indicators = ['<TABLE_START>', '<TABLE_END>', 'RAW_TABLE_JSON', '| ']
        return any(ind in text for ind in table_indicators) or text.count('|') >= 3

    def load_and_process(self):
        """Main execution flow"""
        logger.info("="*60)
        logger.info("🚀 Starting Production Ingestion Pipeline")
        logger.info("="*60)
        
        all_chunks_by_source = self.load_wf2_files()
        if not all_chunks_by_source:
            logger.error("❌ No data loaded from WF2 files")
            return
        
        deduped_data = self.deduplicate_chunks(all_chunks_by_source)
        vectors = self.chunk_and_embed(deduped_data)
        
        self.upsert_to_qdrant(vectors)
        self.save_locally()
        
        self.print_stats()
        return self.stats

    def load_wf2_files(self):
        """Load all WF2 JSON files"""
        data_store = defaultdict(list)
        
        if not self.wf2_dir.exists():
            logger.error(f"❌ Input directory not found: {self.wf2_dir}")
            return data_store
        
        json_files = list(self.wf2_dir.glob("*.json"))
        logger.info(f"📂 Found {len(json_files)} JSON files in {self.wf2_dir}")
        
        for json_file in sorted(json_files):
            logger.info(f"📄 Loading {json_file.name}...")
            try:
                with open(json_file, encoding='utf-8') as f:
                    content = json.load(f)
                
                chunks = content.get('chunks', [])
                self.stats['total_input_sections'] += len(chunks)
                
                for chunk in chunks:
                    src = chunk.get('source_file', json_file.stem)
                    data_store[src].append(chunk)
                
                logger.info(f"   ✓ Loaded {len(chunks)} sections")
            except Exception as e:
                logger.error(f"   ✗ Error reading {json_file}: {e}")
                self.stats['errors'] += 1
        
        return data_store

    def deduplicate_chunks(self, data_store):
        """Remove duplicates based on text content within same file"""
        logger.info("\n🔍 Deduplicating chunks...")
        clean_store = {}
        
        for source, chunks in data_store.items():
            seen = {}
            for chunk in chunks:
                txt = chunk.get('chunk_text', '')
                if not txt.strip():
                    continue
                
                # Create hash of text
                h = hashlib.md5(txt.encode()).hexdigest()
                
                if h in seen:
                    # Merge categories if duplicate found
                    existing = seen[h]
                    old_cats = set(existing.get('categories', '').split(','))
                    new_cats = set(chunk.get('categories', '').split(','))
                    existing['categories'] = ','.join(filter(None, old_cats | new_cats))
                    self.stats['duplicates_removed'] += 1
                else:
                    seen[h] = chunk
            
            clean_store[source] = list(seen.values())
            self.stats['unique_sections'] += len(seen)
        
        logger.info(f"✅ Removed {self.stats['duplicates_removed']} duplicates")
        logger.info(f"✅ Kept {self.stats['unique_sections']} unique sections")
        
        return clean_store

    def _generate_id(self, doc_id, section_no, title, text, idx):
        """Generate readable ID"""
        sec_id = section_no if section_no and section_no != 'unknown' else (title or 'section')
        txt_hash = hashlib.md5(text.encode()).hexdigest()[:8]
        
        # Clean ID string
        clean_id = f"{doc_id}_{sec_id}_{txt_hash}_seg_{idx}"
        clean_id = clean_id.replace(" ", "_").replace(".", "_").lower()
        return clean_id

    def chunk_and_embed(self, clean_store):
        """Split into 512-token chunks and generate embeddings"""
        logger.info("\n📝 Chunking and embedding...")
        all_vectors = []
        
        for source_file, sections in clean_store.items():
            logger.info(f"🔄 Processing {source_file}...")
            section_count = 0
            
            for section in sections:
                full_text = section.get('chunk_text', '')
                
                # Skip tiny sections
                if len(full_text.strip()) < 10:
                    continue

                # Split into 512 token chunks with 51 overlap
                segments = self.token_counter.split_into_token_chunks(
                    full_text, chunk_size=512, overlap=51
                )
                
                for i, segment_text in enumerate(segments):
                    try:
                        # Generate embedding using BGEEmbedder.embed_text()
                        embedding = self.embedder.embed_text(segment_text)
                        
                        # Generate IDs
                        readable_id = self._generate_id(
                            section.get('doc_id', 'unknown'),
                            section.get('section_no', 'unknown'),
                            section.get('title', 'untitled'),
                            segment_text,
                            i
                        )
                        
                        # Qdrant requires UUID
                        qdrant_uuid = str(uuid.uuid5(uuid.NAMESPACE_DNS, readable_id))
                        
                        has_table_chunk = self._detect_table_in_chunk(segment_text)
                        
                        # Metadata Construction
                        payload = {
                            "id": readable_id,
                            "source_file": source_file,
                            "doc_id": section.get('doc_id', 'unknown'),
                            "section_no": section.get('section_no', 'unknown'),
                            "section_title": section.get('title', 'Untitled'),
                            "categories": section.get('categories', ''),
                            "page_no": section.get('pages', 'N/A'),
                            "segment_index": i,
                            "total_segments": len(segments),
                            "text": segment_text,
                            "token_count": self.token_counter.count_tokens(segment_text),
                            "has_tables": section.get('has_tables', False) or has_table_chunk,
                            "chunk_has_table": has_table_chunk,
                            "table_count": section.get('table_count', 0),
                            "has_images": section.get('has_images', False),
                            "image_count": section.get('image_count', 0),
                            "has_formulas": section.get('has_formulas', False),
                            "formula_count": section.get('formula_count', 0)
                        }
                        
                        # Add to vector list for DB upsert
                        all_vectors.append(models.PointStruct(
                            id=qdrant_uuid,
                            vector=embedding,
                            payload=payload
                        ))
                        
                        # Add to local list for file saving
                        self.ingested_chunks_by_pdf[source_file].append(payload)
                        self.stats['total_512token_chunks'] += 1
                        section_count += 1

                    except Exception as e:
                        logger.error(f"   ✗ Embedding error: {e}")
                        self.stats['errors'] += 1
            
            logger.info(f"   ✓ Created {section_count} chunks from {len(sections)} sections")
        
        return all_vectors

    def upsert_to_qdrant(self, points):
        """Batch upsert to Qdrant"""
        if not self.db_available or not points:
            logger.warning("⚠️ Skipping Qdrant upsert (DB unavailable or no points)")
            return

        batch_size = 100
        total = len(points)
        
        logger.info(f"\n🚀 Upserting {total} chunks to Qdrant...")
        
        for i in range(0, total, batch_size):
            batch = points[i:i+batch_size]
            try:
                self.client.upsert(
                    collection_name=COLLECTION_NAME,
                    points=batch
                )
                self.stats['ingested_to_db'] += len(batch)
                progress = (i + len(batch)) / total * 100
                logger.info(f"   ✓ Progress: {progress:.1f}% ({i + len(batch)}/{total})")
            except Exception as e:
                logger.error(f"   ✗ Upsert error: {e}")
                self.stats['errors'] += 1

    def save_locally(self):
        """Save ingested data to local JSON files"""
        logger.info(f"\n💾 Saving local files to {self.output_dir}...")
        
        for source_file, chunks in self.ingested_chunks_by_pdf.items():
            # Format output filename
            clean_name = source_file.replace('.json', '').replace('.pdf', '')
            out_path = self.output_dir / f"{clean_name}_ingested_512token.json"
            
            # Construct exact file structure
            file_data = {
                "source_file": source_file,
                "total_512token_chunks": len(chunks),
                "ingestion_date": datetime.now().isoformat(),
                "chunks": chunks
            }
            
            with open(out_path, 'w', encoding='utf-8') as f:
                json.dump(file_data, f, indent=2, ensure_ascii=False)
            
            self.stats['local_files_created'] += 1
            logger.info(f"   ✓ Saved: {out_path.name}")

    def print_stats(self):
        """Print final statistics"""
        logger.info("\n" + "="*60)
        logger.info("📊 INGESTION STATISTICS")
        logger.info("="*60)
        logger.info(f"📥 Total input sections:     {self.stats['total_input_sections']}")
        logger.info(f"🗑️ Duplicates removed:        {self.stats['duplicates_removed']}")
        logger.info(f"✅ Unique sections kept:      {self.stats['unique_sections']}")
        logger.info(f"📝 Total 512-token chunks:   {self.stats['total_512token_chunks']}")
        logger.info(f"☁️  Chunks ingested to DB:    {self.stats['ingested_to_db']}")
        logger.info(f"💾 Local files created:      {self.stats['local_files_created']}")
        logger.info(f"❌ Errors encountered:       {self.stats['errors']}")
        logger.info("="*60)
        
        if self.db_available:
            # Verify collection
            try:
                info = self.client.get_collection(COLLECTION_NAME)
                logger.info(f"\n✅ Collection '{COLLECTION_NAME}' verified:")
                logger.info(f"   Points: {info.points_count}")
                logger.info(f"   Vectors: {info.vectors_count}")
            except Exception as e:
                logger.error(f"❌ Collection verification failed: {e}")


if __name__ == "__main__":
    # Check if input directory exists
    if not Path(WF2_OUTPUT_DIR).exists():
        print(f"\n❌ ERROR: Input directory not found!")
        print(f"   Expected: {WF2_OUTPUT_DIR}")
        print(f"\n👉 Update WF2_OUTPUT_DIR in this script to point to your JSON files\n")
        sys.exit(1)
    
    # Run pipeline
    try:
        pipeline = ProductionIngestionPipeline(
            wf2_dir=WF2_OUTPUT_DIR,
            output_dir=WF3_OUTPUT_DIR
        )
        stats = pipeline.load_and_process()
        
        if stats and stats['ingested_to_db'] > 0:
            print("\n" + "="*60)
            print("🎉 INGESTION COMPLETED SUCCESSFULLY!")
            print("="*60)
            print(f"✅ {stats['ingested_to_db']} vectors ingested to Qdrant")
            print(f"✅ {stats['local_files_created']} local files saved")
            print("\n🚀 Next steps:")
            print("   1. Check Qdrant dashboard: http://localhost:6333/dashboard")
            print("   2. Restart backend: uvicorn app.main:app --reload --host 0.0.0.0 --port 8000")
            print("   3. Test frontend: http://localhost:3000")
            print("="*60 + "\n")
        else:
            print("\n⚠️ Ingestion completed but no data was uploaded to Qdrant")
            
    except Exception as e:
        logger.error(f"\n❌ FATAL ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
